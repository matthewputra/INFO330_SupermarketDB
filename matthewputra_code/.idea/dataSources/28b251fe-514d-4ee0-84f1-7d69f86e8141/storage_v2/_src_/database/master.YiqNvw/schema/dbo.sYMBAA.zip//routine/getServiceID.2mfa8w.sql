CREATE PROCEDURE getServiceID
@sName VARCHAR(50),
@SID INT OUTPUT
AS
SET @SID = (SELECT ServiceID 
			FROM tblSERVICE
			WHERE ServiceName = @sName)

go

