
CREATE PROCEDURE insertCustCarService
@f_Name VARCHAR(50),
@l_Name VARCHAR(50),
@dob DATE,
@s_Name VARCHAR(50),
@c_Name VARCHAR(50),
@manufacturer VARCHAR(50),
@model_name VARCHAR(50),
@CCSDate DATE, 
@Price NUMERIC(8,2)
AS

-- BR!!
IF EXISTS (
	SELECT *
	FROM tblCUSTOMER C
		JOIN tblCUST_CAR_SERVICE CCS ON C.CustID = CCS.CustID
		JOIN tblCAR CR on CCS.CarID = CR.CarID
		JOIN tblMODEL M on CR.ModelID = M.ModelID
		JOIN tblSERVICE S ON CCS.ServiceID = S.ServiceID
	WHERE C.CustFname = @f_Name -- being passed in customer
		AND C.CustLname = @l_Name
		AND C.CustBirth = @dob
		AND C.CustState = 'Idaho'
		AND @CCSDate > 'November 6, 2021'
		AND @manufacturer = 'Toyota'
		AND @model_name = 'Camry')

		BEGIN
			IF @s_Name = 'Engine rebuild'
				BEGIN
					PRINT 'No engine rebuild';
					THROW 51000, 'Will not serve customers from Idaho', 1;
				END	
		END	

DECLARE @C_ID INT, @S_ID INT, @CR_ID INT

EXEC getCarID
@cName = @c_Name,
@Mfg = @manufacturer,
@mName = @model_name,
@CRID = @CR_ID OUTPUT
IF @CR_ID IS NULL
	BEGIN
		PRINT '@CR_ID is null';
		THROW 51000, '@CR_ID cannot be null', 1;
	END

EXEC getServiceID
@sName = @s_Name,
@SID = @S_ID OUTPUT
IF @S_ID IS NULL
	BEGIN
		PRINT '@S_ID is null';
		THROW 51000, '@S_ID cannot be null', 1;
	END

EXEC getCustomerID
@fName = @f_Name,
@lName = @l_Name,
@Birth = @dob,
@CID = @C_ID OUTPUT
IF @C_ID IS NULL
	BEGIN
		PRINT '@C_ID is null';
		THROW 51000, '@C_ID cannot be null', 1;
	END

BEGIN TRAN T1
	INSERT INTO tblCUST_CAR_SERVICE(CustCarServiceDate, Price,CarID, CustID, ServiceID)
	VALUES(@CCSDate, @Price, @CR_ID, @C_ID, @S_ID)
	IF @@ERROR <> 0
		BEGIN
			PRINT 'Could not insert into tblCUST_CAR_SERVICE due to an error'
			ROLLBACK TRAN T1
		END
	ELSE
		COMMIT TRAN T1

go

