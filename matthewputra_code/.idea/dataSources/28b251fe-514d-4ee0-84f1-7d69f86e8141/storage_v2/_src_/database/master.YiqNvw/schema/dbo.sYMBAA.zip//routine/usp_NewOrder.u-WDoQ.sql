
-- Sproc for new order
create proc usp_NewOrder
@Fname2 varchar(50),
@Lname2 varchar(50),
@DOB2 date,
@ProdName2 varchar(50),
@OrderDate date,
@Qty int
as
declare @C_ID2 int, @P_ID2 int

exec usp_GetCustomerID
@Fname2,
@Lname2,
@DOB2,
@C_ID2 out
if @C_ID2 is null	
	begin
		print 'Error, C_ID2 cannot be null'
		raiserror('@C_ID2 cannot be null', 11, 1)
		return
	end

exec usp_GetProductID
@ProdName2,
@P_ID2 out
if @P_ID2 is null	
	begin
		print 'Error, P_ID2 cannot be null'
		raiserror('@P_ID2 cannot be null', 11, 1)
		return
	end

begin transaction t1
	insert into tblORDER(ProductID, CustomerID, OrderDate, Quantity)
	values(@P_ID2, @C_ID2, @OrderDate, @Qty)
	if @@error <> 0
		begin
			print 'Error, rolling back transaction'
			rollback tran t1
		end
	else
		begin
			commit tran t1
		end
go

