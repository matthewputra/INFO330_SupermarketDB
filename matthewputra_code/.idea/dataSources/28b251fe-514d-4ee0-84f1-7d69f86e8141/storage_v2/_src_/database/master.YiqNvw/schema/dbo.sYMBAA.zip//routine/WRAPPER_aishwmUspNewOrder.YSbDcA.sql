CREATE PROCEDURE WRAPPER_aishwmUspNewOrder
    @Run INT
    AS
    DECLARE @F VARCHAR(50)
    DECLARE @L VARCHAR(50)
    DECLARE @B VARCHAR(50)
    DECLARE @P VARCHAR(50)
    DECLARE @Q INT
    DECLARE @ODate DATE = (SELECT GetDate())
    DECLARE @CustomerRowcount INT = (SELECT COUNT(*) FROM tblCUSTOMER)
    DECLARE @ProductRowcount INT = (SELECT COUNT(*) FROM tblPRODUCT)

    DECLARE @Customer_PK INT
    DECLARE @Product_PK INT

    WHILE @Run > 0
    BEGIN
        SET @Customer_PK = (SELECT RAND() * @CustomerRowcount)
        SET @Product_PK = (SELECT RAND() * @ProductRowcount)
        SET @F = (SELECT CustFName FROM tblCUSTOMER WHERE CustomerID = @Customer_PK)
        SET @L = (SELECT CustLName FROM tblCUSTOMER WHERE CustomerID = @Customer_PK)
        SET @B = (SELECT CustBirthDate FROM tblCUSTOMER WHERE CustomerID = @Customer_PK)
        SET @P = (SELECT ProductName FROM tblPRODUCT WHERE ProductID = @Product_PK)
        Set @Q = (Select 10 * Rand()) + 1
   EXEC aishwmUspNewOrder
        @First = @F,
        @Last = @L,
        @Birth = @B,
        @PName = @P,
        @Quant = @Q,
        @OrdDate = @ODate
SET @Run = @Run -1
PRINT @Run
END
go

