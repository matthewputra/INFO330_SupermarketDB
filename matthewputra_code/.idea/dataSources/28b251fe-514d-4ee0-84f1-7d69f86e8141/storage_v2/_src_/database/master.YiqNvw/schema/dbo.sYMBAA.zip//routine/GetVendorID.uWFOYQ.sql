-- Gets VendorID given VendorName
CREATE PROCEDURE GetVendorID
@VendorName varchar(75),
@VendorID INT OUTPUT
AS
SET @VendorID = (
	SELECT VendorID FROM tblVENDOR
	WHERE VendorName = @VendorName
)
go

