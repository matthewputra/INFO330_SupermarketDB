
/*
5. Write the code to enforce the business rule: 
"No customer of type 'residential' in Redmond, Washington may order more than 
quantity of 12 product named 'Super Heat Solar Panel' in any month of January"
*/

CREATE FUNCTION fn_Max12Panel_Redmon_Jan()
RETURNS INT
AS
BEGIN
DECLARE @Ret INT = 0
	IF EXISTS(SELECT *
		FROM tblCUSTOMER_TYPE CT
			JOIN tblCUSTOMER C ON CT.CustTypeID = C.CustTypeID
			JOIN tblJOB J ON C.CustID = J.CustID
			JOIN tblORDER O ON J.JobID = O.JobID
			JOIN tblLINE_ITEM LI ON O.OrderDate = LI.OrderID
			JOIN tblPRODUCT P ON LI.ProductID = P.ProductID
		WHERE CustTypeName = 'residential'
		AND C.CustZIP = '98052'
		AND P.ProductName = 'Super Heat Solar Panel'
		AND MONTH(O.OrderDate) = 1
		HAVING SUM(LI.Qty) > 12
		)

		BEGIN
			SET @Ret = 1
		END
RETURN @Ret
END
go

