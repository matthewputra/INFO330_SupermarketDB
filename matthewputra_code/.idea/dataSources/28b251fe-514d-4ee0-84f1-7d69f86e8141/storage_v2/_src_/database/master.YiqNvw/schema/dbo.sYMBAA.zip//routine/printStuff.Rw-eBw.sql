CREATE PROCEDURE printStuff
@first VARCHAR(50),
@second VARCHAR(50),
@last VARCHAR(50)
AS

PRINT 'Ran procedure printStuff'
go

