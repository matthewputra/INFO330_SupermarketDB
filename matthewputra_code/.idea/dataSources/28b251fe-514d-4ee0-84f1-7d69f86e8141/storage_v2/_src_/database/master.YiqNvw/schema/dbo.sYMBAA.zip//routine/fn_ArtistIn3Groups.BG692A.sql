-- An Artist can’t be in more than 3 active groups at the same time
CREATE FUNCTION fn_ArtistIn3Groups()
RETURNS INT
AS
BEGIN
   DECLARE @RET INT = 0
       IF EXISTS (
           SELECT A.ArtistID FROM tblArtist A
               JOIN tblGroupArtist GA ON A.ArtistID = GA.ArtistID
               JOIN tblGroup G ON GA.GroupID = G.GroupID
               JOIN tblContract CT ON G.GroupID = CT.GroupID
               JOIN tblContractType CTT ON CT.ContractTypeID = CTT.ContractTypeID
               GROUP BY A.ArtistID
               HAVING COUNT(G.GroupID) > 3
       )
       BEGIN
       SET @RET = 1
       END
RETURN @RET
END
go

