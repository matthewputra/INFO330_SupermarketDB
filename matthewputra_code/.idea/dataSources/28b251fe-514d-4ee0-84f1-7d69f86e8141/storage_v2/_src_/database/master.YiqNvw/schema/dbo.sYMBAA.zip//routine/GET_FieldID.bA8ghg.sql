
--****************************************************************************************************************************************************************--
-- CREATE PROCEDURES + NESTED PROCEDURES
--****************************************************************************************************************************************************************--
-- NESTED STORED PROCEDURE GET FieldID 
CREATE PROCEDURE GET_FieldID
@Fieldname VARCHAR(50),
@Street VARCHAR(50),
@City VARCHAR(20),
@State VARCHAR(2),
@Zip INT,
@FID INT OUTPUT
AS

SET @FID = (SELECT FieldID 
            FROM tblFIELD
            WHERE FieldName = @Fieldname
            AND FieldStreet = @Street
            AND FieldCity = @City
            AND FieldState = @State
            AND FieldZip = @Zip)
go

