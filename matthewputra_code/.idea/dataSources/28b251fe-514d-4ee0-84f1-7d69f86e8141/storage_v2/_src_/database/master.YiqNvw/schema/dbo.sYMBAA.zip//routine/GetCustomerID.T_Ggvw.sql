CREATE PROCEDURE GetCustomerID
 @Customer_FName VARCHAR(60),
 @Customer_LName VARCHAR(60),
 @Customer_Birth DATE,
 @Customer_Email VARCHAR(75),
 @Customer_ID INT OUTPUT
 AS
 SET @Customer_ID = (SELECT CustID FROM tblCustomer
	WHERE CustFname = @Customer_FName
	AND CustLname = @Customer_LName
    AND CustDOB = @Customer_Birth
    AND CustEmail = @Customer_Email)
go

