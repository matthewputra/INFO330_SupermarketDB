CREATE PROCEDURE INSERT_TOURNAMENT
@BeginDate date,
@EndDate date,
@TrnName varchar(20)
AS
BEGIN TRAN P1
INSERT INTO TOURNAMENT(BeginDate, EndDate, TrnName)
VALUES(@BeginDate, @EndDate, @TrnName)
COMMIT TRAN P1
go

