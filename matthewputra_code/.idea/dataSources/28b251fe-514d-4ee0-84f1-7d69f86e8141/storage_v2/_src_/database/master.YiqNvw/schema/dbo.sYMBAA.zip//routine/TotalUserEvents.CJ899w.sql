

--TotalUserEvents - Cecilia
--Total events that a user does
--Goes in tblUSER
CREATE FUNCTION TotalUserEvents(@UserID INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	SET @RET = (SELECT COUNT(*)
				FROM tblUSER U
				JOIN tblSESSION S ON U.UserID = S.UserID
				JOIN tblVIDEO V ON S.SessionID = V.SessionID
				JOIN tblVIDEO_EVENT VE ON V.VideoID = VE.VideoID
				JOIN tblEVENT E ON VE.EventID = E.EventID
				WHERE U.UserID = @UserID
				)
	RETURN @RET
END
go

