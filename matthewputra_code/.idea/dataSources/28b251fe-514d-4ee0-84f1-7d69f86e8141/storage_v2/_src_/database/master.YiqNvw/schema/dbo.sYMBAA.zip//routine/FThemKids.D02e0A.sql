
CREATE FUNCTION FThemKids()
RETURNS INT
AS
BEGIN
DECLARE @Ret INT = 0 --default value of 0, bc assuming the db is correct, has good data. 
IF EXISTS (SELECT * 
			FROM tblSTUDENT S
			JOIN tblREGISTRATION R
			ON S.StudentID = R.StudentID
			JOIN tblCLASS C ON R.ClassID = C.ClassID
			WHERE C.ClassName LIKE '%4__') --to get 481, 411, etc. no other wildcard combos work for this. %4% will return any course # w 4, like 314.
			AND S.BirthDate > (DateAdd(Year, GetDate(), -21)) --SELECT GetDate() - (365.25

BEGIN
SET @Ret = 1
END
RETURN @Ret
END
go

