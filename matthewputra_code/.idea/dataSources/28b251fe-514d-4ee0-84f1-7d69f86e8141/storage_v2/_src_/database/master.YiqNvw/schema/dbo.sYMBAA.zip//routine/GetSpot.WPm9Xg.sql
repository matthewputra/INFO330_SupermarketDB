Create procedure GetSpot
@spName varchar(50),
@spID INT output
as 
Set @spID = (select SpotID from tblSPOT where SpotName = @spName)
go

