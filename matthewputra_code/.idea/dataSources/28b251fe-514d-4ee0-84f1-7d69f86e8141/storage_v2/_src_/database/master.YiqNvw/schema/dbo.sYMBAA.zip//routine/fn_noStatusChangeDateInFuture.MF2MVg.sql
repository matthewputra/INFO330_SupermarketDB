


-- Cannot have StatusChangeDate be in the future of current date
CREATE FUNCTION fn_noStatusChangeDateInFuture()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = 0
    IF EXISTS (
        SELECT * FROM
        tblJobStauts
        WHERE StatusChangeDate > (SELECT GETDATE())
    )
    BEGIN
        SET @Ret = 1
    END
    RETURN @Ret
END
go

