CREATE PROCEDURE kel28_INSERT_STAFF_POSITION
@Begin DATE,
@End DATE,
@D_Name VARCHAR(75),
@S_Fname VARCHAR(60),
@S_Lname VARCHAR(60),
@S_Birth DATE,
@P_Name VARCHAR(50)
AS 
DECLARE @D_ID INT, @S_ID INT, @P_ID INT

EXEC kel28_GetDeptID
@DeptName = @D_Name,
@DeptID = @D_ID OUTPUT

-- ERROR HANDLING

EXEC kel28_GetStaffID
@SFname = @S_Fname,
@SLname = @S_Lname,
@SBirth = @S_Birth,
@StaffID = @S_ID OUTPUT

-- ERROR HANDLING

EXEC kel28_GetPositionID
@PosName = @P_Name,
@PosID = @P_ID OUTPUT

-- ERROR HANDLING

BEGIN TRAN G1
INSERT INTO tblSTAFF_POSITION (StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES (@S_ID, @P_ID, @Begin, @End, @D_ID)
IF @@ERROR <> 0
BEGIN
PRINT 'TRAN G1 is terminating due to some error'
ROLLBACK TRAN G1
END
ELSE
COMMIT TRAN G1
go

