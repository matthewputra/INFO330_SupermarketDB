

--Artists from Germany can’t be a composer - Winnie
CREATE FUNCTION dbo.fn_noComp()
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (SELECT *
	FROM tblCountry C
	JOIN tblCountry_Artist CA ON C.CountryID = CA.CountryID
	JOIN tblArtist A ON A.ArtistID = CA.ArtistID
	JOIN tblArtist_ArtistType AAT ON AAT.ArtistID = A.ArtistID
	JOIN tblArtistType ART ON ART.ArtistTypeID = AAT.ArtistTypeID
	join tblGroupArtist GA ON GA.ArtistID = A.ArtistID
	JOIN tblGroup G ON G.GroupID = GA.GroupID
	JOIN tblContract CT ON CT.GroupID = G.GroupID
	WHERE C.CountryName = 'Germany'
	and ArtistTypeName = 'composer'
	)
	BEGIN
		SET @Ret = 1
	END
	
	RETURN @Ret

END

go

