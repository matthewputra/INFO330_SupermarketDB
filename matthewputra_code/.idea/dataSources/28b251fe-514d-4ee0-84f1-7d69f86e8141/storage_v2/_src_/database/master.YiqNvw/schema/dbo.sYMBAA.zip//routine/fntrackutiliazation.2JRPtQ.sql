CREATE FUNCTION fntrackutiliazation(@PrID INT) 
RETURNS NUMERIC(12,2) 
AS
BEGIN
    DECLARE @Ret NUMERIC(12,2) =
	(SELECT ((pg.OccupiedSpaces / CAST(pud.Value AS int) * 100)) as utilizationRate
	from PARKRIDE_GATEWAY pg 
	JOIN PARKRIDE pr on pr.ParkRideID = pg.ParkRideID
JOIN PR_USAGE_DETAIL pud on pr.ParkRideID = pud.ParkRideID
JOIN USAGE_DETAIL ud on pud.DetailID = ud.DetailID
                    WHERE pg.ParkRideID = @PrID 
					and ud.DetailName = 'Capacity')
    RETURN @Ret
END
go

