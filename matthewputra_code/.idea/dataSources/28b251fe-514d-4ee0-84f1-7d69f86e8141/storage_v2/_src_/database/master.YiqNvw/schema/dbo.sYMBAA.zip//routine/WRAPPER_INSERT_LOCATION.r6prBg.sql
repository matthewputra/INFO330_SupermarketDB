
--****************************************************************************************************************************************************************--
-- WRAPPER FOR INSERT LOCATION
CREATE PROCEDURE WRAPPER_INSERT_LOCATION

AS 
-- DECLARE VARIABLES 
DECLARE @CN VARCHAR(100)   -- CompanyName        
DECLARE @LN VARCHAR(20)   -- LocationName
DECLARE @LST VARCHAR(50)  -- LocationStreet 
DECLARE @LC VARCHAR(20)   -- LocationCity 
DECLARE @LS VARCHAR(2)    -- LocationState
DECLARE @LZ INT           -- LocationZip

DECLARE @Company_PK INT = (SELECT COUNT(*) FROM tblCOMPANY)
DECLARE @Location_PK INT = (SELECT COUNT(*) FROM tblCompany_Location)

--------------------------------------------------
-- WHILE LOOP 
WHILE @Company_PK > 0 
    BEGIN 
		DECLARE @QUANTITY INT = (SELECT(Rand() * 5)) + 1
		DECLARE @CURRENT INT = 0

        SET @CN = (SELECT CompanyName
                    FROM tblCOMPANY
                    WHERE CompanyID = @Company_PK)
        
		WHILE @CURRENT < @QUANTITY
			BEGIN
				SET @LN = (SELECT LocationName
                    FROM tblCompany_Location
                    WHERE LocationID = @Location_PK)
				
				SET @LST = (SELECT LocationStreet
                    FROM tblCompany_Location
                    WHERE LocationID = @Location_PK)

				SET @LC = (SELECT LocationCity
                    FROM tblCompany_Location
                    WHERE LocationID = @Location_PK)

		        SET @LS = (SELECT LocationState
					FROM tblCompany_Location
                    WHERE LocationID = @Location_PK)
                
                SET @LZ = (SELECT LocationZip
					FROM tblCompany_Location
                    WHERE LocationID = @Location_PK)
    
                EXEC INSERT_LOCATION
                @C_Name = @CN,
                @L_Name = @LN,
                @Street = @LST,
                @City = @LC,
                @State = @LS,
                @Zip = @LZ

				DELETE FROM tblCompany_Location WHERE LocationID = @Location_PK
				SET @Location_PK = @Location_PK - 1
				SET @CURRENT = @CURRENT + 1
			END

        -- EXEC BASED PROCEDURE 
        SET @Company_PK = @Company_PK - 1
    END
go

