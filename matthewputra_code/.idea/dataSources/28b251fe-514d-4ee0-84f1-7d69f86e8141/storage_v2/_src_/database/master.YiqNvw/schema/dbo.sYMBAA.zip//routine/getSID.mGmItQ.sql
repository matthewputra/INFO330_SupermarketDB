
CREATE PROCEDURE getSID
@fname varchar(50),
@lname varchar(50),
@bd DATE,
@sid INT OUTPUT
AS
SET @sid = (SELECT StudentID
			FROM STUDENT
			WHERE Fname = @fname
				AND Lname = @lname
				AND DOB = @bd)
go

