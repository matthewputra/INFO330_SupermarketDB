CREATE FUNCTION fn_adPriceLowerThanCampaignPrice()
RETURNS INT 
AS 
BEGIN
    DECLARE @Ret INT = 0
    IF EXISTS (
        SELECT * FROM tblAD_LOCATION_PRICE ALP 
            JOIN tblAD_LOCATION AL ON ALP.AdLocationID = AL.AdLocationID
            JOIN tblAD A ON AL.AdLocationID = A.AdLocationID
            JOIN tblPRODUCT_CAMPAIGN PC ON A.ProductCampaignID = PC.ProductCampaignID
            JOIN tblCAMPAIGN C ON PC.CampaignID = C.CampaignID
            JOIN tblCAMPAIGN_TYPE CT ON C.CampaignTypeID = CT.CampaignTypeID
        WHERE C.AdsPlacedPrice < CT.CampaignTypePrice 
    )
        SET @Ret = 1
    RETURN @Ret
END
go

