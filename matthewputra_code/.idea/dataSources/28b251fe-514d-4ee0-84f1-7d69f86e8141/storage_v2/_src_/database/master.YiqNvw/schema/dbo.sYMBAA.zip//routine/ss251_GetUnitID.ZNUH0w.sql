
CREATE PROCEDURE ss251_GetUnitID
@Unity varchar(50),
@UnityID INT OUTPUT
AS

SET @UnityID = (SELECT UnitID
FROM tblUNIT
WHERE UnitName = @Unity)

go

