
Create procedure NewDetailForEvent
@DeTypeName varchar(50),
@DeName varchar(50),
@DeValue varchar(300),
@EVENTday Date,
@EVENTname varchar(50)

as
Declare @De_id INT, @EVENT_id INT , @DeTypeID INT
EXEC GetEvent
@Eday = @EVENTday,
@Ename = @EVENTname,
@evID = @EVENT_id output
IF @EVENT_id IS NULL
BEGIN
RAISERROR ('@EVENT_id cannot be NULL', 11,1)
RETURN
END
EXEC GetDetailType
@DTName =@DeTypeName,
@DTID = @DeTypeID output
IF @DeTypeID IS NULL
BEGIN
RAISERROR ('@DeTypeID cannot be NULL', 11,1)
RETURN
END
Begin Transaction T1
Insert into tblINPUTDETAIL(DetailName,DetailTypeID,DetailValue)
Values (@DeName, @DeTypeID, @DeValue)
IF @@ERROR <> 0
BEGIN
PRINT 'Failing transaction T1'
ROLLBACK TRAN T1
END
ELSE
SET @De_id = (SELECT SCOPE_IDENTITY())
	Begin Transaction T2
	Insert into tblEVENT_DETAIL (EventID,DetailID) values(@EVENT_id,@De_id)
	IF @@ERROR <> 0
	BEGIN
	PRINT 'Failing transaction T2'
	ROLLBACK TRAN T2
	END
	ELSE
	COMMIT TRAN T2
COMMIT TRAN T1
go

