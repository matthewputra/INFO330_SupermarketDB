create proc usp_GetCustomerID
@Fname varchar(50),
@Lname varchar(50),
@DOB date,
@C_ID int out
as
set @C_ID = (select CustomerID 
			from tblCUSTOMER 
			where CustFName = @Fname
			and CustLName = @Lname
			and CustBirthDate = @DOB)
go

