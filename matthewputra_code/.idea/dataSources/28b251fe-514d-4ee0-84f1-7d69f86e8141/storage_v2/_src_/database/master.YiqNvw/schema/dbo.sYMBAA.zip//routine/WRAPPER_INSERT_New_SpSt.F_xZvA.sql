CREATE PROCEDURE WRAPPER_INSERT_New_SpSt
@RUN INT
AS
DECLARE @Rand INT, @SpPK INT, @StPK INT
DECLARE @SpName varchar(50)
DECLARE @StName varchar(50)

/*unique value from rand rows and col*/
SET  @SpPK = (SELECT COUNT(*) FROM tblSPOT)
SET  @StPK = (SELECT COUNT(*) FROM tblSTATUS)
WHILE @Run > 0
BEGIN

SET @SpPK = (SELECT RAND() * (@SpPK-1)+1)
SET @StPK = (SELECT RAND() * (@StPK-1)+1)
PRINT '@SpPK = '
PRINT @SpPK
PRINT '@StPK = '
PRINT @StPK
SET @SpName = (SELECT SpotName FROM tblSPOT WHERE SpotID = @SpPK)
SET @StName = (SELECT StatusName FROM tblSTATUS WHERE StatusID = @StPK)
/*if @fname is null OR @lName is null OR @ccDOB is null OR @ppname is null
begin
PRINT 'element null '
PRINT '@fName '
print @fName
PRINT '@lName '
print @lName
PRINT '@ccDOB '
print @ccDOB
PRINT '@ppname '
print @ppname
end*/

EXEC newSpSt
@spotName =@SpName,
@statusName =@StName

SET @Run = @Run -1
PRINT @Run
END
go

