CREATE PROCEDURE getCarID
@cName VARCHAR(50),
@Mfg VARCHAR(50),
@mName VARCHAR(50),
@CRID INT OUTPUT
AS
SET @CRID = (SELECT CarID 
			FROM tblCAR C
			JOIN tblMODEL M ON C.ModelID = M.ModelID
			WHERE C.CarName = @cName
			AND M.MfgName = @Mfg
			AND MfgName = @mName)

go

