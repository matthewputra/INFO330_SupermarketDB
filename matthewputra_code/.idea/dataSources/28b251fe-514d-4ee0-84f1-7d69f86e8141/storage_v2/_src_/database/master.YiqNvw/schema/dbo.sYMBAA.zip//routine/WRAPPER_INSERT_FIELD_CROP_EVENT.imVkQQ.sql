CREATE PROCEDURE WRAPPER_INSERT_FIELD_CROP_EVENT
@RUN INT
AS

-- DELCARE VARIABLES 
DECLARE @EBD DATE            -- EventBeginDate
DECLARE @FN VARCHAR(50)      -- FieldName
DECLARE @FST VARCHAR(50)     -- FieldStreet
DECLARE @FC VARCHAR(20)      -- FieldCity
DECLARE @FS VARCHAR(2)       -- FieldState
DECLARE @FZ INT              -- FieldZip
DECLARE @CN VARCHAR(50)      -- CropName
DECLARE @EN VARCHAR(50)      -- EventName

DECLARE @FieldCrop_PK INT
DECLARE @Event_PK INT
DECLARE @Field_PK INT
DECLARE @Crop_PK INT

SET @EBD = (SELECT GetDate())

--------------------------------------------------
-- WHILE LOOP 
WHILE @RUN > 0 
    BEGIN
        SET @FieldCrop_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblFIELD_CROP))
        SET @Event_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblEVENT))

        IF @FieldCrop_PK = 0
            BEGIN
                SET @FieldCrop_PK = 1
            END

        IF @Event_PK = 0
            BEGIN
                SET @Event_PK = 1
            END

        SET @Field_PK = (SELECT FieldID
                        FROM tblFIELD_CROP
                        WHERE FieldCropID = @FieldCrop_PK)

        SET @Crop_PK = (SELECT CropID
                        FROM tblFIELD_CROP
                        WHERE FieldCropID = @FieldCrop_PK)
        
        SET @FN = (SELECT FieldName
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FST = (SELECT FieldStreet
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FC = (SELECT FieldCity
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FS = (SELECT FieldState
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FZ = (SELECT FieldZip
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @CN = (SELECT CropName
                    FROM tblCROP
                    WHERE CropID = @Crop_PK)

        SET @EN = (SELECT EventName
                    FROM tblEVENT
                    WHERE EventID = @Event_PK)

        -- EXEC BASED PROCEDURE 
        EXEC INSERT_FIELD_CROP_EVENT
        @E_BeginD = @EBD,
        @F_N = @FN,
        @F_Street = @FST,
        @F_City = @FC,
        @F_State = @FS,
        @F_Zip = @FZ,
        @Crop_N = @CN,
        @Event_N = @EN

        SET @RUN = @RUN - 1
        print @RUN
    END
go

