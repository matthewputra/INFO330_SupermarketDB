
CREATE PROCEDURE hire_exst_pos1
@F varchar(20), --first name
@L varchar(20), --last name
@A varchar(50), --address
@C varchar(20), --city
@S varchar(20), --state
@Z varchar(20), --zip
@B DATE,        --birth
@N varchar(20), --netID
@E varchar(20), --email
@G varchar(20), --gender
@P varchar(20), --position
@D varchar(20), --department
@BD DATE,       --begin date
@ED DATE        --end date
AS
DECLARE @S_ID INT, @P_ID INT, @D_ID INT
SET @S_ID = 
	(SELECT StaffID
	FROM tblSTAFF
	WHERE StaffNetID = @N)

SET @P_ID =
	(SELECT PositionID
	FROM tblPOSITION
	WHERE PositionName = @P)

SET @D_ID =
	(SELECT DeptID
	FROM tblDEPARTMENT
	WHERE DeptName = @D)

INSERT INTO tblSTAFF(StaffFName, StaffLName, StaffAddress, StaffCity, StaffState, StaffZip, StaffBirth, StaffNetID, StaffEmail, Gender)
VALUES (@F, @L, @A, @C, @S, @Z, @B, @N, @E, @G)

INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES(@S_ID, @P_ID, @BD, @ED, @D_ID)

go

