
CREATE PROCEDURE insertNewJob
@Fnamey VARCHAR(50),
@Lnamey VARCHAR(50),
@Phonel VARCHAR(20),
@Emaill VARCHAR(100),
@LocationNamey VARCHAR(50),
@Chargey decimal(6,2),
@JobDescribe VARCHAR(2000)
AS
DECLARE @L_ID INT
    EXEC xz67_GetLocationID
    @Fname = @Fnamey,
    @Lname = @Lnamey,
    @Phoney = @Phonel,
    @Emailly = @Emaill,
    @LocationName = @LocationNamey,
    @LocationID = @L_ID OUTPUT
    if @L_ID IS NULL 
    BEGIN
        PRINT 'Hey...@L_ID is NULL and that is not good'
        RAISERROR ('@L_ID cannot be NULL', 11, 1)
        RETURN 
    END

    BEGIN TRAN T1
	INSERT INTO tblJob(LocID, Charge, JobDesc)
	VALUES (@L_ID, @Chargey, @JobDescribe)
	IF @@ERROR <> 0
		BEGIN
			ROLLBACK TRAN T1
		END
	ELSE
		COMMIT TRAN T1
go

