
CREATE PROCEDURE uspNewOrder
@FN varchar(20),
@LN varchar(20),
@DOB date,
@P varchar(50),
@Odate date,
@Q int
AS
	DECLARE @C_ID INT, @P_ID INT

	EXEC GetCustID
	@F = @FN,
	@L = @LN,
	@DOB = @DOB,
	@CustID = @C_ID output
	EXEC GetProdID
	@ProName = @P,
	@ProdID = @P_ID output
	
	INSERT INTO tblORDER(ProductID,CustomerID,OrderDate,Quantity)
	VALUES(@P_ID,@C_ID,@Odate,@Q)
go

