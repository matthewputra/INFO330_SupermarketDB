CREATE PROCEDURE GetRatingID
@ratingName VARCHAR(50),
@RatingID INT OUTPUT
AS
SET @RatingID = (SELECT ratingID 
			FROM tblRating
			WHERE ratingName = @ratingName)
go

