--1）
CREATE PROCEDURE GetCustID
@F varchar(20),
@L varchar(20),
@DOB date,
@CustID int out
AS
	SET @CustID = (SELECT CustomerID FROM tblCUSTOMER WHERE CustFname = @F AND CustLname = @L AND CustDOB = @DOB)
go

