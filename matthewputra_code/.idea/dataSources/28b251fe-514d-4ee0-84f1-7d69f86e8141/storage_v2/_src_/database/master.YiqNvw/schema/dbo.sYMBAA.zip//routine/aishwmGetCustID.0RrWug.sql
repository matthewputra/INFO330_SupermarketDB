CREATE PROCEDURE aishwmGetCustID
    @Fname VARCHAR(50),
    @Lname VARCHAR(50),
    @Birthy Date,
    @C_ID INT OUTPUT
    AS
    SET @C_ID = (
        SELECT CustomerID
        FROM tblCUSTOMER
        WHERE CustFName = @Fname
        AND CustLName = @Lname
        AND CustBirthDate = @Birthy
        )
go

