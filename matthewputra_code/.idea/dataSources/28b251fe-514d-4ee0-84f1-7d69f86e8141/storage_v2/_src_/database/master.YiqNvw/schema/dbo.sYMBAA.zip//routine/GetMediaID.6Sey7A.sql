-- Gets MediaID given MediaName
CREATE PROCEDURE GetMediaID
@MediaName varchar(75),
@MediaID INT OUTPUT
AS
SET @MediaID = (
	SELECT MediaID FROM tblMEDIA
	WHERE MediaName = @MediaName
)
go

