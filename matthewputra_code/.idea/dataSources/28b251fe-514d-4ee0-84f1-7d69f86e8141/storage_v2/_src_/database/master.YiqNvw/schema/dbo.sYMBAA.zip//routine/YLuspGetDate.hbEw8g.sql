CREATE PROCEDURE YLuspGetDate @NumberOfDays INT
AS
SELECT GetDate() - @NumberOfDays
go

