
-------------------------------------------------------------
-- NESTED STORED PROCEDURE GET CompanyID
CREATE PROCEDURE GET_CompanyID
@Companyname VARCHAR(50),
@CID INT OUTPUT
AS 

SET @CID = (SELECT CompanyID
            FROM tblCOMPANY
            WHERE CompanyName = @Companyname)
go

