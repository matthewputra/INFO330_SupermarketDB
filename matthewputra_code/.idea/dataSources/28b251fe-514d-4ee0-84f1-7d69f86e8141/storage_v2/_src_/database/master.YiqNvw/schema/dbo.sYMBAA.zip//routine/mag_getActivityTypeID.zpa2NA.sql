
-- Stored procedure for getting activitytype ID
Create Procedure mag_getActivityTypeID
@AT_N varchar(50),
@AT_ID Int Output
As
	Set @AT_ID = (Select ActivityTypeID from tblACTIVITY_TYPE
				 Where ActivityTypeName = @AT_N)
go

