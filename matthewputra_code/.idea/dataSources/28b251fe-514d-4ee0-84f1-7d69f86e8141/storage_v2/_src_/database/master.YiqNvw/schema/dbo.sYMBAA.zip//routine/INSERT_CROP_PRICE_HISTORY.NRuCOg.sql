
------------------------------------------------------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT CROP PRICE HISTORY 
CREATE PROCEDURE INSERT_CROP_PRICE_HISTORY
@Price MONEY,
@Begin_Date DATE,
@C_Name VARCHAR(50)
AS 

DECLARE @C_ID INT

-- EXEC GET CropID
EXEC GET_CropID
@Cropname = @C_Name,
@CID = @C_ID OUTPUT

IF @C_ID IS NULL
    BEGIN
        PRINT('@C_ID is NULL, it cannot be null')
        RAISERROR('@C_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblCROP_PRICE_HISTORY (CropPricePerPound, CropHistoryBeginDate, CropID)
    VALUES (@Price, @Begin_Date, @C_ID)

    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

