-- Gets CampaignID given CampaignName
CREATE PROCEDURE GetCampaignID
@C_Name varchar(75),
@C_ID INT OUTPUT
AS
SET @C_ID = (
	SELECT CampaignID FROM tblCAMPAIGN
	WHERE CampaignName = @C_Name
)
go

