
/*
4. Write the code to enforce the business rule: 
"Employees younger than 21 cannot participate in tasks with any tool type ‘Land Mauler’. "
*/
 
CREATE FUNCTION fn_NoMaulerUnder21()
RETURNS INT
AS
BEGIN
DECLARE @Ret INT = 0
	IF EXISTS(SELECT *
			FROM tblEMPLOYEE E
			JOIN tblEMPLOYEE_SKILL ES ON E.EmpID = ES.EmpID
			JOIN tblCUST_JOB_TASK CJT ON ES.EmpSkillID = CJT.EmpSkillID
			JOIN tblTool T ON CJT.ToolID = T.ToolID
			JOIN tblToolType TT ON T.ToolTypeID = TT.ToolTypeID
			WHERE TT.ToolTypeName = 'Land Mauler'
			AND E.EmpBirthDate > DATEADD(year, -21, GETDATE()))

			BEGIN
				SET @Ret = 1
			END
RETURN @Ret
END
go

