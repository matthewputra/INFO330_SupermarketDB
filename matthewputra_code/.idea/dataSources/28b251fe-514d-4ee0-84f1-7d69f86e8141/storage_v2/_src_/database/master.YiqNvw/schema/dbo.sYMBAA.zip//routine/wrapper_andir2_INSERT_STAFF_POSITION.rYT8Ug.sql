
CREATE PROCEDURE wrapper_andir2_INSERT_STAFF_POSITION
@RUN INT
AS

DECLARE @FirstName Varchar(60), @LastName varchar(60), @DOB Date, @Pos varchar(50), @Dept varchar(75), @BDate Date, @EDate Date

DECLARE @StaffRowCount 	INT = (SELECT COUNT(*) FROM tblCUSTOMER)
DECLARE @PositionRowCount 	INT = (SELECT COUNT(*) FROM tblPOSITION)
DECLARE @DepartmentRowCount INT = (SELECT COUNT(*) FROM tblDEPARTMENT)
DECLARE @Staff_PK INT, @Position_PK INT, @Ddepartment_PK INT

WHILE @RUN > 0
BEGIN
SET @Staff_PK 	= (SELECT RAND() * @StaffRowCount + 1)
SET @Position_PK 	= (SELECT RAND() * @PositionRowCount + 1)
SET @Ddepartment_PK = (SELECT RAND() * @DepartmentRowCount + 1)

SET @FirstName = (SELECT StaffFname FROM tblSTAFF WHERE StaffID = @Staff_PK)
SET @LastName  = (SELECT StaffLname FROM tblSTAFF WHERE StaffID = @Staff_PK)
SET @DOB 	 = (SELECT StaffBirth FROM tblSTAFF WHERE StaffID = @Staff_PK)
SET @Pos  	 = (SELECT PositionName FROM tblPOSITION WHERE PositionID = @Position_PK)
SET @Dept 	 = (SELECT DeptName FROM tblDEPARTMENT WHERE DeptID = @Ddepartment_PK)

SET @BDate = (SELECT GetDate() - @Staff_PK)

SET @EDate = (SELECT GetDate() - @Staff_PK)

EXEC andir2_INSERT_STAFF_POSITION
@DepName		= @Dept,
@StaffFirstName 	= @FirstName,
@StaffLastName	= @LastName,
@StaffBirthday	= @DOB,
@PosName		= @Pos,
@BeginDate		= @BDate,
@EndDate		= @EDate
PRINT @RUN
SET @RUN = @RUN-1
END
go

