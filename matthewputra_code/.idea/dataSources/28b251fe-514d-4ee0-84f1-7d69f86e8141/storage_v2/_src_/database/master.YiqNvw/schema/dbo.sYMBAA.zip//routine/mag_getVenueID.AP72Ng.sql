
-- Stored procedure for getting the id value of a venue
Create Procedure mag_getVenueID
@Cru_N varchar(50),
@Cru_C Int,
@Cru_MD Datetime,
@V_N varchar(50),
@V_Capac Int,
@V_ID Int Output
As

	Declare @Cruise_ID Int

	Execute mag_getCruiseShipID
		@C_N = @Cru_N,
		@Capac = @Cru_C,
		@M_D = @Cru_MD,
		@C_ID = @Cruise_ID Output

	Set @V_ID = (Select VenueID
				From tblVenues
				Where VenueName = @V_N
					And Capacity = @V_Capac
					And CruiseshipID = @Cruise_ID)
go

