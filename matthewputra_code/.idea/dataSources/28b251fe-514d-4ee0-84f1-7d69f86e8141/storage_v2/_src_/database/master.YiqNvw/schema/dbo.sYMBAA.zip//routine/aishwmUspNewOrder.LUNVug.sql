CREATE PROCEDURE aishwmUspNewOrder
    @First VARCHAR(50),
    @Last VARCHAR(50),
    @Birth DATE,
    @PName VARCHAR(50),
    @Quant INT,
    @OrdDate DATE
    AS
    DECLARE @Prod_ID INT, @CustID INT

    EXEC aishwmGetProdID
        @ProdName = @PName,
        @P_ID = @Prod_ID OUTPUT

    EXEC aishwmGetCustID
        @FName = @First,
        @Lname= @Last,
        @Birthy= @Birth,
        @C_ID = @CustID OUTPUT
    BEGIN TRAN T1
        INSERT INTO tblORDER (ProductID, CustomerID, OrderDate, Quantity)
        VALUES (@Prod_ID, @CustID, @OrdDate, @Quant)
    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE
        COMMIT TRAN T1
go

