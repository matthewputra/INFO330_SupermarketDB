CREATE PROCEDURE GetProdID
@ProName varchar(50),
@ProdID int out
AS
	SET @ProdID = (SELECT ProductID FROM tblPRODUCT WHERE ProductName = @ProName)
go

