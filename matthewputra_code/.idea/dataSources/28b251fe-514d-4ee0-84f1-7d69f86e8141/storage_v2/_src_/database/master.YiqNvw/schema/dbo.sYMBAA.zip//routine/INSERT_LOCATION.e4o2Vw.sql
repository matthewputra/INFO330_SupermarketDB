
------------------------------------------------------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT LOCATION
CREATE PROCEDURE INSERT_LOCATION
@C_Name VARCHAR(50),
@L_Name VARCHAR(50),
@Street VARCHAR(50),
@City VARCHAR(20),
@State VARCHAR(2),
@Zip INT
AS

DECLARE @C_ID INT 

-- EXEC GET CompanyID 
EXEC GET_CompanyID
@Companyname = @C_Name,
@CID = @C_ID OUTPUT

IF @C_ID IS NULL
    BEGIN
        PRINT('@C_ID is NULL, it cannot be null')
        RAISERROR('@C_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblLOCATION (LocationName, LocationStreet, LocationCity, LocationState, LocationZip, CompanyID)
    VALUES (@L_Name, @Street, @City, @State, @Zip, @C_ID)

    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

