
CREATE PROCEDURE kel28_GetPositionID
@PosName VARCHAR(50),
@PosID INT OUTPUT
AS 
SET @PosID = (SELECT PositionID FROM tblPOSITION WHERE PositionName = @PosName)
go

