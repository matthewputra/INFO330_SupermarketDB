

--Insert New Provider
CREATE PROCEDURE xz67_GetProvTypeID
@ProvTName VARCHAR(60),
@ProvTID INT OUTPUT 
AS
SET @ProvTID = (SELECT ProvTypeID FROM tblProviderType
WHERE ProvTypeName = @ProvTName)
go

