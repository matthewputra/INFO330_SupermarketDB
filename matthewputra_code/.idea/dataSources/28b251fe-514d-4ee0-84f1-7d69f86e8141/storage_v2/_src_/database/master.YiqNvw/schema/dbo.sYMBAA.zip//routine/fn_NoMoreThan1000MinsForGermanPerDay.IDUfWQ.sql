CREATE FUNCTION fn_NoMoreThan1000MinsForGermanPerDay()
RETURNS INT
AS
BEGIN   
    DECLARE @RET INT = 0
    IF EXISTS (
        SELECT *
        FROM tblStream  S
            JOIN tblCountry C   ON C.CountryID = S.CountryID
            JOIN tblRecording R ON S.RecordingID = R.RecordingID
        WHERE CountryName = 'Germany'
        GROUP BY S.RecordingID
        HAVING SUM(RecordingLength) > 2000
    )
    BEGIN
        SET @RET = 1
    END
RETURN @RET
END
go

