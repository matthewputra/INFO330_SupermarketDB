
--****************************************************************************************************************************************************************--
-- SYNTHETIC TRANSACTIONS (WRAPPERS )
--****************************************************************************************************************************************************************--
-- WRAPPER FOR tblCOMPANY
CREATE PROCEDURE WRAPPER_INSERT_COMPANY
AS 

-- DECLARE VARIABLES 
DECLARE @CName VARCHAR(100)   -- CompanyName 
DECLARE @CTName VARCHAR(50)  -- CompanyTypeName

DECLARE @Company_ROW INT     -- Companies Table ROW  
DECLARE @CompanyType_PK INT  -- Company Type PK 

SET @Company_ROW = (SELECT COUNT(*) FROM companies)

-- WHILE LOOP
WHILE @Company_Row > 0 
    BEGIN 

    SET @CompanyType_PK = (SELECT(Rand() * 5)) + 1

    SET @CName = (SELECT CompanyName
                    FROM companies
                    WHERE CompanyPK = @Company_ROW)

    SET @CTName = (SELECT CompanyTypeName
                    FROM tblCOMPANY_TYPE
                    WHERE CompanyTypeID = @CompanyType_PK)

    DELETE FROM companies WHERE CompanyPK = @Company_ROW
    SET @Company_ROW = @Company_Row - 1

    -- EXEC BASED STORED PROCEDURE
    EXEC INSERT_COMPANY
    @C_Name = @CName,
    @CT_Name = @CTName
    
    END
go

