CREATE PROCEDURE aishwmGetProdID
    @ProdName VARCHAR(50),
    @P_ID INT OUTPUT
    AS
    SET @P_ID = (
        SELECT ProductID
        FROM tblProduct
        WHERE ProductName = @ProdName
        )
go

