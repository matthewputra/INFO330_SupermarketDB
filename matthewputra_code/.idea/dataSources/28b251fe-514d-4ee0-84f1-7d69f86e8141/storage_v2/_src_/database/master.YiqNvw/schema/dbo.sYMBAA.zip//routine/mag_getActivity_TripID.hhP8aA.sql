
Create Procedure mag_getActivity_TripID
@S_T	Datetime,
@E_T	Datetime,
@Ac_Na	varchar(50),
@Ca		Int,
@St_D	Date,
@En_D	Date,
@AT_ID	Int Output
As

Declare @ACT_ID Int, @TR_ID Int

	Execute mag_getActivityID
		@A_N = @Ac_Na,
		@C = @Ca,
		@A_ID = @ACT_ID Output
	Execute mag_getTripID
		@S_D = @St_D,
		@E_D = @En_D,
		@T_ID = @TR_ID Output

	Set @AT_ID = (Select ActivityTripID
				 From tblACTIVITY_TRIP
				Where TripID = @TR_ID
				And ActivityID = @Act_ID
				And StartTime = @S_T
				And EndTime = @E_T)
go

