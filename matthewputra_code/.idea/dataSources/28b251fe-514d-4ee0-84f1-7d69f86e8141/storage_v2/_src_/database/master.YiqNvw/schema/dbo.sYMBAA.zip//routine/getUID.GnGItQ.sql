
CREATE PROCEDURE getUID
@uname varchar(50),
@bname varchar(50),
@uid INT OUTPUT
AS
SET @uid = (SELECT U.UnitID
			FROM UNIT U
				JOIN BUILDING B
					ON B.BuildingID = U.BuildingID
			WHERE B.Bname = @bname
				AND U.Uname = @uname)
go

