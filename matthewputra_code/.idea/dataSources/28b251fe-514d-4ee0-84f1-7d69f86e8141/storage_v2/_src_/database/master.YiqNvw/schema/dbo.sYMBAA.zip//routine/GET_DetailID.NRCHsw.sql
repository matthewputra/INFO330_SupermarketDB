
-------------------------------------------------------------
-- NESTED STORED PROCEDURE GET DetailID 
CREATE PROCEDURE GET_DetailID
@Detailname VARCHAR(50),
@DID INT OUTPUT
AS 

SET @DID = (SELECT DetailID
            FROM tblDETAIL
            WHERE DetailName = @Detailname)
go

