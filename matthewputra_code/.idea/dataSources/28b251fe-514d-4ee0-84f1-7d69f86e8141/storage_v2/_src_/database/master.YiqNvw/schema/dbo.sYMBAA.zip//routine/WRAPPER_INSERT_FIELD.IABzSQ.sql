CREATE PROCEDURE WRAPPER_INSERT_FIELD

AS 
-- DECLARE VARIABLES 
DECLARE @FF VARCHAR(20) -- Grower First Name
DECLARE @FL VARCHAR(20) -- Grower Last Name
DECLARE @FD DATE -- Grower Birth Date
DECLARE @FST VARCHAR(50)     -- Field Street 
DECLARE @FC VARCHAR(20)    -- Field City
DECLARE @FS VARCHAR(2)   -- Field State
DECLARE @FZ INT   -- Field Zip
DECLARE @AC INT -- Field Acres
DECLARE @GrowerCombinedName VARCHAR(50) -- Field name from concatenating grower information

DECLARE @GROWER_ROW INT -- Grower/owner of field
DECLARE @CURRENT INT -- Current field of grower being inserted
DECLARE @QUANTITY INT -- Amount of fields one grower will have
DECLARE @FIELD_LOCATION_ROW INT -- Getting the field location from external table

SET @GROWER_ROW = (SELECT COUNT(*) FROM tblGROWER)
SET @FIELD_LOCATION_ROW = (SELECT COUNT(*) FROM Field_Locations)

--------------------------------------------------
-- WHILE LOOP 
WHILE @GROWER_ROW > 0 
    BEGIN 
		SET @QUANTITY = (SELECT(Rand() * 5)) + 1
		SET @CURRENT = 0

        SET @FF = (SELECT GrowerFName
                    FROM tblGROWER
                    WHERE GrowerID = @GROWER_ROW)

		SET @FL = (SELECT GrowerLName
                    FROM tblGROWER
                    WHERE GrowerID = @GROWER_ROW)

		SET @FD = (SELECT GrowerBirthDate
					FROM tblGROWER
					WHERE GrowerID = @GROWER_ROW)

        
		WHILE @CURRENT < @QUANTITY
			BEGIN
				SET @AC = (SELECT RAND() * 150) + 50

				SET @GrowerCombinedName = Concat(@FF, ' ', @FL, ' ', @QUANTITY)

				SET @FST = (SELECT FieldStreet
                    FROM Field_Locations
                    WHERE FieldPK = @FIELD_LOCATION_ROW)
				
				SET @FC = (SELECT FieldCity
                    FROM Field_Locations
                    WHERE FieldPK = @FIELD_LOCATION_ROW)

				SET @FS = (SELECT FieldState
                    FROM Field_Locations
                    WHERE FieldPK = @FIELD_LOCATION_ROW)

		        SET @FZ = (SELECT FieldZip
					FROM Field_Locations
                    WHERE FieldPK = @FIELD_LOCATION_ROW)
    
				EXEC INSERT_FIELD
				@First_Name = @FF,
				@Last_Name = @FL,
				@DateOfBirth = @FD,
				@F_Name = @GrowerCombinedName,
				@Acres = @AC,
				@Street = @FST,
				@City = @FC,
				@State = @FS,
				@Zip = @FZ

				DELETE FROM Field_Locations WHERE FieldPK = @FIELD_LOCATION_ROW
				SET @FIELD_LOCATION_ROW = @FIELD_LOCATION_ROW - 1
				SET @CURRENT = @CURRENT + 1
			END

        -- EXEC BASED PROCEDURE 
        SET @GROWER_ROW = @GROWER_ROW - 1
        PRINT @GROWER_ROW 
    END
go

