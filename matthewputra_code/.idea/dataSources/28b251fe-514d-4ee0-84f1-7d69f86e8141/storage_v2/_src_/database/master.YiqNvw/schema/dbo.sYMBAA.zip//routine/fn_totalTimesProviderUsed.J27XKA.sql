
-- Number of times a provider was used all together
CREATE FUNCTION fn_totalTimesProviderUsed(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = (
        SELECT COUNT(*) FROM
        tblServiceJobProvider
        WHERE ProvID = @PK
    )
    RETURN @Ret
END
go

