
--**********************************************************--
-- NESTED STORED PROCEDURE GET GrowerID
--**********************************************************--
CREATE PROCEDURE GET_GrowerID
@Fname VARCHAR(30),
@Lname VARCHAR(30),
@BirthDate DATE,
@GID INT OUTPUT
AS 

SET @GID = (SELECT GrowerID
            FROM tblGROWER
            WHERE GrowerFName = @Fname
            AND GrowerLName = @Lname
            AND GrowerBirthDate = @BirthDate)
go

