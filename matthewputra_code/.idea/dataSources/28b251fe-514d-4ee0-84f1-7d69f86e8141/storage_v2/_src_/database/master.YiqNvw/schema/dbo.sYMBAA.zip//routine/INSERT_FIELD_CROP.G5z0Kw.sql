
-------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT FIELD CROP 
CREATE PROCEDURE INSERT_FIELD_CROP
@BeginD DATE,
@Qty INT,
@Field_N VARCHAR(50),
@F_Street VARCHAR(50),
@F_City VARCHAR(20),
@F_State VARCHAR(2),
@F_Zip INT,
@Crop_N VARCHAR(50)
AS

DECLARE @F_ID INT, @C_ID INT

-- EXEC GET FieldID
EXEC GET_FieldID
@Fieldname = Field_N,
@Street = @F_Street,
@City = @F_City,
@State = @F_State,
@Zip = @F_Zip,
@FID = @F_ID OUTPUT

IF @F_ID IS NULL
    BEGIN
        PRINT('@F_ID is NULL, it cannot be null')
        RAISERROR('@F_ID is NULL',11,1)
        RETURN
    END

-- EXEC GET CropID
EXEC GET_CropID
@Cropname = @Crop_N,
@CID = @C_ID OUTPUT

IF @C_ID IS NULL
    BEGIN
        PRINT('@C_ID is NULL, it cannot be null')
        RAISERROR('@C_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblFIELD_CROP (FieldCropBeginDate, FieldCropQuantity, FieldID, CropID)
    VALUES (@BeginD, @Qty, @F_ID, @C_ID)
    
    IF @@ERROR <> 0 
        BEGIN 
            ROLLBACK TRAN T1
        END
    ELSE
        BEGIN
            COMMIT TRAN T1
        END
go

