CREATE PROCEDURE newMeasurable
@MeasurementName varchar(50),
@Mname varchar(50),
@Mvalue INT
AS
DECLARE @M_ID INT

EXEC getMeasurementUnitID
@MU_Name = @MeasurementName,
@MeasurementUnitID = @M_ID OUTPUT
IF @M_ID IS NULL
	BEGIN
	RAISERROR('Measurement Unit ID cannot be null', 11, 1)
	RETURN
	END

BEGIN TRAN MT1
INSERT INTO tblMEASURABLE (MeasureableName, MeasureableUnitID, MeasureableValue)
VALUES (@Mname, @M_ID, @Mvalue)
IF @@ERROR <> 0
	BEGIN
		PRINT 'Measurable Insertion Error'
	END
ELSE
	COMMIT TRAN MT1
go

