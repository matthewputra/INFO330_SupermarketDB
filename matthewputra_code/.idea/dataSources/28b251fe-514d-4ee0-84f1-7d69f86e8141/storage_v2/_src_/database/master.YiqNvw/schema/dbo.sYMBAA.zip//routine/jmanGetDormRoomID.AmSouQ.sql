CREATE PROCEDURE jmanGetDormRoomID
@DormRoomNumber varchar(50),
@D_ID INT OUTPUT 
AS
SET @D_ID = (SELECT DormRoomID 
			FROM tblDORMROOM 
			WHERE DormRoomNumber = @DormRoomNumber)
go

