CREATE PROCEDURE pwinebr_InsertOrder
@Fname varchar(20),
@Lname varchar(20),
@BirthDate DATE,
@ProdName varchar(50),
@Quant INT,
@OrdDate DATE
AS

DECLARE @C_ID INT, @P_ID INT

EXEC pwinebr_getCustID
@Firsty = @Fname,
@Lasty = @Lname,
@Birthy = @BirthDate,
@CID = @C_ID OUTPUT

IF @C_ID IS NULL
BEGIN
    THROW 51000, '@C_ID is null', 1;
END

EXEC pwinebr_getProdID
@Proddy = @Prodname,
@PID = @P_ID OUTPUT

IF @P_ID IS NULL
BEGIN
    THROW 51000, '@P_ID is null', 1;
END

BEGIN TRAN T1
INSERT INTO tblOrder (CustomerID, ProductID, Quantity, OrderDate)
VALUES (@C_ID, @P_ID, @Quant, @OrdDate)
IF @@ERROR <> 0
BEGIN
    ROLLBACK TRAN T1
END
ELSE
    COMMIT TRAN T1

go

