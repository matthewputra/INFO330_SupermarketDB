
-- People in the North America can’t stream recordings in Genre 'Blues' for more than 500 hours in total per day on the platform Spotify - Wayne
CREATE FUNCTION fn_NoMoreThan500Hours_NorthAmerica_BluesSpotify()
RETURNS INT
AS
BEGIN   
    DECLARE @RET INT = 0
    IF EXISTS (
        SELECT * 
        FROM   tblStream S
            JOIN tblRecording R   ON S.RecordingID = R.RecordingID
            JOIN tblGenre     G   ON R.GenreID     = G.GenreID
            JOIN tblCountry   C   ON C.CountryID   = S.CountryID
            JOIN tblRegion    RE  ON RE.RegionID   = C.RegionID
            JOIN tblPlatform  P   ON P.PlatformID  = S.PlatformID
        WHERE RegionName = 'North America'
        AND   GenreName  = 'Blues'
        AND   PlatformName = 'Spotify'
        GROUP BY S.RecordingID
        HAVING SUM(RecordingLength) > 500 * 60
    )
    BEGIN
        SET @RET = 1
    END
RETURN @RET
END
go

