
-- Jimmy
-- A recording cannot be released before the artist was born
CREATE FUNCTION fn_NoRecordingBeforeBirth()
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (
		SELECT *
		FROM tblArtist A
			JOIN tblGroupArtist GA ON A.ArtistID = GA.ArtistID
			JOIN tblGroup G ON GA.GroupID = G.GroupID
			JOIN tblRecordingGroup RG ON G.GroupID = RG.GroupID
			JOIN tblRecording R ON RG.RecordingID = R.RecordingID
		WHERE DateOfBirth > RecordingDate
	)
	BEGIN
		SET @Ret = 1
	END
	RETURN @Ret
END
go

