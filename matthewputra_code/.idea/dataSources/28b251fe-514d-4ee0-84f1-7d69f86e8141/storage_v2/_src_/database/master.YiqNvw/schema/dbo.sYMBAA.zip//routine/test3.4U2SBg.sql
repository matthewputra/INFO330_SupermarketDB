CREATE PROCEDURE test3
--exist_student_class
@RDate DATE,
@RFEE INT,
@CourseN varchar(40),
@QuarterN varchar(40),
@CYear INT,
@Sec varchar(20),
@StudentNet INT
AS

DECLARE @Q_ID INT, @CO_ID INT, @C_ID INT, @S_ID INT
--DECLARE @CO_ID INT
--DECLARE @C_ID INT 
--DECLARE @S_ID INT

SET @Q_ID = (SELECT QuarterID
FROM tblQUARTER
WHERE QuarterName = @QuarterN)

SET @CO_ID = (SELECT CourseID
FROM tblCOURSE
WHERE CourseName = @CourseN)

SET @C_ID = (SELECT ClassID
FROM tblCLASS
WHERE CourseID = @CO_ID
AND QuarterID = @Q_ID
AND SECTION = @Sec
AND [Year] = @CYear)

SET @S_ID = (SELECT StudentID
FROM tblSTUDENT
WHERE StudentNetID = @StudentNet)

INSERT INTO tblCLASS_LIST(ClassID, StudentID, RegistrationDate, RegistrationFee)
VALUES(@C_ID, @S_ID, @RDate, @RFee)
go

