CREATE PROCEDURE dma150GetProdID
@ProdName varchar(50),
@Prod_ID INT OUTPUT
AS
SET @Prod_ID = (SELECT ProductID 
				FROM tblPRODUCT 
				WHERE ProductName = @ProdName)
go

