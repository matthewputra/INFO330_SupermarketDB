CREATE PROCEDURE INSERT_STAFF
@StaffFname varchar(20),
@StaffLname varchar(20),
@Gender varchar(10),
@BirthDate date
AS

BEGIN TRAN P1
INSERT INTO STAFF(StaffFname, StaffLname, Gender, BirthDate)
VALUES(@StaffFname, @StaffLname, @Gender, @BirthDate)
COMMIT TRAN P1
go

