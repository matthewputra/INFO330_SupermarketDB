--DROP PROCEDURE andir2_GetStaffID
CREATE PROCEDURE andir2_GetStaffID
@StaffLName 	varchar(60),
@StaffFName 	varchar(60),
@StaffBday	date,
@StaffID	INT OUTPUT
AS
	
SET @StaffID = (SELECT StaffID From tblSTAFF WHERE StaffFName = @StaffFName AND StaffLName = @StaffLName AND StaffBirth = @StaffBday)
go

