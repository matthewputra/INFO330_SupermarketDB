
/*
2. Write the code to CREATE a stored procedure to insert a new row into EMPLOYEE_POSITION:
	- Takes in four parameters: Position Name, Employee’s first name, last name and birthdate
	- Uses variables to look-up required FK values
	- Inserts a new row in a single explicit transaction (assume IDENTITY function enabled)
*/
 
CREATE PROCEDURE addEmployeePosition
@Fname varchar(20),
@Lname varchar(20),
@Birth DATE,
@PosName varchar(20),
@Begin DATE
AS

DECLARE @E_ID INT, @P_ID INT
SET @E_ID = 
	(SELECT EmpID
	FROM tblEMPLOYEE
	WHERE EmpFname = @Fname
	AND EmpLname = @Lname
	AND EmpBirthDate = @Birth)
SET @P_ID = 
	(SELECT PositionID
	FROM tblPOSITION
	WHERE PositionName = @PosName)

BEGIN TRAN T1
INSERT INTO tblEMPLOYEE_POSITION(EmpID, PositionID, BeginDate)
VALUES (@E_ID, @P_ID , @Begin)
COMMIT TRAN T1
go

