
CREATE FUNCTION fn_NoLexBlazerInNewYork()
RETURNS INT
AS 
BEGIN
	DECLARE @RET INT = 0
		IF EXISTS (SELECT *
				   FROM tblEMPLOYEE E
						JOIN tblEMPLOYEE_POSITION EP ON E.EmployeeID = EP.EmployeeID
						JOIN tblITEM_ORDER IO ON EP.EmployeePositionID = IO.EmployeePositionID
						JOIN tblITEM I ON IO.ItemID = I.ItemID
				   WHERE E.State = 'NY'
						AND I.ItemName = 'Lexia Blazer')
		BEGIN
			SET @RET = 1
		END
	RETURN @RET
END
go

