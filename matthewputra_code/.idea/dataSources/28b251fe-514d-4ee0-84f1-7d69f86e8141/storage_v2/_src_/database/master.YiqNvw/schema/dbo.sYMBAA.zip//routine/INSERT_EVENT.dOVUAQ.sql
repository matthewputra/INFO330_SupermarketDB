
-------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT EVENT 
CREATE PROCEDURE INSERT_EVENT
@ET_Name VARCHAR(50),
@E_Name VARCHAR(50)
AS 

DECLARE @ET_ID INT 

-- EXEC GET EventTypeID
EXEC GET_EventTypeID
@ETname = @ET_Name,
@ETID = @ET_ID OUTPUT

IF @ET_ID IS NULL
    BEGIN
        PRINT('@ET_ID is NULL, it cannot be null')
        RAISERROR('@ET_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblEVENT (EventName, EventTypeID)
    VALUES (@E_Name, @ET_ID)

    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

