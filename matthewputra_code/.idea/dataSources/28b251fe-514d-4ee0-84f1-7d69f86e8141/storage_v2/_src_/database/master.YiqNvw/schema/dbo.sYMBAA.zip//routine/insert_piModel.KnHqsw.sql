--Model
Create procedure insert_piModel 
@ManufacturerID int, 
@Model varchar (50),
@year int
AS
Insert into piModel (model, year)
values( 
@Model,
@year)
go

