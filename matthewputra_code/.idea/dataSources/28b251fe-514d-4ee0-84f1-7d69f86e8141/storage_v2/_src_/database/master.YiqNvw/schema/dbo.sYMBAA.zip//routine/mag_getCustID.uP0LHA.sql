
Create Procedure mag_getCustID
@C_F varchar(50),
@C_L varchar(50),
@DOB Date,
@C_ID Int Output

As

Set @C_ID = (Select CustID
From tblCUSTOMER
Where CustFname = @C_F
And CustLName = @C_L
And CustDOB = @DOB)

go

