CREATE PROCEDURE uspINSERTFEATURE
@FeatureName varchar(20),
@BrandName varchar(20)
AS
DECLARE @B_ID INT
SELECT @B_ID = (
    SELECT BrandID
    FROM tblBRAND
    WHERE BrandName = @BrandName
)
BEGIN TRAN T1
INSERT INTO tblFEATURE
(BrandID, FeatureName)
VALUES (@B_ID, @FeatureName)
COMMIT TRAN T1
go

