
--****************************************************************************************************************************************************************--
-- WRAPPER FOR INSERT GROWER COMPANY
CREATE PROCEDURE WRAPPER_INSERT_GROWER_COMPANY
@RUN INT
AS 

DECLARE @FN VARCHAR(30)  -- FirstName
DECLARE @LN VARCHAR(30)  -- LastName
DECLARE @BD DATE         -- GrowerBirthDate
DECLARE @CN VARCHAR(100)  -- CompanyName

DECLARE @Grower_PK INT
DECLARE @Company_PK INT

--------------------------------------------------
-- WHILE LOOP 
WHILE @RUN > 0 
    BEGIN
        SET @Grower_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblGROWER))
        SET @Company_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblCOMPANY))

        IF @Grower_PK = 0
            BEGIN
                SET @Grower_PK = 1
            END

        IF @Company_PK = 0
            BEGIN
                SET @Company_PK = 1
            END

        SET @FN = (SELECT GrowerFName
                    FROM tblGROWER
                    WHERE GrowerID = @Grower_PK)

        SET @LN = (SELECT GrowerLName
                    FROM tblGROWER
                    WHERE GrowerID = @Grower_PK)

        SET @BD = (SELECT GrowerBirthDate
                    FROM tblGROWER
                    WHERE GrowerID = @Grower_PK)

        SET @CN = (SELECT CompanyName
                    FROM tblCOMPANY
                    WHERE CompanyID = @Company_PK)
        
        EXEC INSERT_GROWER_COMPANY
        @F_n = @FN,
        @L_n = @LN,
        @DateOfBirth = @BD,
        @Company_Name = @CN

        SET @RUN = @RUN - 1
    END
go

