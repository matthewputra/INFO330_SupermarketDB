--SessionDuration - Cecilia
--EndTime - BeginTime
--Goes in tblSESSION

CREATE FUNCTION SessionDuration(@SessionID INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	SET @RET = (SELECT SessionEndTime - SessionBeginTime
				FROM tblSESSION S
				WHERE S.SessionID = @SessionID
				)
	RETURN @RET
END
go

