CREATE PROCEDURE CatchDateERROR
	@BeginDate Date
	,@EndDate Date
AS
	BEGIN
		BEGIN TRY
			IF @BeginDate > @EndDate
				RAISERROR('END DATE PRECEDES BEGIN DATE', 11, 1)
			SELECT 'Summer Vacation Date' as Descr
			SELECT @BeginDate 
			SELECT @EndDate
		END TRY
		BEGIN CATCH
			DECLARE @ErrorMessage	nvarchar(1000) = ERROR_MESSAGE()
			DECLARE @ErrorSeverity	INT = ERROR_SEVERITY()
			DECLARE @ErrorState		INT = ERROR_STATE()
			RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState)

		END CATCH	  	
	END;
go

