
create procedure gjoleGetProdID
@ProdName varchar(50),
@ProdID int output
as
set @ProdID = (Select ProductID from tblPRODUCT
				where ProdName = @ProdName)
go

