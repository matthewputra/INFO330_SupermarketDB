
------------------------------------------------------------------------------------------------------------
-- NESTED STORED PROCEDURE GET DetailTypeID
CREATE PROCEDURE GET_DetailTypeID
@DTName VARCHAR(50),
@DTID INT OUTPUT
AS 

SET @DTID = (SELECT DetailTypeID
            FROM tblDETAIL_TYPE
            WHERE DetailTypeName = @DTName)
go

