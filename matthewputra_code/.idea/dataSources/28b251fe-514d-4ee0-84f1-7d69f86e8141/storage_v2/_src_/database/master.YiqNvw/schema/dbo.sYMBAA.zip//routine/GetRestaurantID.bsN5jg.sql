
-- 12) GetRestaurantID(restaurantName, address)
CREATE PROCEDURE GetRestaurantID
@restaurantName VARCHAR(50),
@address VARCHAR(50),
@RestaurantID INT OUTPUT
AS
SET @RestaurantID = (SELECT restaurantID
					FROM tblRestaurant
					WHERE restaurantName = @restaurantName
						AND restaurantAddress = @address)
go

