
-- 1) Creating the stored procedures to get the Unit ID
CREATE PROCEDURE aoesGetUnitID
@UName VARCHAR(20),
@UID INT OUTPUT
AS
SET @UID = (SELECT UnitID FROM tblUNIT
				WHERE UnitName = @UName)
go

