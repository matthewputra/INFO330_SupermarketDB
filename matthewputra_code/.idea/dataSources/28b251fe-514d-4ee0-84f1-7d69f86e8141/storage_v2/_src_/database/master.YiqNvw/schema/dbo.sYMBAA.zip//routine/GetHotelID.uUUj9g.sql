CREATE PROCEDURE GetHotelID
 @Hotel_Name VARCHAR(50),
 @Hotel_Address VARCHAR(50),
 @Hotel_Phone INT,
 @Hotel_ID INT OUTPUT
 AS
 SET @Hotel_ID = (SELECT HotelID FROM tblHotel
	WHERE HotelName = @Hotel_Name
	AND HotelAddress = @Hotel_Address
    AND HotelPhone = @Hotel_Phone)
go

