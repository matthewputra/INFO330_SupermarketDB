CREATE PROCEDURE uspNewHireExistingPositionJasmine
--get StaffID
@Fname varchar(20),
@Lname varchar(20),
@Bdate varchar(20),

--non ID
@BeginDate varchar(20),
@EndDate varchar(20),

--position info
@Pname varchar(20),

--department info
@Dname varchar(20)
AS
    DECLARE @S_ID INT, @P_ID INT, @D_ID INT

SET @S_ID = (SELECT StaffID
            FROM tblSTAFF
            WHERE StaffFName = @Fname
            AND StaffLName = @Lname
            AND StaffBirth = @Bdate
    )

SET @P_ID = ( SELECT PositionID
            FROM tblPosition
            WHERE PositionName = @Pname
    )

SET @D_ID = (SELECT DeptID
            FROM tblDEPARTMENT
            WHERE DeptName = @Dname
    )
INSERT INTO tblstaff_position(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES(@S_ID, @P_ID, @Bdate, @EndDate,@D_ID)
go

