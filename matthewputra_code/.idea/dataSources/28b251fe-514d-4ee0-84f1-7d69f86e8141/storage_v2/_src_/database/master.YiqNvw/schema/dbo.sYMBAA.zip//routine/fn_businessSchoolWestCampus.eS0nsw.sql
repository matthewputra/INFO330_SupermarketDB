CREATE FUNCTION fn_businessSchoolWestCampus()
RETURNS INT
AS
BEGIN
DECLARE @RET INT = 0
IF EXISTS (SELECT * 
			FROM tblSTUDENT S
				JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
				JOIN tblDORMROOM DR ON SD.DormRoomID = DR.DormRoomID
				JOIN tblBUILDING B ON DR.BuildingID = B.BuildingID
				JOIN tblLOCATION L ON B.LocationID = L.LocationID
				JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
				JOIN tblCLASS C ON CL.ClassID = C.ClassID
				JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
				JOIN tblDEPARTMENT D ON CO.DeptID = D.DeptID
				JOIN tblCOLLEGE CE ON D.CollegeID = CE.CollegeID
			WHERE L.LocationName = 'West Campus' 
			AND CL.Grade >= 3.48
			AND CE.CollegeName = 'Business (Foster)'
			GROUP BY(S.StudentID)
			HAVING SUM(CO.Credits) < 20)
	SET @RET = 1
RETURN @RET
END
go

