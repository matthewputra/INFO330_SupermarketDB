CREATE PROCEDURE GetRoomTypeID
 @RoomType_Name VARCHAR(50),
 @RoomType_Descr VARCHAR(50),
 @RoomType_ID INT OUTPUT
 AS
 SET @RoomType_ID = (SELECT RoomTypeID FROM tblRoomType
	WHERE RoomTypeName = @RoomType_Name
	AND RoomTypeDescr = @RoomType_Descr)
go

