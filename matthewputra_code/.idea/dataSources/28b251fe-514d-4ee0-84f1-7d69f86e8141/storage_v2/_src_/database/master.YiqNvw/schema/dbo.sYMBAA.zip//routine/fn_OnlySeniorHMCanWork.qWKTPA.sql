CREATE FUNCTION fn_OnlySeniorHMCanWork()
RETURNS INT
AS 
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS (SELECT *
	FROM EMPLOYEE E
	JOIN EMPLOYEE_SKILL ES ON E.EmpID = ES.EmpID
	JOIN LEVEL L ON ES.LevelID = L.LevelID
	JOIN SKILL S ON ES.SkillID = S.SkillID
	JOIN SKILL_TYPE ST ON S.SkillTypeID = ST.SkillTypeID
	JOIN CUST_JOB_TASK CJT ON ES.EmpSkillID = CJT.EmpSkillID 
	JOIN JOB J ON CJT.JobID = J.JobID
	JOIN JOB_TYPE JT ON J.JobTypeID = JT.JobTypeID
	JOIN EQUIPMENT E ON CJT.EquipID = E.EquipID
	JOIN EQUIPMENT_TYPE ET ON E.EquipTypeID = ET.EquipTypeID
	WHERE J.JobBeginDate > 'November 11, 2021'
	AND JT.JobTypeName = 'high-rise residential'
	AND ET.EquipTypeName = 'hydraulic lift'
	AND ((L.LevelName != 'Senior') OR (ST.SkillTypeName != 'Heavy Machinery'))
	)

	SET @RET = 1
	RETURN @RET
	END
go

