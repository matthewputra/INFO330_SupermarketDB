
-------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT DETAIL
CREATE PROCEDURE INSERT_DETAIL 
@Detail_Name VARCHAR(50),
@Detail_Year INT,
@DT_Name VARCHAR(50)
AS 

DECLARE @DT_ID INT 

-- EXEC GET DetailTypeID
EXEC GET_DetailTypeID
@DTName = @DT_Name,
@DTID = @DT_ID OUTPUT

IF @DT_ID IS NULL
    BEGIN
        PRINT('@DT_ID is NULL, it cannot be null')
        RAISERROR('@DT_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblDETAIL (DetailName, DetailYear, DetailTypeID)
    VALUES (@DT_Name, @Detail_Year, @DT_ID)

    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

