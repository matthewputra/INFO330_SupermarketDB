
-------------------------------------------------------------
-- NESTED STORED PROCEDURE GET EventID
CREATE PROCEDURE GET_EventID
@Eventname VARCHAR(50),
@EID INT OUTPUT
AS

SET @EID = (SELECT EventID
            FROM tblEVENT
            WHERE EventName = @Eventname)
go

