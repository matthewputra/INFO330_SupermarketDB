CREATE PROCEDURE smwest3Registration
@F varchar(20),
@L varchar(20),
@C varchar(50),
@D Date
AS
DECLARE @S_ID INT, @C_ID INT
SET @S_ID = (SELECT StudentID
FROM tblSTUDENT
WHERE FirstName = @F
AND LastName = @L)
go

