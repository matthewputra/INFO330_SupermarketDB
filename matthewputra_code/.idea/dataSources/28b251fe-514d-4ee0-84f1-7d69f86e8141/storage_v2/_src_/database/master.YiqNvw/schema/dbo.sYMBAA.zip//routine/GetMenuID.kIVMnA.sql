
-- 13) GetMenuID(menuName)
CREATE PROCEDURE GetMenuID
@menuName VARCHAR(50),
@menuID INT OUTPUT
AS
SET @menuID = (SELECT menuID
				FROM tblMenu
				WHERE menuName = @menuName)
go

