
CREATE PROCEDURE GetPositionID
@PosName VARCHAR(50),
@POS_ID INT OUTPUT

AS

SET @POS_ID = (SELECT PositionID FROM tblPOSITION
               WHERE PositionName = @PosName)
go

