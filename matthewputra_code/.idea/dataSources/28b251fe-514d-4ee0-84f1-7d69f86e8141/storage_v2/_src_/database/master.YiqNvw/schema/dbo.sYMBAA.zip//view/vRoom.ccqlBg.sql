CREATE -- DROP
VIEW vRoom AS
SELECT RoomNumber,
	   RoomAvailable
FROM tblRoom
go

