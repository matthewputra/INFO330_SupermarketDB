
-- Album type EP should not have more than 5 songs in one album
CREATE FUNCTION fn_NoMoreThanFiveEP()
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (
		SELECT A.AlbumID, COUNT(R.RecordingID) AS NumRecordings
		FROM tblAlbumType AT
			JOIN tblAlbum A ON AT.AlbumTypeID = A.AlbumTypeID
			JOIN tblGroup G ON A.GroupID = G.GroupID
			JOIN tblRecordingGroup RG ON G.GroupID = RG.GroupID
			JOIN tblRecording R ON RG.RecordingID = R.RecordingID
		WHERE AlbumTypeName = 'EP'
		GROUP BY A.AlbumID
		HAVING COUNT(R.RecordingID) > 5
	)
	BEGIN
		SET @Ret = 1
	END
	RETURN @Ret
END
go

