CREATE PROCEDURE swINSERT_tblPRODUCT_TYPE
-- paramters go here
@ProductTypeName varchar(50),
@ProductTypeDesc varchar(500)

AS

-- variables and base code go here

INSERT INTO sw_tblPRODUCT_TYPE (ProdTypeName, ProdTypeDesc)
VALUES (@ProductTypeName, @ProductTypeDesc)
go

