
-------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT EVENT DETAIL FIELD CROP 
CREATE PROCEDURE INSERT_EVENT_DETAIL_FIELD_CROP
@Quantity INT,
@Detail_N VARCHAR(50),
@MEASURE VARCHAR(20),
@Event_BeginD DATE,
@FieldCrop_BeginD DATE,
@Field_Name VARCHAR(50),
@Field_STREET VARCHAR(50),
@Field_CITY VARCHAR(20),
@Field_STATE VARCHAR(2),
@Field_ZIP INT,
@Crop_Name VARCHAR(50),
@Event_Name VARCHAR(50)
AS 

DECLARE @D_ID INT, @M_ID INT, @FC_ID INT, @E_ID INT, @FCE_ID INT

-- EXEC GET DetailID
EXEC GET_DetailID
@Detailname = @Detail_N,
@DID = @D_ID OUTPUT

IF @D_ID IS NULL
    BEGIN
        PRINT('@D_ID is NULL, it cannot be null')
        RAISERROR('@D_ID is NULL',11,1)
        RETURN
    END

-- EXEC GET MeasurementID
EXEC GET_MeasurementID
@Measure = @MEASURE,
@MID = @M_ID OUTPUT

IF @M_ID IS NULL
    BEGIN
        PRINT('@M_ID is NULL, it cannot be null')
        RAISERROR('@M_ID is NULL',11,1)
        RETURN
    END

-- EXEC GET FieldCropEventID
EXEC GET_FieldCropEventID
@E_BeginD = @Event_BeginD,
@FC_BeginD = @FieldCrop_BeginD,
@F_N = @Field_Name,
@F_Street = @Field_STREET,
@F_City = @Field_CITY,
@F_State = @Field_STATE,
@F_Zip = @Field_ZIP,
@Crop_N = @Crop_Name,
@Event_N = @Event_Name,
@FCEID = @FCE_ID OUTPUT

IF @FCE_ID IS NULL
    BEGIN
        PRINT('@FCE_ID is NULL, it cannot be null')
        RAISERROR('@FCE_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblEVENT_DETAIL_FIELD_CROP (MeasurementQty, DetailID, MeasurementID, FieldCropEventID)
    VALUES (@Quantity, @D_ID, @M_ID, @FCE_ID)

    IF @@ERROR <> 0 
        BEGIN 
            ROLLBACK TRAN T1
        END 
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

