CREATE PROCEDURE uspPopulateSTOP
@Name varchar(50),
@Streety varchar(75),
@City varchar(35),
@Zip varchar(10),
@GPS varchar(50),
@Neighborhood varchar(50),
@StopType varchar(50)
AS
DECLARE @N_ID INT
DECLARE @ST_ID INT

SET @N_ID = (SELECT NeighborhoodID
FROM tblNEIHGBORHOOD
WHERE NeighborhoodName = @Neighborhood)

--Advanced class --> error-handling goes here
SET @ST_ID = (SELECT StopTypeID
FROM tblSTOP_TYPE
WHERE StopTypeName = @StopType)
--Advanced class --> error-handling goes here

BEGIN TRANSACTION T1
INSERT INTO tblSTOP (StopName, StopAddress, StopCity, StopZip, StopGPS, NeighborhoodID, StopTypeID)
VALUES (@Name,@Streety,@City,@Zip,@GPS,@N_ID, @ST_ID)
IF @@ERROR <> 0
ROLLBACK TRANSACTION T1

ELSE
COMMIT TRANSACTION T1
go

