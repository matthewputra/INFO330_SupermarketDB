CREATE PROCEDURE usp_jc_GetBuildingTypeID
@BT_Name varchar(50),
@BT_ID INT OUTPUT
AS
SET @BT_ID = (SELECT BuildingTypeID
			FROM tblBUILDING_TYPE
			WHERE BuildingTypeName = @BT_Name)
go

