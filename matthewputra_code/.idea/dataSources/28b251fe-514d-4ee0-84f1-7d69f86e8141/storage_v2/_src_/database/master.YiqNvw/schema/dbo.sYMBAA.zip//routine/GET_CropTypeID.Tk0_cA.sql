
------------------------------------------------------------------------------------------------------------
-- NESTED STORED PROCEDURE GET DetailTypeID
CREATE PROCEDURE GET_CropTypeID
@CTName varchar(50),
@CTID INT OUTPUT
AS 

SET @CTID = (SELECT CropTypeID
            FROM tblCROP_TYPE
            WHERE CropTypeName = @CTName)
go

