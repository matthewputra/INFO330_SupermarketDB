CREATE PROCEDURE usp_PopReport
@ReportTypeName VARCHAR(50),
@HikeName VARCHAR(50),
@CommentName VARCHAR(50),
@RatingName VARCHAR(25),
@ReportName VARCHAR(50),
@ReportDesc VARCHAR(50)
AS
DECLARE @RTID INT
DECLARE @HID INT
DECLARE @CommentID INT
DECLARE @RatingID INT

SET @RTID = (SELECT ReportTypeID FROM tblREPORT_TYPE WHERE ReportTypeName = @ReportTypeName)
	IF @RTID IS NULL
		BEGIN 
			PRINT 'You have Mispelled the name of ReportType'; 
				THROW 5777, '@RTID cannot be NULL; statement is being terminated', 11;
		END

SET @HID = (SELECT HikeID FROM tblHIKE WHERE HikeName = @HikeName)
	IF @HID IS NULL
		BEGIN 
			PRINT 'You have Mispelled the name of Hike'; 
				THROW 5777, '@HID cannot be NULL; statement is being terminated', 11;
		END

SET @CommentID = (SELECT CommentID FROM tblCOMMENT WHERE CommentName = @CommentName)
	IF @CommentID IS NULL
		BEGIN 
			PRINT 'You have Mispelled the name of Comment'; 
				THROW 5777, '@CommentID cannot be NULL; statement is being terminated', 11;
		END
SET @RatingID = (SELECT RatingID FROM tblRATING WHERE RatingName = @RatingName)
	IF @RatingID IS NULL
		BEGIN 
			PRINT 'You have Mispelled the name of Rating'; 
				THROW 5777, '@HikerID cannot be NULL; statement is being terminated', 11;
		END

INSERT INTO tblREPORT(ReportTypeID, HikeID, CommentID, RatingID, ReportName, ReportDesc)
VALUES(@RTID, @HID, @CommentID, @RatingID, @ReportName, @ReportDesc)
go

