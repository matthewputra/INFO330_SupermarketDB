CREATE FUNCTION fn_DeliveryDriverOver18()
RETURNS INT
AS
BEGIN
  DECLARE @RET int = 0
  IF EXISTS(
       SELECT E.EmployeeID, E.EmployeeFname, E.EmployeeLname, E.EmployeeDOB, R.RoleName
       FROM tblEMPLOYEE AS E
           JOIN tblJOB AS J ON J.EmployeeID = E.EmployeeID
           JOIN tblEVENT_JOB AS EJ ON EJ.JobID = J.JobID
           JOIN tblROLE AS R ON EJ.RoleID = R.RoleID
       WHERE DATEDIFF(YEAR, E.EmployeeDOB, GETDATE()) < 18
       AND R.RoleName LIKE '%Driver%'
  )
  BEGIN
   SET @RET = 1
  END
  RETURN @RET
END
go

