
-- Sproc for getting product ID
create proc usp_GetProductID
@ProdName varchar(50),
@P_ID int out
as
set @P_ID = (select ProductID
			from tblPRODUCT
			where ProductName = @ProdName)
go

