Create PROCEDURE CatchERROR AS
	BEGIN
		BEGIN TRY
			SELECT 'This first line in TRY is printed'
			SELECT SQRT(-1) -- Error happens here!
			SELECT 'But the last line in TRY is never printed'
		END TRY
		BEGIN CATCH
		  SELECT 'Something Went Wrong! Time to do something!'
		END CATCH
	END;
go

