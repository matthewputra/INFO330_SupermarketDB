CREATE PROCEDURE Item_Status_Populate
@ItemStatusName varchar(50),
@ItemName varchar(50),
@StatusName varchar(50)
AS
DECLARE @ItemID INT, @StatusID INT
SET @ItemID = (SELECT ItemID FROM ITEM WHERE ItemName = @ItemName)
SET @StatusName = (SELECT StatusID FROM STATUS WHERE StatusName = @StatusName)

INSERT INTO ITEM_STATUS (ItemStatusName, ItemID, StatusID)
VALUES (@ItemStatusName, @ItemName, @StatusName)
go

