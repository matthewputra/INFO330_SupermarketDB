
------------------------------------------------------------------------------------------------------------
-- NESTED STORED PROCEDURE GET FieldCropID
CREATE PROCEDURE GET_FieldCropID
@Field_N VARCHAR(50),
@Field_Street VARCHAR(50),
@Field_City VARCHAR(20),
@Field_State VARCHAR(2),
@Field_Zip INT,
@Crop_Name VARCHAR(50),
@FCID INT OUTPUT
AS 

DECLARE @F_ID INT, @C_ID INT

-- EXEC GET FieldID
EXEC GET_FieldID
@Fieldname = @Field_N,
@Street = @Field_Street,
@City = @Field_City,
@State = @Field_State,
@Zip = @Field_Zip,
@FID = @F_ID OUTPUT

IF @F_ID IS NULL
    BEGIN
        PRINT('@F_ID is NULL, it cannot be null')
        RAISERROR('@F_ID is NULL',11,1)
        RETURN
    END

-- EXEC GET CropID 
EXEC GET_CropID
@Cropname = @Crop_Name,
@CID = @C_ID OUTPUT

IF @C_ID IS NULL
    BEGIN
        PRINT('@C_ID is NULL, it cannot be null')
        RAISERROR('@C_ID is NULL',11,1)
        RETURN
    END

SET @FCID = (SELECT FieldCropID
            FROM tblFIELD_CROP
            WHERE FieldID = @F_ID
            AND CropID = @C_ID)
go

