
Create Procedure mag_getTripID
@S_D Date,
@E_D Date,
@T_ID Int Output
As

Set @T_ID = (Select TripID
From tblTRIP
Where StartDate = @S_D
And EndDate = @E_D)

go

