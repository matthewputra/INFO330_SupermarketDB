CREATE PROCEDURE InstblRoom
@RoomTypeName VARCHAR(50),
@RoomTypeDescr VARCHAR(50),
@HotelName VARCHAR(50),
@HotelAddress VARCHAR(50),
@HotelPhone INT,
@Room_Number INT,
@Room_Available BIT
AS
DECLARE @R_ID INT, @H_ID INT

EXEC GetRoomTypeID
@RoomType_Name = @RoomTypeName,
@RoomType_Descr = @RoomTypeDescr,
@RoomType_ID = @R_ID OUTPUT

IF @R_ID IS NULL
	BEGIN
		PRINT 'RoomID cannot be NULL';
		THROW 51000,'RoomID cannot be NULL', 1
	END

EXEC GetHotelID
@Hotel_Name = @HotelName,
@Hotel_Address = @HotelAddress,
@Hotel_Phone = @HotelPhone,
    @Hotel_ID = @H_ID OUTPUT

IF @H_ID IS NULL
	BEGIN
	PRINT 'Hey @H_ID is NULL...check spelling of @Hotels'
	RAISERROR ('@H_ID cannot be NULL', 11,1)
	RETURN
END

BEGIN TRAN G1
INSERT INTO tblRoom (RoomTypeID, RoomNumber, RoomAvailable, HotelID)
VALUES (@R_ID, @Room_Number, @Room_Available, @H_ID)
IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN G1
	END
ELSE
	COMMIT TRAN G1
go

