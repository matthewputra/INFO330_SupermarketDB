
Create procedure GetStatus
@stName varchar(50),
@stID INT output
as 
Set @stID = (select StatusID from tblSTATUS where StatusName = @stName)
go

