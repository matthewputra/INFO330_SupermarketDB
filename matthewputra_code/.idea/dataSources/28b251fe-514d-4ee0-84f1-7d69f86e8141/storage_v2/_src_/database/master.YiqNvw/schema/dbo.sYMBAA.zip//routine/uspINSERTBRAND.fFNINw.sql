CREATE PROCEDURE uspINSERTBRAND
@BrandName varchar(20),
@BrandDescription varchar(500),
@BrandTypeName varchar(20)
AS
DECLARE @BT_ID INT
SELECT @BT_ID = (
    SELECT BrandTypeID
    FROM tblBRAND_TYPE
    WHERE BrandTypeName = @BrandTypeName
)
BEGIN TRAN T1
INSERT INTO tblBRAND
(BrandName, BrandDescription, BrandTypeID)
VALUES (@BrandName, @BrandDescription, @BT_ID)
COMMIT TRAN T1
go

