
CREATE PROCEDURE insertNewProvider
@ProviderName VARCHAR(100),
@ProviderAdd1 VARCHAR(200),
@ProviderAdd2 VARCHAR(200),
@ProviderPhone VARCHAR(20),
@ProviderEmail VARCHAR(100),
@CityNamy VARCHAR(50),
@PtypeNamy VARCHAR(60)
AS
    IF @ProviderName IS NULL OR @ProviderAdd1 IS NULL OR @ProviderAdd2 IS NULL OR  @ProviderPhone IS NULL OR @ProviderEmail IS NULL OR @CityNamy IS NULL
    OR @CityNamy IS NULL
	BEGIN
		RAISERROR ('Missing parameter; Check to make sure no parameter is null', 11, 1)
		RETURN
	END
DECLARE @C_ID INT, @PT_ID INT

EXEC ss251_GetCityID
@City = @Citynamy,
@City_ID = @C_ID OUTPUT
if @C_ID IS NULL 
    BEGIN
        PRINT 'Hey...@C_ID is NULL and that is not good'
        RAISERROR ('@C_ID cannot be NULL', 11, 1)
        RETURN 
    END
EXEC xz67_GetProvTypeID
@ProvTName = @PtypeNamy,
@PtypeNamy = @PT_ID OUTPUT
if @PT_ID IS NULL 
    BEGIN
        PRINT 'Hey...@PT_ID is NULL and that is not good'
        RAISERROR ('@PT_ID cannot be NULL', 11, 1)
        RETURN 
    END

BEGIN TRAN T1
	INSERT INTO tblProvider(ProvName, ProvAddr1, ProvAddr2, ProvPhone, ProvEmail, ProvTypeID, CityID)
	VALUES (@ProviderName, @ProviderAdd1, @ProviderAdd2, @ProviderPhone, @ProviderEmail, @PT_ID, @C_ID)
	IF @@ERROR <> 0
		BEGIN
			ROLLBACK TRAN T1
		END
	ELSE
		COMMIT TRAN T1
go

