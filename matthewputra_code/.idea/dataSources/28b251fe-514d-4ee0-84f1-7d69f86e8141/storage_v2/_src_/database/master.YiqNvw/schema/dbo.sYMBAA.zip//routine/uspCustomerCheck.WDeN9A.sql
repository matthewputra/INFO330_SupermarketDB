CREATE PROCEDURE uspCustomerCheck 
@State INT
AS
BEGIN
IF @State IS NULL GOTO CodeBlock_One 
IF @State IN (1, 2) GOTO CodeBlock_Three 
IF @State IN (3, 4) GOTO CodeBlock_Two  
IF @State = 'Jimi Hendrix' GOTO CodeBlock_Four
IF @State = 'Bruce Lee' PRINT 'Enter The Dragon'
RETURN

CodeBlock_One:
PRINT '@State IS NULL; skipping LocationBlock Two'
GOTO CodeBlock_Three; 

CodeBlock_Two:
PRINT @State--'one'

CodeBlock_Three:
PRINT @State --'two'

CodeBlock_Four:
PRINT @State + 'block three'
END
go

