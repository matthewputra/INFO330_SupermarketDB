
-------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT CROP
CREATE PROCEDURE INSERT_CROP 
@C_Name VARCHAR(50),
@PRICE MONEY,
@CT_Name VARCHAR(50)
AS 

DECLARE @CT_ID INT

-- EXEC GET CropTypeID
EXEC GET_CropTypeID
@CTName = @CT_Name,
@CTID = @CT_ID OUTPUT

IF @CT_ID IS NULL
    BEGIN
        PRINT('@CT_ID is NULL, it cannot be null')
        RAISERROR('@CT_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblCROP (CropName, CropPricePerPound, CropTypeID)
    VALUES(@C_Name, @PRICE, @CT_ID)

    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

