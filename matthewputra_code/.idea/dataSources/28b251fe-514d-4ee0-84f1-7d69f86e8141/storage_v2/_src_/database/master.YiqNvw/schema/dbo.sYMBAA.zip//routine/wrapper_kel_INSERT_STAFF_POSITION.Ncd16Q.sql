CREATE PROCEDURE wrapper_kel_INSERT_STAFF_POSITION
@RUN INT
AS
-- challenge --> write you wrapper to have variation (random) customer and random product random order date and qty

DECLARE @SF VARCHAR(60), @SL VARCHAR(60), @SB DATE, @D VARCHAR(75), @P varchar(50), @B Date, @E DATE

DECLARE @StaffRowCount INT = (SELECT COUNT(*) FROM tblSTAFF)
DECLARE @DeptRowCount INT = (SELECT COUNT(*) FROM tblDEPARTMENT)
DECLARE @PosRowCount INT = (SELECT COUNT(*) FROM tblPOSITION)
DECLARE @S_PK INT, @D_PK INT, @P_PK INT

WHILE @RUN > 0
BEGIN
SET @S_PK = (SELECT RAND() * @StaffRowCount + 1)
SET @D_PK = (SELECT RAND() * @DeptRowCount + 1)
SET @P_PK = (SELECT RAND() * @PosRowCount + 1)

SET @SF = (SELECT StaffFname FROM tblSTAFF WHERE StaffID = @S_PK)
SET @SL = (SELECT StaffLname FROM tblSTAFF WHERE StaffID = @S_PK)
SET @SB = (SELECT StaffBirth FROM tblSTAFF WHERE StaffID = @S_PK)
SET @D = (SELECT DeptName FROM tblDEPARTMENT WHERE DeptID = @D_PK)
SET @P = (SELECT PositionName FROM tblPOSITION WHERE PositionID = @P_PK)

SET @B = (SELECT GetDate() - @S_PK)
SET @E = (SELECT GetDate() - @S_PK)

EXEC kel28_INSERT_STAFF_POSITION
@Begin = @B,
@End = @E,
@D_Name = @D,
@S_Fname = @SF,
@S_Lname = @SL,
@S_Birth = @SB,
@P_Name = @P
PRINT @RUN
SET @RUN = @RUN -1
END
go

