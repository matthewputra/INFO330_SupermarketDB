
-------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT GROWER COMPANY 
CREATE PROCEDURE INSERT_GROWER_COMPANY
@F_n VARCHAR(20),
@L_n VARCHAR(20),
@DateOfBirth DATE,
@Company_Name VARCHAR(50)
AS 

DECLARE @G_ID INT, @C_ID INT

-- EXEC GET GrowerID
EXEC GET_GrowerID
@Fname = @F_n,
@Lname = @L_n,
@BirthDate = @DateOfBirth,
@GID = @G_ID OUTPUT

IF @G_ID IS NULL
    BEGIN
        PRINT('@G_ID is NULL, it cannot be null')
        RAISERROR('@G_ID is NULL',11,1)
        RETURN
    END

-- EXEC GET CompanyID
EXEC GET_CompanyID
@Companyname = @Company_Name,
@CID = @C_ID OUTPUT

IF @C_ID IS NULL
    BEGIN
        PRINT('@C_ID is NULL, it cannot be null')
        RAISERROR('@C_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblGROWER_COMPANY (GrowerID, CompanyID)
    VALUES (@G_ID, @C_ID)

    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

