
CREATE PROCEDURE jmanGetBuildingID
@BuildingName varchar(20),
@B_ID INT OUTPUT
AS 
SET @B_ID = (SELECT BuildingID
			FROM tblBUILDING
			WHERE BuildingName = @BuildingName)
go

