create proc Wrapper_usp_NewOrder
@run int
as
declare 
@F varchar(50),
@L varchar(50),
@B date,
@P varchar(50),
@D date = (select getdate()),
@Q int

-- get matching customer fname, lname, dob with correct primary key

-- variable to hold row count of tblCustomer
declare @CustomerRowCount int = (select count(*) from tblCUSTOMER)
declare @Customer_PK int
-- variable to hold row count of tblOrder
declare @ProductRowCount int = (select count(*) from tblProduct)
declare @Product_PK int

while @run > 0
begin

-- customer
set @Customer_PK = (select rand() * @CustomerRowCount)
set @F = (select CustFName from tblCUSTOMER where CustomerID = @Customer_PK)
set @L = (select CustLName from tblCUSTOMER where CustomerID = @Customer_PK)
set @B = (select CustBirthDate from tblCUSTOMER where CustomerID = @Customer_PK)

-- product
set @Product_PK = (select rand() * @ProductRowCount)
set @P = (select ProductName from tblPRODUCT where ProductID = @Product_PK)

-- quantity
set @Q = (select round(((rand() * 2) + 1), 0))
	exec usp_NewOrder
	@Fname2 = @F,
	@Lname2 = @L,
	@DOB2 = @B,
	@ProdName2 = @P,
	@OrderDate = @D,
	@Qty = @Q

set @run = @run -1
print @run
end
go

