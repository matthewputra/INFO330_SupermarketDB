CREATE -- DROP
VIEW vBooking AS
SELECT Rate,
       BeginDate,
       EndDate,
       BookingDate
FROM tblBooking
go

