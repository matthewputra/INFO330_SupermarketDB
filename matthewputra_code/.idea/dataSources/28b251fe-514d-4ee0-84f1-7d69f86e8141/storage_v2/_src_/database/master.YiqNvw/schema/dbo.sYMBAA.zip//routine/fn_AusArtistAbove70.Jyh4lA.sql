
-- Scarlett

-- Artists from Australia who are above 70 can’t sign a contract type that is temporary
CREATE FUNCTION fn_AusArtistAbove70()
RETURNS INT
AS
BEGIN
   DECLARE @RET INT = 0
       IF EXISTS (
           SELECT A.ArtistID FROM tblArtist A
               JOIN tblCountry_Artist CA ON A.ArtistID = CA.ArtistID
               JOIN tblCountry C ON CA.CountryID = C.CountryID
               JOIN tblGroupArtist GA ON A.ArtistID = GA.ArtistID
               JOIN tblGroup G ON GA.GroupID = G.GroupID
               JOIN tblContract CT ON G.GroupID = CT.GroupID
               JOIN tblContractType CTT ON CT.ContractTypeID = CTT.ContractTypeID
 
               WHERE A.DateOfBirth > DateAdd(year, -70, GETDATE())
               AND C.CountryName = 'Autrailia'
               AND CTT.ContractTypeName = 'temporary'
       )
       BEGIN
       SET @RET = 1
       END
RETURN @RET
END
go

