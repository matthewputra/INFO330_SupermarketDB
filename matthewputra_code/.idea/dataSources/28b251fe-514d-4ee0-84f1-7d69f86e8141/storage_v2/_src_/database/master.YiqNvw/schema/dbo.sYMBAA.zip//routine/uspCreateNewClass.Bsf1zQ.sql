CREATE PROCEDURE uspCreateNewClass
		@CrName varchar (50),
		@Yr DATE,
		@Sect varchar (5)
		AS
			DECLARE @C_ID INT
			SET @C_ID = (SELECT CourseID 
						 FROM tblCOURSE
						 WHERE CourseName = @CrName)
		BEGIN Tran A1
			INSERT INTO tblCLASS(CourseID, [YEAR], Section)
			VALUES(@CrName, @Yr, @Sect)
		COMMIT Tran A1
go

