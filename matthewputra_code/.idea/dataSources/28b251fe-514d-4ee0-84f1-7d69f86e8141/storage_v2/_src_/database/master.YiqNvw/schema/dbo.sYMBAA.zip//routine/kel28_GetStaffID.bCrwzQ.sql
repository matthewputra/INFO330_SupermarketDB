
CREATE PROCEDURE kel28_GetStaffID
@SFname VARCHAR(60),
@SLname VARCHAR(60),
@SBirth DATE,
@StaffID INT OUTPUT
AS 
SET @StaffID = (SELECT StaffID FROM tblSTAFF WHERE StaffFName = @SFname AND StaffLName = @SLname AND StaffBirth = @SBirth)
go

