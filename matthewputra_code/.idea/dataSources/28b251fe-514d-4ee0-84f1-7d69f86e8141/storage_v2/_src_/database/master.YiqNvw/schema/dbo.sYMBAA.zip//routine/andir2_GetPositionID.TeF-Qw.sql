
--DROP PROCEDURE andir2_GetPositionID
CREATE PROCEDURE andir2_GetPositionID
@PostionName	varchar(50),
@PostionID	INT OUTPUT
AS
	
SET @PostionID = (SELECT PositionID From tblPOSITION WHERE PositionName = @PostionName)
go

