--6 
CREATE PROCEDURE uspNEWSTAFF
@FName VARCHAR(20),
@LName VARCHAR(20),
@Birth Date,
@PositionName VARCHAR(50),
@DeptName VARCHAR(50)
AS 
DECLARE @S_ID INT, @D_ID INT, @P_ID INT
SET @S_ID = (SELECT StaffID 
			FROM tblSTAFF
			WHERE StaffFName = @FName
			AND StaffLName = @LName
			AND StaffBirth = @Birth)
SET @D_ID = (SELECT DeptID
			FROM tblDEPARTMENT
			WHERE DeptName = @DeptName)
SET @P_ID = (SELECT PositionID 
			FROM tblPOSITION
			WHERE PositionName = @PositionName)
INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, DeptID)
VALUES (@S_ID, @D_ID, @P_ID)
go

