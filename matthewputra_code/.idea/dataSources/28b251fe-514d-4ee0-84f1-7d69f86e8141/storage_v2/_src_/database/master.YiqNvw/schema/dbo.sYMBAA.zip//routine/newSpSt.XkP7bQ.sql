
Create procedure newSpSt
@spotName varchar(50),
@statusName varchar(50)
as
Declare @spot_id INT, @status_id INT

Exec GetSpot
@spName =@spotName,
@spID = @spot_id output
IF @spot_id IS NULL
BEGIN
RAISERROR ('@spot_id cannot be NULL', 11,1)
RETURN
END
Exec GetStatus
@stName = @statusName,
@stID = @status_id output

IF @status_id IS NULL
BEGIN
RAISERROR ('@status_id cannot be NULL', 11,1)
RETURN
END
Begin Transaction T1
Insert into tblSPOT_STATUS(SpotID,StatusID)
Values (@spot_id, @status_id)
if @@error <> 0 
begin
print'newSpSt insertion error'
end
Commit Transaction T1
go

