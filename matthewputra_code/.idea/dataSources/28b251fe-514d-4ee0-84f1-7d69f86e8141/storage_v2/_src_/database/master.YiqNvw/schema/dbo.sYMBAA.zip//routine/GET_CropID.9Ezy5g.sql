
-------------------------------------------------------------
-- NESTED STORED PROCEDURE GET CropID
CREATE PROCEDURE GET_CropID
@Cropname VARCHAR(50),
@CID INT OUTPUT
AS

SET @CID = (SELECT CropID 
            FROM tblCROP
            WHERE CropName = @Cropname)
go

