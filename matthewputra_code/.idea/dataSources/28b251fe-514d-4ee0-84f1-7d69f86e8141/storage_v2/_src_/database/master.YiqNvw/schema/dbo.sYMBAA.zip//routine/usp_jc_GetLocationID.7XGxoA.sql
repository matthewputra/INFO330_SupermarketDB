CREATE PROCEDURE usp_jc_GetLocationID
@L_Name varchar(50),
@L_ID INT OUTPUT
AS
SET @L_ID = (SELECT LocationID
			FROM tblLOCATION 
			WHERE LocationName = @L_Name)
go

