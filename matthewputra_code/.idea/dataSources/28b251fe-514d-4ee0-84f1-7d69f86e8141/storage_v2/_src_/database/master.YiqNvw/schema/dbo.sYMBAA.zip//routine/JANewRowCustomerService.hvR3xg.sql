Create Procedure JANewRowCustomerService
@CSName Varchar (50),
@CSDescr Varchar (250),
@Price Numeric (6,2)

As

Insert Into [dbo].[tblCUSTOMERSERVICE]
(
[CustServiceName]
,[CustServiceDescr]
,[Price]
)
Values 
(
@CSName
,@CSDescr
,@Price
)
go

