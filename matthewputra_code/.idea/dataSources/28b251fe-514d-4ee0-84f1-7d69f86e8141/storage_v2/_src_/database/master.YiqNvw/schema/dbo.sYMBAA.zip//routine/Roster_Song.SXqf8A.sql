CREATE PROCEDURE Roster_Song
@Year char(4),
@qname varchar(20),
@cname varchar(50),
@section char(10)
AS
SELECT S.StudentFname, S.StudentLname, S.StudentBirth, CR.CourseName, Q.QuarterName, CS.[YEAR], CL.RegistrationDate
FROM tblCOURSE CR
	JOIN tblCLASS CS
		ON CR.CourseID = CS.CourseID
	JOIN tblQUARTER Q
		ON CS.QuarterID = Q.QuarterID
	JOIN tblCLASS_LIST CL
		ON CS.ClassID = CL.ClassID
	JOIN tblSTUDENT S
		ON CL.StudentID = S.StudentID
WHERE CS.[YEAR] = @Year
	AND Q.QuarterName = @qname
	AND CR.CourseName = @cname
	AND CS.Section = @section
go

