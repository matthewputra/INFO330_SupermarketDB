CREATE PROCEDURE usp_INSERT_tblAD_LOCATION
@CityName varchar(75),
@StateName varchar(75),
@VendorName varchar(75),
@MediaName varchar(75),
@AdLocationName varchar(75),
@AdLocationDescr varchar(500),
@AdLocationPrice money,
@AdLocationID INT OUTPUT

AS

DECLARE @CityID INT
EXEC GetCityID
@CityName = @CityName,
@StateName = @StateName,
@CityID = @CityID OUTPUT
IF @CityID IS NULL
BEGIN
	PRINT '@CityID IS NULL'
	RAISERROR ('@CityID cannot be NULL',11,1)
	RETURN
END

DECLARE @VendorID INT
EXEC GetVendorID
@VendorName = @VendorName,
@VendorID = @VendorID OUTPUT
IF @VendorID IS NULL
BEGIN
	PRINT '@VendorID IS NULL'
	RAISERROR ('@VendorID cannot be NULL',11,1)
	RETURN
END

DECLARE @MediaID INT
EXEC GetMediaID
@MediaName = @MediaName,
@MediaID = @MediaID OUTPUT
IF @MediaID IS NULL
BEGIN
	PRINT '@MediaID IS NULL'
	RAISERROR ('@MediaID cannot be NULL',11,1)
	RETURN
END

BEGIN TRANSACTION T1
INSERT INTO tblAD_LOCATION (MediaID, VendorID, CityID, AdLocationName, AdLocationDescr)
VALUES (@MediaID, @VendorID, @CityID, @AdLocationName, @AdLocationDescr)
SET @AdLocationID = SCOPE_IDENTITY()
IF @@ERROR <> 0
BEGIN
	ROLLBACK TRANSACTION T1
END

INSERT INTO tblAD_LOCATION_PRICE (AdLocationID, AdLocationPrice, BeginDate)
VALUES (@AdLocationID, @AdLocationPrice, GETDATE())
IF @@ERROR <> 0
BEGIN
	ROLLBACK TRANSACTION T1
END
COMMIT TRANSACTION T1
go

