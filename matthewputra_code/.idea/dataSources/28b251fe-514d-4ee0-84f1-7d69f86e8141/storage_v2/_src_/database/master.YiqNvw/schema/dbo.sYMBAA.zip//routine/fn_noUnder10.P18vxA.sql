

-- Winnie
CREATE FUNCTION dbo.fn_noUnder10()
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (SELECT *
	FROM tblCountry C
	JOIN tblCountry_Artist CA ON C.CountryID = CA.CountryID
	JOIN tblArtist A ON A.ArtistID = CA.ArtistID
	join tblGroupArtist GA ON GA.ArtistID = A.ArtistID
	JOIN tblGroup G ON G.GroupID = GA.GroupID
	JOIN tblContract CT ON CT.GroupID = G.GroupID
	WHERE C.CountryName = 'United Kingdom'
	and YEAR(DateOfBirth) > DATEADD(YEAR, -10, GETDATE()) 

	)
	BEGIN
		SET @Ret = 1
	END
	
	RETURN @Ret

END
go

