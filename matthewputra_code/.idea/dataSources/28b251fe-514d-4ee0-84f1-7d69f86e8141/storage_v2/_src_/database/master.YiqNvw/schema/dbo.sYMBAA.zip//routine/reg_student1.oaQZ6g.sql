
/*
Write the code to create a stored procedure to register an existing student to an existing class.
*/

CREATE PROCEDURE reg_student1
@N varchar(20), --netID
@C varchar(20), --course name
@Q varchar(20), --quarter
@S varchar(20), --section
@D DATE,        --reg date
@F INT          --reg fee
AS
DECLARE @S_ID INT, @CR_ID INT, @Q_ID INT, @C_ID INT
SET @S_ID = 
	(SELECT StudentID
	FROM tblSTUDENT
	WHERE StudentNetID = @N)

SET @CR_ID =
	(SELECT CourseID
	FROM tblCOURSE
	WHERE CourseName = @C)

SET @Q_ID =
	(SELECT QuarterID
	FROM tblQUARTER
	WHERE QuarterName = @Q)

SET @C_ID =
	(SELECT ClassID
	FROM tblCLASS
	WHERE CourseID = @CR_ID
	AND QuarterID = @Q_ID
	AND Section = @S)

INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES(@C_ID, @S_ID, NULL, @D, @F)

go

