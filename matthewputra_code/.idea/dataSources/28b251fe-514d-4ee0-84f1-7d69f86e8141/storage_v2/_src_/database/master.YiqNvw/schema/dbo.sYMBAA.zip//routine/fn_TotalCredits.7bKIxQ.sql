CREATE FUNCTION fn_TotalCredits(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = (SELECT SUM(CR.Credits)
                    FROM tblStudent S
                        JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
                        JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
                        JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
                        JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
                        JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
                        JOIN tblCLASSROOM CM ON CS.ClassroomID = CM.ClassroomID
                        JOIN tblBUILDING B ON CM.BuildingID = B.BuildingID
                        JOIN LOCATION L ON B.LocationID = L.LocationID
                    WHERE C.CollegeName = 'Arts and Sciences'
                    AND CL.Grade >= 3.4
                    AND L.LocationName LIKE "%Quad%"
                    AND S.StudentID = @PK)
RETURN @Ret
END
go

