--7
CREATE PROCEDURE uspNEWCLASS
@CourseName VARCHAR (50),
@ScheduleName VARCHAR(50),
@ClassroomName VARCHAR(50),
@QuarterName VARCHAR (20)
AS 
DECLARE @C_ID INT, @S_ID INT, @Q_ID INT, @CL_ID INT
SET @C_ID = (SELECT CourseID
			FROM tblCOURSE
			WHERE CourseName = @CourseName)
SET @S_ID = (SELECT ScheduleID
			FROM tblSCHEDULE
			WHERE ScheduleName = @ScheduleName)
SET @Q_ID = (SELECT QuarterID
			FROM tblQUARTER
			WHERE QuarterName = @QuarterName)
SET @CL_ID = (SELECT ClassroomName
			FROM tblCLASSROOM
			WHERE ClassroomName = @ClassroomName)
INSERT INTO tblCLASS(CourseID, ScheduleID, QuarterID, ClassroomID) 
VALUES (@C_ID, @S_ID, @Q_ID, @CL_ID)
go

