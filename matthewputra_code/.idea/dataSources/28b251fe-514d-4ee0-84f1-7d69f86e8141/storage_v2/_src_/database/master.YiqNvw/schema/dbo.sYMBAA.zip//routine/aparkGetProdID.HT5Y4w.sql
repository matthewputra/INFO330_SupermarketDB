
CREATE PROCEDURE aparkGetProdID
@ProdName varchar(50),
@ProdID INT OUTPUT
AS
SET @ProdID = (SELECT ProductID
                   FROM tblPRODUCT
                   WHERE ProductName = @ProdName)
go

