
-- Create sp for getting UnitID
CREATE PROCEDURE GET_UnitID
@UnitName varchar(50),
@UID INT OUTPUT
AS 

SET @UID = (SELECT UnitID
            FROM tblUNIT
            WHERE Unitname = @UnitName)

IF @UID IS NULL
    BEGIN 
        PRINT ('@UID is NULL, it cannot be NULL')
        RAISERROR ('@UID is NULL',11,1)
    END
go

