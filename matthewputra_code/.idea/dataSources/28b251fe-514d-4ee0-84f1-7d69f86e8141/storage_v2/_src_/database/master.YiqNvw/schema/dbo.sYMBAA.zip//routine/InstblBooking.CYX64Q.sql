CREATE PROCEDURE InstblBooking
@CustomerFName VARCHAR(60),
@CustomerLName VARCHAR(60),
@CustomerBirth DATE,
@CustomerEmail VARCHAR(75),
@RateBook MONEY,
@BeginDate DATE,
@EndDate DATE,
@BookingDate DATE
AS
DECLARE @C_ID INT

EXEC GetCustomerID
@Customer_FName = @CustomerFName,
    @Customer_LName = @CustomerLName,
    @Customer_Birth = @CustomerBirth,
    @Customer_Email = @CustomerEmail,
    @Customer_ID = @C_ID OUTPUT

IF @C_ID IS NULL
	BEGIN
		PRINT 'CustomerID cannot be NULL';
		THROW 51000,'CustomerID cannot be NULL', 1
	END


BEGIN TRAN T1
INSERT INTO tblBooking(CustID, Rate, BeginDate, EndDate, BookingDate)
VALUES (@C_ID, @RateBook, @BeginDate,@EndDate,@BookingDate)
IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN T1
	END
ELSE
	COMMIT TRAN T1
go

