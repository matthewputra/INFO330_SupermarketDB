CREATE PROCEDURE populateCustType
    @CustTypeName varchar(20)
AS
    INSERT INTO tblCustomerType(CustTypeName)
    VALUES (@CustTypeName)
go

