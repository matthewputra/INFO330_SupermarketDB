CREATE PROCEDURE INSERT_MANAGER
@ManagerName varchar(20),
@ManagerDesc varchar(500)
AS 
BEGIN TRAN P1
INSERT INTO MANAGER(ManagerName, ManagerDesc)
VALUES(@ManagerName, @ManagerDesc)
COMMIT TRAN P1
go

