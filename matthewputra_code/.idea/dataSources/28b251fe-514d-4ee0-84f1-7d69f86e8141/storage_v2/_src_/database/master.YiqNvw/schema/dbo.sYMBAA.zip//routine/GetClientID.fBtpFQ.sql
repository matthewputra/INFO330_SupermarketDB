-- Gets ClientID given ClientName
CREATE PROCEDURE GetClientID
@Cl_Name varchar(75),
@Cl_ID INT OUTPUT
AS
SET @Cl_ID = (
	SELECT ClientID FROM tblCLIENT
	WHERE ClientName = @Cl_Name
)
go

