CREATE PROCEDURE getMeasurementUnitID
@MU_Name varchar(50),
@MeasurementUnitID INT OUTPUT
AS
SET @MeasurementUnitID = (SELECT MeasurementUnitID FROM tblMEASUREMENTUNIT
						WHERE MeasurementUnitName = @MU_Name)
go

