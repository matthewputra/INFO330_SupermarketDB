
CREATE PROCEDURE GetTripID
@T_N VARCHAR(50),
@S_D DATE,
@E_D DATE,
@T_ID INT OUTPUT

AS

SET @T_ID =(SELECT TripID FROM tblTRIP
            WHERE TripName = @T_N
			AND StartDate = @S_D
			AND EndDate = @E_D)
go

