
create function roomCheck()
returns int
as 
begin
declare @RET int = 0
if 
exists(
select H.HotelID, R.[Floor], C.CharacterID
from tblHOTEL H
	join tblROOM R
		on R.HotelID = H.HotelID
	join tblCHARACTER C
		on C.CharacterID = R.CharacterID
group by H.HotelID, R.[Floor], C.CharacterID
having count(R.RoomID) > 2)
begin 
	set @RET = 1
end
return @RET
end
go

