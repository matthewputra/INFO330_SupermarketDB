
-- Stored Procedures
Create Procedure mag_getActivityID
@A_N varchar(50),
@C	Int,
@A_ID Int Output
As

Set @A_ID = (Select ActivityID
			From tblACTIVITY
			Where ActivityName = @A_N
			And Capacity = @C)
go

