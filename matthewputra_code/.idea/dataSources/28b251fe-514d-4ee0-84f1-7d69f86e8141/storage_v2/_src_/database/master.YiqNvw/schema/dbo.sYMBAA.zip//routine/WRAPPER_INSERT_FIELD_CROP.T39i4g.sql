
--****************************************************************************************************************************************************************--
-- SYNTHETIC TRANSACTIONS (WRAPPERS )
--****************************************************************************************************************************************************************--
-- WRAPPER FOR INSERT FIELD CROP 
CREATE PROCEDURE WRAPPER_INSERT_FIELD_CROP
@RUN INT
AS

-- DECLARE VARIABLES 
DECLARE @BD DATE
DECLARE @Q INT
DECLARE @FN VARCHAR(50)
DECLARE @FST VARCHAR(50)
DECLARE @FC VARCHAR(20)
DECLARE @FS VARCHAR(2)
DECLARE @FZ INT
DECLARE @CrN VARCHAR(50)

DECLARE @Field_PK INT 
DECLARE @Crop_PK INT

SET @BD = (SELECT GetDate())
--------------------------------------------------
-- WHILE LOOP 
WHILE @RUN > 0 

    BEGIN 
        SET @Q = (SELECT FLOOR(Rand() * 901)) + 100

        SET @Field_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblFIELD))
        SET @Crop_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblCROP))

        SET @FN = (SELECT FieldName
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FST = (SELECT FieldStreet
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FC = (SELECT FieldCity
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FS = (SELECT FieldState
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FZ = (SELECT FieldZip
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @CrN = (SELECT CropName
                    FROM tblCROP
                    WHERE CropID = @Crop_PK)

        -- EXEC BASED PROCEDURE
        EXEC INSERT_FIELD_CROP
        @BeginD = @BD,
        @Qty = @Q,
        @Field_N = @FN,
        @F_Street = @FST,
        @F_City = @FC,
        @F_State = @FS,
        @F_Zip = @FZ,
        @Crop_N = @CrN

        SET @RUN = @RUN - 1
        PRINT @RUN 
    END
go

