
CREATE PROCEDURE lim55_getCountryID
@CtyName VARCHAR(50),
@CtyID INT OUTPUT
AS 
SET @CtyID = (SELECT CountryID FROM lim55_COUNTRY WHERE CountryName = @CtyName)
go

