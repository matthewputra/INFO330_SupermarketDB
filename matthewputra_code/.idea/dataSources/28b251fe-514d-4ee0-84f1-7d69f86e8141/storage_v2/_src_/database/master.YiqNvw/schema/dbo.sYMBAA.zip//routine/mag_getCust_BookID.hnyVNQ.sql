
Create Procedure mag_getCust_BookID
@Book_N char(7),
@Book_T Datetime,
@Cust_F varchar(50),
@Cust_L varchar(50),
@Cust_DOB Date,
@CB_ID Int Output

As

Declare @Book_ID Int, @Cust_ID Int

Execute mag_getBookingID
@B_N = @Book_N,
@B_T = @Book_T,
@B_ID = @Book_ID Output
Execute mag_getCustID
@C_F = @Cust_F,
@C_L = @Cust_L,
@DOB = @Cust_DOB,
@C_ID = @Cust_ID Output

Set @CB_ID = (Select CustBookingID
From tblCUST_BOOK
Where CustID = @Cust_ID
And BookingID = @Book_ID)
go

