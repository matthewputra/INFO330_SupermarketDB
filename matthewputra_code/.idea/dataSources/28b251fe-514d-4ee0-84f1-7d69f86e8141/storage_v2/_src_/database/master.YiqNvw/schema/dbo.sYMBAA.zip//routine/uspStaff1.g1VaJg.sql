
CREATE PROCEDURE uspStaff1
	@StaffFname varchar(20),
	@StaffLname varchar(20), 
	@BDate		Date,
	@PosName	varchar(40),
	@DeptName   varchar(40),
	@BeginDate	Date, 
	@EndDate	Date
AS
	DECLARE @P_ID INT, @STAFF_ID INT, @DEPT_ID INT
	SET @P_ID = (SELECT PositionID FROM tblPOSITION P
				 WHERE P.PositionName = @PosName)
	SET @STAFF_ID = (SELECT StaffID FROM tblSTAFF
					 WHERE StaffFname = @StaffFname
					 AND StaffLname = @StaffLname
					 AND StaffBirth = @BDate)
	SET @DEPT_ID = (SELECT DeptID FROM tblDEPARTMENT
					WHERE DeptName = @DeptName)
BEGIN TRAN uspStaff1
	INSERT INTO tblSTAFF_POSITION
		(StaffID, PositionID, BeginDate, DeptID)
	values (@P_ID, @STAFF_ID, @BeginDate, @DEPT_ID)
COMMIT TRAN uspStaff1
go

