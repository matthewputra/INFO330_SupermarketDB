
------------------------------------------------------------------------------------------------------------
-- CREATE MAIN PROCEDURE INSERT FIELD
CREATE PROCEDURE INSERT_FIELD 
@First_Name VARCHAR(20),
@Last_Name VARCHAR(20),
@DateOfBirth DATE,
@F_Name VARCHAR(50),
@Acres INT,
@Street VARCHAR(50),
@City VARCHAR(20),
@State VARCHAR(2),
@Zip INT
AS 

DECLARE @G_ID INT
    
-- EXEC GET GrowerID
EXEC GET_GrowerID
@Fname = @First_Name,
@Lname = @Last_Name,
@BirthDate = @DateOfBirth,
@GID = @G_ID OUTPUT

IF @G_ID IS NULL
    BEGIN
        PRINT('@G_ID is NULL, it cannot be null')
        RAISERROR('@G_ID is NULL',11,1)
        RETURN
    END

BEGIN TRAN T1
    INSERT INTO tblFIELD (FieldName, FieldAcres, FieldStreet, FieldCity, FieldState, FieldZip, GrowerID)
    VALUES (@F_Name, @Acres, @Street, @City, @State, @Zip, @G_ID)

    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE 
        BEGIN
            COMMIT TRAN T1
        END
go

