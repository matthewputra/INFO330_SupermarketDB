CREATE PROCEDURE INSERT_LEASE
@S_Fname varchar(50),
@S_Lname varchar(50),
@B_Date DATE,
@U_Name varchar(50),
@Begin_Date DATE,
@MonthlyPayment MONEY,
@End_Date DATE
AS 
DECLARE @S_ID INT, @U_ID INT

EXEC GET_StudentID
@StudentFname = @S_Fname,
@StudentLname = @S_Lname,
@BirthDate = @B_Date,
@SID = @S_ID OUTPUT

EXEC GET_UnitID
@UnitName = @U_Name,
@UID = @U_ID OUTPUT

BEGIN TRAN T1
    INSERT INTO tblLEASE (LeaseBeginDate, LeaseEndDate, PaymentByMonth)
    VALUES (@Begin_Date, @End_Date, @MonthlyPayment)

    IF @@ERROR <> 0
        BEGIN 
            COMMIT TRAN T1
        END
    ELSE
        BEGIN 
            ROLLBACK TRAN T1
        END
go

