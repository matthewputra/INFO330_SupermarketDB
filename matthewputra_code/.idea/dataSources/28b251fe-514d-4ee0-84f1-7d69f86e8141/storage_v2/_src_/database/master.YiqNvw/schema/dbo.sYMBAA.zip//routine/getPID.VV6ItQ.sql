
CREATE PROCEDURE getPID
@pname varchar(50),
@pid INT OUTPUT
AS
SET @pid = (SELECT ProdID
			FROM PRODUCT
			WHERE ProdName = @pname)
go

