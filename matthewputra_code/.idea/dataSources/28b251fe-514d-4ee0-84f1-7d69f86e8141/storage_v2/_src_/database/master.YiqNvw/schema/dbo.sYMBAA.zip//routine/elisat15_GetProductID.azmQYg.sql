/*

1) Create two 'GetID' procesuder --> on for Product and the other for customer

2) Create base procedure to insert a new rot into tblORDER --> leverage GetID procs from above

3) Create wrapper around the base stored procedure to execute at volume --> 1,000,000+
    (Synthetic transaction)

*/

-- CREATE GetID procedure

CREATE PROCEDURE elisat15_GetProductID 
@ProdName varchar(50),
@Proddy_ID INT OUTPUT
AS 

SET @Proddy_ID = (SELECT ProductID FROM tblPRODUCT WHERE ProductName = @ProdName)
go

