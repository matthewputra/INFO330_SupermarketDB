CREATE FUNCTION fn_NoNewAdIfCampaignIsOver()
RETURNS INT
AS
BEGIN  
    DECLARE @Ret INT = 0
    IF EXISTS (
        SELECT * FROM tblAD A
            JOIN tblPRODUCT_CAMPAIGN PC ON A.ProductCampaignID = PC.ProductCampaignID
            JOIN tblCAMPAIGN C ON PC.CampaignID = C.CampaignID
        WHERE C.EndDate > A.DatePlaced
    )
    SET @Ret = 1
    RETURN @Ret
END
go

