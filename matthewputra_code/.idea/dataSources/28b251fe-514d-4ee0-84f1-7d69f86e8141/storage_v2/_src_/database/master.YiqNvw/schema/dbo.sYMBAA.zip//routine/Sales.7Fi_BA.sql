create function Sales(@PK int)
returns numeric(6,2) 
as 
begin
declare @percent numeric(5,2) = 
(select SA.SaleAmount 
from tblSALE_AMOUNT SA
	join tblMERCHANDISE_SALE MS
		on MS.SaleAmountID = SA.SaleAmountID
where MS.MerchandiseSaleID = @PK
)
declare @norm numeric(6,2) =
(select MST.Price
from tblMERCHANDISE_SALE MS
	join tblMERCHANDISE_STORE MST
		on MST.MerchandiseStoreID = MS.MerchandiseStoreID
where MS.MerchandiseSaleID = @PK
)
return @norm - (@norm * @percent)
end
go

