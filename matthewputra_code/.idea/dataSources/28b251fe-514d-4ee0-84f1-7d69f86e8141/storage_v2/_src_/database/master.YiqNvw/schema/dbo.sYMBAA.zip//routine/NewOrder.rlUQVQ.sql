
CREATE PROCEDURE NewOrder
@f_name varchar(50),
@l_name varchar(50),
@b_d DATE,
@p_name varchar(50),
@qty INT,
@odate DATE
AS

IF EXISTS(SELECT *
		FROM PRODUCT P
			JOIN PRODUCT_TYPE PT
				ON P.ProdTypeID = PT.ProdTypeID
		WHERE ProdName = @p_name
			AND ProdTypeName = 'Alcohol')
	IF @b_d > (SELECT GETDATE() - 365.25 * 21)
		BEGIN
			PRINT 'No Alcohol for 21 or under';
			THROW 54665, 'Customer is too young to buy alcohol', 1;
		END

DECLARE @c_id INT, @p_id INT

EXEC getCID
@fname = @f_name,
@lname = @l_name,
@bd = @b_d,
@cid = @c_id OUTPUT
IF @c_id IS NULL
       BEGIN
              PRINT 'Invalid customer info'
              RAISERROR('@c_id cannot be null', 11, 1)
              RETURN
       END

EXEC getPID
@pname  = @p_name,
@pid = @p_id OUTPUT

BEGIN TRAN A1
INSERT INTO [ORDER](CustID, ProdID, Quantity, OrderDate)
VALUES(@c_id, @p_id, @qty, @odate)
IF @@ERROR <> 0
       BEGIN
              PRINT 'Failed to insert into ORDER'
              ROLLBACK TRAN A1
       END
ELSE
       COMMIT TRAN A1
go

