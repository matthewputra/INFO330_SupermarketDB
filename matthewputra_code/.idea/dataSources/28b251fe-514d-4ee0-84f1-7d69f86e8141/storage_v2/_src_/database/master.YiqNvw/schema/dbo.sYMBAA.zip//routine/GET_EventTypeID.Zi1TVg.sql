
------------------------------------------------------------------------------------------------------------
-- NESTED STORED PROCEDURE GET EventTypeID
CREATE PROCEDURE GET_EventTypeID
@ETname VARCHAR(50),
@ETID INT OUTPUT
AS 

SET @ETID = (SELECT EventTypeID
            FROM tblEVENT_TYPE
            WHERE EventTypeName = @ETname)
go

