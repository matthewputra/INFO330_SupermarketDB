CREATE PROCEDURE GetCountryID
@CtyName VARCHAR(30),
@CtyID INT OUTPUT
AS
	SET @CtyID = (SELECT CountryID FROM tblCOUNTRY
					WHERE CountryName = @CtyName)
go

