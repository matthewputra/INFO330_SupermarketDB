
Create Procedure uspNew_Cust_Book_Act_Trip
@C Numeric(8,2), -- Cost
@R Datetime, -- Registime
@St_Time Datetime, -- Start time
@En_Time Datetime, -- End time
@A_Name varchar(50), -- Activity name
@St_Date Datetime, -- StartDate
@En_Date Datetime, -- EndDate
@Capac Int, -- Capacity
@Book_Num char(7), -- Booking number
@Book_Time Datetime,  -- Booking time
@Cust_First varchar(50),
@Cust_Last varchar(50),
@Cust_Birth Date

As
	Declare @CustB_ID Int, @ACTR_ID Int

	Execute mag_getCust_BookID
		@Book_N = @Book_Num,
		@Book_T = @Book_Time,
		@Cust_F = @Cust_First,
		@Cust_L = @Cust_Last,
		@Cust_DOB = @Cust_Birth,
		@CB_ID = @CustB_ID Output

	If @CustB_ID Is Null
	Begin
		Print '@CustB_ID is Null'
		Raiserror('Null is breaking insert statement', 11, 1)
		Return
	End

	Execute mag_getActivity_TripID
		@S_T = @St_Time,
		@E_T = @En_Time,
		@St_D = @St_Date,
		@En_D = @En_Date,
		@Ac_Na = @A_Name,
		@Ca = @Capac,
		@AT_ID = @ACTR_ID Output

	If @ACTR_ID Is Null
	Begin
		Print '@ACTR_ID Is Null'
		Raiserror('Null is breaking insert statement', 11, 1)
		Return
	End

Begin Tran T1
	Insert into tblCUST_BOOK_ACT_TRIP(CustBookingID, ActivityTripID, Cost, RegisTime)
	Values (@CustB_ID, @ACTR_ID, @C, @R)
	If @@ERROR <> 0 
		Begin
			Rollback Tran T1
			End
		Else
			Commit Tran T1
go

