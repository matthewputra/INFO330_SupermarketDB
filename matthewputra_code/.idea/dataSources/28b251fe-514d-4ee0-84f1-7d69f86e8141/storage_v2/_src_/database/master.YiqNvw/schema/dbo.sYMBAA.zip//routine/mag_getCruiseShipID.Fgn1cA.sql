
-- Stored Procedure 2
-- Inserting a new activity that a customer went on

-- Gets ID of a cruiseship
Create Procedure mag_getCruiseShipID
@C_N varchar(50),
@Capac Int,
@M_D Datetime,
@C_ID Int Output
As

Set @C_ID = (Select CruiseshipID
			From tblCRUISESHIP
			Where CruiseshipName = @C_N
				And Capacity = @Capac
				And ManufacturedDate = @M_D)
go

