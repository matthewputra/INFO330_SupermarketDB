Create procedure GetDetailType
@DTName varchar(50),
@DTID INT output
as 
Set @DTID = (select DetailTypeID from tblDETAIL_TYPE where DetailTypeName = @DTName)
go

