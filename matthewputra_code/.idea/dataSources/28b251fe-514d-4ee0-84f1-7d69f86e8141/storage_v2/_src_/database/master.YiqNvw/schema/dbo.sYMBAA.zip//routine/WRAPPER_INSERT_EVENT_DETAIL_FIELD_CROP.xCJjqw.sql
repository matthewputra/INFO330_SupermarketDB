
------------------------------------------------------------------------------------------------------------
-- WRAPPER FOR INSERT EVENT DETAIL FIELD CROP 
CREATE PROCEDURE WRAPPER_INSERT_EVENT_DETAIL_FIELD_CROP
@RUN INT
AS 

-- DECLARE VARIABLES 
DECLARE @Q INT             -- Quantity 
DECLARE @DN VARCHAR(50)    -- DetailName
DECLARE @M VARCHAR(20)     -- Measure 
DECLARE @FN VARCHAR(50)    -- FieldName
DECLARE @FST VARCHAR(50)   -- FieldStreet
DECLARE @FC VARCHAR(20)    -- FieldCity 
DECLARE @FS VARCHAR(2)     -- FieldState
DECLARE @FZ INT            -- FieldZip
DECLARE @CN VARCHAR(50)    -- CropName
DECLARE @EN VARCHAR(50)    -- EventName

DECLARE @Detail_PK INT
DECLARE @Measure_PK INT
DECLARE @FieldCropEvent_PK INT
DECLARE @FieldCrop_PK INT
DECLARE @Event_PK INT
DECLARE @Field_PK INT
DECLARE @Crop_PK INT

SET @Q = (SELECT FLOOR(Rand() * 20)) + 1

--------------------------------------------------
-- WHILE LOOP 
WHILE @RUN > 0 
    BEGIN 
        SET @Detail_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblDETAIL))
        SET @Measure_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblMEASUREMENT))
        SET @FieldCropEvent_PK = (SELECT Rand() * (SELECT COUNT(*) FROM tblFIELD_CROP_EVENT))

        SET @FieldCrop_PK = (SELECT FieldCropID
                            FROM tblFIELD_CROP_EVENT
                            WHERE FieldCropEventID = @FieldCropEvent_PK)

        SET @Event_PK = (SELECT EventID
                            FROM tblFIELD_CROP_EVENT
                            WHERE FieldCropEventID = @FieldCropEvent_PK)

        SET @Field_PK = (SELECT FieldID
                        FROM tblFIELD_CROP
                        WHERE FieldCropID = @FieldCrop_PK)

        SET @Crop_PK = (SELECT CropID
                        FROM tblFIELD_CROP
                        WHERE FieldCropID = @FieldCrop_PK)

        SET @DN = (SELECT DetailName
                    FROM tblDETAIL
                    WHERE DetailID = @Detail_PK)

        SET @M = (SELECT MeasurementUnit
                    FROM tblMEASUREMENT
                    WHERE MeasurementID = @Measure_PK)

        SET @FN = (SELECT FieldName
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FST = (SELECT FieldStreet
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FC = (SELECT FieldCity
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FS = (SELECT FieldState
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @FZ = (SELECT FieldZip
                    FROM tblFIELD
                    WHERE FieldID = @Field_PK)

        SET @CN = (SELECT CropName
                    FROM tblCROP
                    WHERE CropID = @Crop_PK)

        SET @EN = (SELECT EventName
                    FROM tblEVENT
                    WHERE EventID = @Event_PK)
    
        -- EXEC BASED PROCEDURE 
        EXEC INSERT_EVENT_DETAIL_FIELD_CROP
        @Quantity = @Q, 
        @Detail_N = @DN,
        @MEASURE = @M,
        @Field_Name = @FN,
        @Field_STREET = @FST,
        @Field_CITY = @FC,
        @Field_STATE = @FS,
        @Field_ZIP = @FZ,
        @Crop_Name = @CN, 
        @Event_Name = @EN 

        SET @RUN = @RUN - 1
        PRINT @RUN 
    END
go

