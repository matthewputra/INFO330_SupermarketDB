
CREATE PROCEDURE getCID
@fname varchar(50),
@lname varchar(50),
@bd DATE,
@cid INT OUTPUT
AS
SET @cid = (SELECT CustID
			FROM CUSTOMER 
			WHERE Fname = @fname
				AND Lname = @lname
				AND DOB = @bd)
go

