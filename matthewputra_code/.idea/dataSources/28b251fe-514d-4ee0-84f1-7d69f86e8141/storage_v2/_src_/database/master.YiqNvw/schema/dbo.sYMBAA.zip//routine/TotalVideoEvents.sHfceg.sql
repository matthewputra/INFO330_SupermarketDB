
--TotalVideoEvents - Cecilia
--Total events done on a specific video
--Allows us to track interactions with videos to see which are most popular
--Goes in tblVIDEO
CREATE FUNCTION TotalVideoEvents(@VideoID INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	SET @RET = (SELECT COUNT(*)
				FROM tblVIDEO V
				JOIN tblVIDEO_EVENT VE ON V.VideoID = VE.VideoID
				JOIN tblEVENT E ON VE.EventID = E.EventID
				WHERE V.VideoID = @VideoID
				)
	RETURN @RET
END
go

