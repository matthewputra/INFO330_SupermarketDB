CREATE PROCEDURE registration
@F varchar(20),
@L varchar(20),
@C varchar(50),
@D Date
AS
DECLARE @S_ID INT, @C_ID INT
SET @S_ID = 
	(SELECT StudentID
	FROM tblSTUDENT
	WHERE StudentFname = @F
	AND StudentLname = @L)

SET @C_ID =
	(SELECT ClassID
	FROM tblCLASS
	WHERE ClassName = @C)
go

