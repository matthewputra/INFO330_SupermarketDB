
CREATE PROCEDURE GetVenueID
@VName VARCHAR(50),
@C INT,--capacity
@V_ID INT OUTPUT
AS

SET @V_ID = (SELECT VenueID FROM tblVENUES V
              JOIN tblVenue_TypeID VT on VT.VenueTypeID = V.VenueTypeID
			  WHERE VenueName = @VName
			  AND Capacity = @C)
go

