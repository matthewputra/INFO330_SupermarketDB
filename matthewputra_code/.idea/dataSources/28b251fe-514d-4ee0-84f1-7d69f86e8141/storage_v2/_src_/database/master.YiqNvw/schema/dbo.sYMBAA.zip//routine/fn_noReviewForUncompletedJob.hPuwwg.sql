
-- Cannot have review for uncompleted job
CREATE FUNCTION fn_noReviewForUncompletedJob()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = 0
    IF EXISTS (
        SELECT * FROM
        tblREVIEW R
        JOIN tblServiceJobProvider SJP ON R.SerJobProvID = SJP.SerJobProvID
        JOIN tblJob J On J.JobID = SJP.JobID
        JOIN tblJobStatus JS ON J.JobID = JS.JobID
        JOIN tblStatus S ON S.StatusID = JS.StatusID
        WHERE S.StatusName != 'Completed'
    )
    BEGIN
        SET @Ret = 1
    END
    RETURN @Ret
END
go

