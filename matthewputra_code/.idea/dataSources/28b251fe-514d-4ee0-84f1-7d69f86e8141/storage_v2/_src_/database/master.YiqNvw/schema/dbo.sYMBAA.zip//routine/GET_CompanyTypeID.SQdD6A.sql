
------------------------------------------------------------------------------------------------------------
-- NESTED STORED PROCEDURE GET CompanyTypeID
CREATE PROCEDURE GET_CompanyTypeID
@CTName VARCHAR(50),
@CTID INT OUTPUT
AS

SET @CTID = (SELECT CompanyTypeID
            FROM tblCOMPANAY_TYPE
            WHERE CompanyTypeName = @CTName)
go

