
----------- TESTING ----------
CREATE PROCEDURE testprintStuff
@first VARCHAR(50),
@second VARCHAR(50),
@third VARCHAR(50)
AS

IF (@first like 'hello' 
AND @second like 'world'
AND @third like 'bye')
	BEGIN
		PRINT 'Ran procedure printStuff';
		THROW 51000, 'Will throw error here', 1;
	END

EXEC testprintStuff
@first = 'hello',
@second = 'world',
@third = 'bye'
go

