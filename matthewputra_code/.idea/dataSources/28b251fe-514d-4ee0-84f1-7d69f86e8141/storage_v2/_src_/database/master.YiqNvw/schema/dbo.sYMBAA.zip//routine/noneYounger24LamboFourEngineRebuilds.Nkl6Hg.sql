CREATE FUNCTION noneYounger24LamboFourEngineRebuilds()
RETURNS INT
AS BEGIN
	DECLARE @RET INT = 0
	IF EXISTS(SELECT E.EmpID
				FROM tblSERVICE S
					JOIN tblEMP_CAR_SERVICE ECS ON S.ServiceID = ECS.ServiceID
					JOIN tblCAR C ON ECS.CarID = C.CarID
					JOIN tblMODEL MD ON C.ModelID = MD.ModelID
					JOIN tblMFG M ON MD.MfgID = M.MfgID
				WHERE M.MfgName = 'Lamborghini'
					AND E.EmpBirthDate > DateAdd(YEAR, -24, GetDate())
					AND S.ServiceName = 'Engine Rebuild'
				GROUP BY E.EmpID
				HAVING SUM(S.ServiceName) > 4)
			BEGIN
			SET @RET = 1
			END
RETURN @RET
END
go

