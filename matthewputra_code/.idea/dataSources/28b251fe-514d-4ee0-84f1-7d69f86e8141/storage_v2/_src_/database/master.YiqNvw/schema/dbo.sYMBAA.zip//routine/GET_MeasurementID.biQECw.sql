
-------------------------------------------------------------
-- NESTED STORED PROCEDURE GET MeasurementID
CREATE PROCEDURE GET_MeasurementID
@Measure VARCHAR(20),
@MID INT OUTPUT
AS 

SET @MID = (SELECT MeasurementID
            FROM tblMEASUREMENT
            WHERE MeasurementUnit = @Measure)
go

