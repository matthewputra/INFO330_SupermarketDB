-- Gets ProductID given ProductName
CREATE PROCEDURE GetProductID
@P_Name varchar(75),
@P_ID INT OUTPUT
AS
SET @P_ID = (
	SELECT ProductID FROM tblPRODUCT
	WHERE ProductName = @P_Name
)
go

