CREATE PROCEDURE TestERROR AS
	BEGIN
		BEGIN TRY
			SELECT 'This first line in TRY is printed'
			SELECT SQRT(-1) -- Error happens here!
			SELECT 'But the last line in TRY is never printed'
		END TRY
		BEGIN CATCH
		  SELECT
			ERROR_MESSAGE() AS ErrorMessage,
			ERROR_PROCEDURE() AS ErrorProcedure,
			ERROR_NUMBER() AS ErrorNumber,
			ERROR_STATE() AS ErrorState,
			ERROR_SEVERITY() AS ErrorSeverity,
			ERROR_LINE() AS ErrorLine;
		END CATCH
	END;
go

