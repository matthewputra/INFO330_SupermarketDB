-- 6. Get TripID -- Before we got rid of TripName...
CREATE PROC cruise_GetTripID
@ShipName varchar(50),
@Start date,
@End date,
@T_ID INT OUTPUT
AS
SET @T_ID = (SELECT TripID FROM tblTRIP
	WHERE CruiseshipID = (SELECT CruiseshipID FROM tblCRUISESHIP WHERE CruiseshipName = @ShipName)
		AND StartDate = @Start AND EndDate = @End)
go

