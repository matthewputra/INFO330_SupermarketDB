
/*
Write the code to create a stored procedure to create a new class of an existing course.
*/

CREATE PROCEDURE new_class1
@C varchar(20),  --course name
@Q varchar(20),  --quarter name
@Y varchar(4),   --year
@CR varchar(20), --classroom name
@SN varchar(20), --shcedule name
@S varchar(20)   --section
AS
DECLARE @C_ID INT, @Q_ID INT, @CR_ID INT, @S_ID INT
SET @C_ID = 
	(SELECT CourseID
	FROM tblCOURSE
	WHERE CourseName = @C)

SET @Q_ID =
	(SELECT QuarterID
	FROM tblQUARTER
	WHERE QuarterName = @Q)

SET @CR_ID =
	(SELECT ClassroomID
	FROM tblCLASSROOM
	WHERE ClassroomName = @CR)

SET @S_ID =
	(SELECT ScheduleID
	FROM tblSCHEDULE
	WHERE ScheduleName = @SN)

INSERT INTO tblCLASS(CourseID, QuarterID, [YEAR], ClassroomID, ScheduleID, Section)
VALUES(@C_ID, @Q_ID, @Y, @CR_ID, @S_ID, @S)

go

