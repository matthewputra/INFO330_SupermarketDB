 CREATE PROCEDURE GetPetTypeID
 @PTypeName VARCHAR(30),
 @PTypeID INT OUTPUT
 AS
	SET @PTypeID = (SELECT PetTypeID FROM tblPET_TYPE
					WHERE PetTypeName = @PTypeName)
 go

