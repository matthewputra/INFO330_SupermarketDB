/*
1. Write the code to create a computed column to measure the total number of tasks 
each employee has completed in the past 2.5 years.
*/
 
CREATE FUNCTION fn_Calc_TotalTasks(@PK_ID INT)
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 
		(SELECT COUNT(T.TaskID)
		FROM tblTASK T
			JOIN tblCUST_JOB_TASK CJT ON T.TaskID = CJT.TaskID
			JOIN tblEMPLOYEE_SKILL ES ON CJT.EmpSkillID = ES.EmpSkillID
			JOIN tblEMPLOYEE E ON ES.EmpID = E.EmpID
		WHERE E.EmpID = @PK_ID
		AND CJT.EndTime >= DATEADD(year, -2.5, GETDATE()))
	RETURN @Ret
END
go

