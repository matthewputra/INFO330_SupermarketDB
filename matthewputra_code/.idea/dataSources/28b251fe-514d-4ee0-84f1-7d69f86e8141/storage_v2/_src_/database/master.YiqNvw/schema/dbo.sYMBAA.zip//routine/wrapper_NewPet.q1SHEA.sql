Create procedure wrapper_NewPet
@Run int
as
declare 
@PetN varchar(50),
@PT varchar(50),
@Temper varchar(30),
@Location varchar(50),
@Birthday date,
@SexType varchar(20)

declare @Pet_ID int, @Count_ID int, @Disp_ID int, @ST_ID int, @PetNameFind int
DECLARE @PetNameCount int = (select count(PetName) from Pet_Working_Table)
DECLARE @PetTypeCount INT = (SELECT COUNT(*) FROM tblPet_TypeR)
DECLARE @TemperamentCount INT = (SELECT COUNT(*) FROM tblTemperment)
DECLARE @CountryCount INT = (SELECT COUNT(*) FROM tblCountry)
DECLARE @GenderCount INT = (SELECT COUNT(*) FROM tblGender)

while @Run > 0
begin
set @PetNameFind = (select Rand() * @PetNameCount +1)
set @Pet_ID = (SELECT RAND() * @PetTypeCount + 1)
set @Count_ID = (select rand() * @CountryCount +1)
set @Disp_ID = (select rand() * @TemperamentCount +1)
set @ST_ID = (select rand() * @GenderCount +1)

SET @PetN = (SELECT PetName FROM tblPet_Working_Table WHERE PetPK = @PetNameFind)
Set @PT = (Select PetTypeName from tblPet_TypeR where PetTypeID = @Pet_ID)
SET @Temper = (Select TempName from tblTemperment where TempID = @Disp_ID)
SET @Location = (Select CountryName from tblCountry where CountryID = @Count_ID)
Set @Birthday = (Select GetDate() - @PetNameCount)
Set @SexType = (Select GenderName from tblGender where GenderID = @ST_ID)

exec usp_NewPet
@PetNamey = @PetN,
@Pet_Types = @PT,
@Tempers = @Temper,
@Locs = @Location,
@Birthy = @Birthday,
@SeTY = @SexType
Print @Run
Set @Run = @Run - 1
End
go

