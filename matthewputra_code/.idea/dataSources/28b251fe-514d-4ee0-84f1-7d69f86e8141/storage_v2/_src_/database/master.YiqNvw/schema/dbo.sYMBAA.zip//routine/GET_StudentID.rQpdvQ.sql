CREATE PROCEDURE GET_StudentID
@StudentFname varchar(50),
@StudentLname varchar(50),
@BirthDate DATE,
@SID INT OUTPUT
AS 

SET @SID = (SELECT StudentID
            FROM tblSTUDENT
            WHERE Fname = @StudentFname
            AND Lname = @StudentLname
            AND DateOfBirth = @BirthDate)

IF @SID IS NULL
    BEGIN 
        PRINT ('@SID is NULL, it cannot be NULL')
        RAISERROR ('@SID is NULL',11,1)
    END
go

