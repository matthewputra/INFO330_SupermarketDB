
------------------------------------------------------------------------------------------------------------
-- NESTED STORED PROCEDURE GET FieldCropEventID
CREATE PROCEDURE GET_FieldCropEventID
@E_BeginD DATE,
@FC_BeginD DATE,
@F_N VARCHAR(50),
@F_Street VARCHAR(50),
@F_City VARCHAR(20),
@F_State VARCHAR(2),
@F_Zip INT,
@Crop_N VARCHAR(50),
@Event_N VARCHAR(50),
@FCEID INT OUTPUT
AS 
DECLARE @FC_ID INT, @E_ID INT

-- EXEC GET FieldCropID 
EXEC GET_FieldCropID
@Field_N = @F_N,
@Field_Street = @F_Street,
@Field_City = @F_City,
@Field_State = @F_State,
@Field_Zip = @F_Zip,
@Crop_Name = @Crop_N,
@FCID = @FC_ID OUTPUT

IF @FC_ID IS NULL
    BEGIN
        PRINT('@FC_ID is NULL, it cannot be null')
        RAISERROR('@FC_ID is NULL',11,1)
        RETURN
    END

-- EXEC GET EventID
EXEC GET_EventID
@Eventname = @Event_N,
@EID = @E_ID OUTPUT

IF @E_ID IS NULL
    BEGIN
        PRINT('@E_ID is NULL, it cannot be null')
        RAISERROR('@E_ID is NULL',11,1)
        RETURN
    END

SET @FCEID = (SELECT FieldCropEventID
            FROM tblFIELD_CROP_EVENT
            WHERE EventBeginDate = @E_BeginD
            AND FieldCropID = @FC_ID
            AND EventID = @E_ID)
go

