

CREATE PROCEDURE getStudentID
    @SF VARCHAR(100),
    @SL VARCHAR(100),
    @DOB DATE,
    @rsid INT OUTPUT
AS
BEGIN
    SET @rsid = (
        SELECT StudentID FROM Student
        WHERE 
            StudentFName = @SF
            AND StudentLName = @SL
            AND StudentDOB = @DOB
    )
END
go

