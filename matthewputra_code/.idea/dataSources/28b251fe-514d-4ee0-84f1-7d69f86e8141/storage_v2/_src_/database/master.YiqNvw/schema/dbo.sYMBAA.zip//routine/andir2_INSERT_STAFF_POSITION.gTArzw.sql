
--DROP PROCEDURE andir2_INSERT_STAFF_POSITION
CREATE PROCEDURE andir2_INSERT_STAFF_POSITION
@DepName		varchar(75),
@StaffFirstName 	varchar(60),
@StaffLastName	varchar(60),
@StaffBirthday	DATE,
@PosName		varchar(50),
@BeginDate		DATE,
@EndDate		DATE

AS
DECLARE @S_ID INT, @P_ID INT, @D_ID INT

EXEC andir2_GetStaffID
@StaffLName 	= 	@StaffFirstName,
@StaffFName 	= 	@StaffLastName,	
@StaffBday	= 	@StaffBirthday,	
@StaffID	= 	@S_ID OUTPUT

IF @S_ID IS NULL
BEGIN
PRINT '@S_ID is Null!'
RAISERROR('@S_ID cannot be NULL; check spelling;', 11,1)
RETURN
END

EXEC andir2_GetDepartmentID
@DepartmentName 	= @DepName,
@DepartmentID		= @D_ID OUTPUT

IF @D_ID IS NULL
BEGIN
PRINT '@D_ID is Null!'
RAISERROR('@D_ID cannot be NULL; check spelling;', 11,1)
RETURN
END

EXEC andir2_GetPositionID
@PostionName		= @PosName,
@PostionID		= @P_ID OUTPUT

IF @P_ID IS NULL
BEGIN
PRINT '@P_ID is Null!'
RAISERROR('@P_ID cannot be NULL; check spelling;', 11,1)
RETURN
END

BEGIN TRAN G1
INSERT INTO tblSTAFF_POSITION([StaffID], [PositionID], [BeginDate], [EndDate], [DeptID])
VALUES(@S_ID,@P_ID,@BeginDate,@EndDate,@D_ID)
IF @@ERROR <> 0
BEGIN
PRINT 'TRAN G1 is terminating due to some error'
ROLLBACK TRAN G1
END
ELSE
COMMIT TRAN G1
go

