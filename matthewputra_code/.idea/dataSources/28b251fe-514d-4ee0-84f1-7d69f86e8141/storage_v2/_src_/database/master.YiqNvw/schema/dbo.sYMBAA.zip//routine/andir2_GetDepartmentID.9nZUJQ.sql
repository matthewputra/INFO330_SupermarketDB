CREATE PROCEDURE andir2_GetDepartmentID
@DepartmentName 	varchar(75),
@DepartmentID		INT OUTPUT
AS
	
SET @DepartmentID = (SELECT DeptID From tblDEPARTMENT WHERE DeptName = @DepartmentName)
go

