CREATE PROCEDURE getShrinkageTypeID
@ShrinkTypeName VARCHAR(50),
@ShrinkTypeID INT OUTPUT 
AS
SET @ShrinkTypeID = (SELECT ShrinkTypeID FROM tblSHRINKAGE_TYPE WHERE ShrinkTypeName = @ShrinkTypeName)
go

