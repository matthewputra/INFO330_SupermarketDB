
-- Stored procedure for inserting a new activity
Create Procedure mag_uspNewActivity
@A_N varchar(50),
@A_D varchar(500),
@A_C Int,
@A_Cost Numeric(8,2),
@Act_Na varchar(50),
@Cruise_Na varchar(50),
@Cruise_Capac Int,
@Cruise_MaD	Datetime,
@Venue_Na	varchar(50),
@Venue_Capac Int
As
	
	Declare @ActTy_ID Int, @Venue_ID Int

	Execute  mag_getActivityTypeID
		@AT_N = @Act_Na,
		@AT_ID = @ActTy_ID Output

	If @ActTy_ID Is Null
	Begin
		Print '@ActTy_ID is Null'
		Raiserror('Null is breaking insert statement', 11, 1)
		Return
	End

	Execute mag_getVenueID
		@V_N = @Venue_Na,
		@V_Capac = @Venue_Capac,
		@Cru_N = @Cruise_Na,
		@Cru_C = @Cruise_Capac,
		@Cru_MD = @Cruise_Mad,
		@V_ID = @Venue_ID Output

	If @Venue_ID Is Null
	Begin
		Print '@Venue_ID Is Null'
		Raiserror('Null is breaking insert statement', 11, 1)
		Return
	End

	Begin Tran T1
		Insert Into tblACTIVITY(VenueID, ActivityTypeID, ActivityName, ActivityDescr, Capacity, Cost)
		Values (@Venue_ID, @ActTy_ID, @A_N, @A_D, @A_C, @A_Cost)
		If @@ERROR <> 0
			Begin
				Rollback Tran t1
			End
		Else
			Commit Tran T1
go

