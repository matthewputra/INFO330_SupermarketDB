create procedure wrapper_gjoleNewOrder
@RUN int
as
Declare @F varchar(20), @L varchar(20), @B date, @P varchar(50), @OD date, @Q int

declare @CustRowCount int =(select count(*) from tblCustomer)
declare @ProRowCOunt int = (select count(*) from tblProduct)
declare @C_PK int, @P_PK int

while @RUN > 0
begin
set @C_PK = (select rand() * @CustRowCount + 1)
set @P_PK = (select rand() * @ProRowCOunt + 1)
set @F = (select CustomerFname from tblCustomer where CustomerID = @C_PK)
set @L = (select CustomerLname from tblCustomer where CustomerID = @C_PK)
set @B = (select DateOfBirth from tblCustomer where CustomerID = @C_PK)
set @P = (select ProdName from tblProduct where ProductID = @P_PK)
set @OD = (select DateAdd(Day, Rand() * DateDiff(Day, '1-1-2000', '1-1-2020'), '1-1-2000'))
set @Q = (select rand() * 100 + 1)

exec gjoleNewOrder
@CFName = @F,
@CLName = @L,
@CDOB = @B,
@PName = @P,
@Qty = @Q,
@ODate = @OD

print @RUN
set @RUN = @RUN -1
end
go

