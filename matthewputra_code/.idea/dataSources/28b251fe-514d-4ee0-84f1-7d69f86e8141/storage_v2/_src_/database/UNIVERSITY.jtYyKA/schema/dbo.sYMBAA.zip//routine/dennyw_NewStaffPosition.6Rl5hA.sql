CREATE PROCEDURE dennyw_NewStaffPosition
@Firsty VARCHAR(60),
@Lasty VARCHAR(60),
@Birthy Date,
@DeptName VARCHAR(75),
@PosName VARCHAR(50),
@Begin Date,
@End Date

AS 

DECLARE @S_ID INT, @D_ID INT, @P_ID INT

EXEC dennyw_GetStaffID
@Fname = @Firsty,
@Lname = @Lasty,
@BDate = @Birthy,
@Staffy = @S_ID OUTPUT

-- error-handle in case @S_ID IS NULL
IF @S_ID IS NULL
    BEGIN
        PRINT '@S_ID is NULL and the following transaction will fail'
        RAISERROR ('@S_ID cannot be NULL', 11, 1)
        RETURN
    END

SET @D_ID = (SELECT DeptID 
             FROM tblDEPARTMENT 
             WHERE DeptName = @DeptName)
-- error-handle in case @D_ID IS NULL

SET @P_ID = (SELECT PositionID 
             FROM tblPOSITION 
             WHERE PositionName = @PosName)
-- error-handle in case @P_ID IS NULL

-- create explicit transaction 
BEGIN TRAN G1
INSERT INTO tblSTAFF_POSITION (StaffID, DeptID, PositionID, BeginDate, EndDate)
VALUES (@S_ID, @D_ID, @P_ID, @Begin, @End)
-- check if there is a train-wreck ahead 
IF @@ERROR <> 0
    ROLLBACK TRAN G1
ELSE    
    COMMIT TRAN G1
go

