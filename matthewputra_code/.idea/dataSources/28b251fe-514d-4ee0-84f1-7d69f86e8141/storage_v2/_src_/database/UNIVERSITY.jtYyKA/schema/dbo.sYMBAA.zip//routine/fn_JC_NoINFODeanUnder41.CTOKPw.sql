CREATE FUNCTION fn_JC_NoINFODeanUnder41()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS (SELECT *
				FROM tblCOLLEGE C
					JOIN tblDEPARTMENT D ON C.CollegeID = D.CollegeID
					JOIN tblSTAFF_POSITION SP ON D.DeptID = SP.DeptID
					JOIN tblPOSITION P ON SP.PositionID = P.PositionID
					JOIN tblSTAFF S ON SP.StaffID = S.StaffID
				WHERE C.CollegeName = 'Information School'
				AND S.StaffBirth > DATEADD(Year, -41, GETDATE()))
	SET @RET = 1
RETURN @RET
END
go

