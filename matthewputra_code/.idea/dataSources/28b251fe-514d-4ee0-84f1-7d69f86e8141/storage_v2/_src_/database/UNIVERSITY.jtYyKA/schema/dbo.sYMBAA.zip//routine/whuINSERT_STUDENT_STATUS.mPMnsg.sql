CREATE PROCEDURE whuINSERT_STUDENT_STATUS
@Fname VARCHAR(50),
@Lname VARCHAR(50),
@Birth DATE, 
@Status VARCHAR(50),
@Begin DATE,
@End DATE
AS
DECLARE @St_ID INT, @Sta_ID INT

/*SET @St_ID = (Select StudentID FROM tblSTUDENT 
				WHERE StudentFname = @FName 
				AND StudentLname = @LName 
				AND StudentBirth = @Birth)
*/
EXEC whuGetStudentID
@StuFName = @Fname,
@StuLName = @Lname,
@StuDOB = @Birth,
@StudentID = @St_ID OUTPUT

IF @St_ID IS NULL
	BEGIN
		PRINT('@St_ID is null, check spelling for names')
		RAISERROR('@St_ID cannot be null, statement terminating', 11,1)
		RETURN
	END

/* SET @Sta_ID = (Select StatusID FROM tblSTATUS WHERE StatusName = @Status)
*/
EXEC whuGetStatusID
@StatusName = @Status,
@StatusID =  @Sta_ID OUTPUT

IF @Sta_ID IS NULL
	BEGIN
		PRINT '@Sta_ID is null, check spelling for status';
		THROW 56789, '@Sta_ID cannot be null', 11;
		RETURN
	END

BEGIN TRAN W1
INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate)
VALUES(@St_ID, @Sta_ID, @Begin, @End)
IF @@ERROR <> 0
	BEGIN 
		PRINT 'Error at the end, rolling back soon '
		ROLLBACK TRAN W1
	END
ELSE
	COMMIT TRAN W1
go

