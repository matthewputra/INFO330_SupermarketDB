CREATE PROCEDURE apeng_INSERT_STUDENT_STATUS
@StudentFName VARCHAR(50),
@StudentLName VARCHAR(50),
@BirthDate DATE,
@Status VARCHAR(50),
@Begin DATE,
@End DATE
AS
DECLARE
@StudentID INT,
@StatusID INT

EXECUTE apeng_GET_STUDENT_ID
@FName = @StudentFName,
@LName = @StudentLName,
@Birthday = @BirthDate,
@StuID = @StudentID OUTPUT

IF @StudentID IS NULL
	BEGIN
		PRINT '@StudentID was returned as NULL. Check your spelling.'
		RAISERROR ('@StudentID cannot be NULL. Session terminated.',11,1)
		RETURN
	END

EXECUTE apeng_GET_STATUS_ID
@StatusName = @Status,
@StatID = @StatusID OUTPUT

IF @StatusID IS NULL
	BEGIN
		PRINT '@StatusID was returned as NULL. Check your spelling.'; --THROW always needs a semicolon
		THROW 34508, '@StatusID cannot be NULL.', 1;
	END

BEGIN TRAN G1
INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate)
VALUES (@StudentID, @StatusID, @Begin, @End)
IF @@ERROR <> 0
	BEGIN
		PRINT 'Error detected. Rolling back transaction'
		ROLLBACK TRAN G1
	END
ELSE
	COMMIT TRAN G1


--CREATE PROCEDURE apeng_GET_STUDENT_ID
--@FName varchar(50),
--@LName varchar(50),
--@Birthday DATE,
--@StuID INT OUTPUT
--AS
--SET @StuID = (SELECT StudentID FROM tblSTUDENT WHERE StudentBirth = @Birthday AND StudentFname = @FName AND StudentLname = @LName)


--CREATE PROCEDURE apeng_GET_STATUS_ID
--@StatusName varchar(50),
--@StatID INT OUTPUT
--AS
--SET @StatID = (SELECT StatusID FROM tblSTATUS WHERE StatusName = @StatusName)
go

