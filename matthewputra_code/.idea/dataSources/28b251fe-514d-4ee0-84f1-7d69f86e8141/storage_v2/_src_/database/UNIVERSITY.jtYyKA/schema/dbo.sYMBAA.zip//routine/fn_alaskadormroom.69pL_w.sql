create function fn_alaskadormroom()
returns int
as 
begin
	declare @ret int = 0
		if exists 
		(select * 
		from tblstudent s 
		join tblSTUDENT_DORMROOM sd on s.StudentID = sd.StudentID
		join tblDORMROOM d on sd.DormRoomID = d.DormRoomID
		join tblBUILDING b on d.BuildingID = b.buildingid 
		join tblLOCATION l on b.LocationID = l.Locationid 
		join tblDORMROOM_TYPE dt on d.DormRoomTypeID = dt.DormRoomTypeID
		Where s.StudentBirth > DATEADD(year, -23, getdate())
		and l.locationname = 'West Campus'
		and s.StudentPermState = 'Alaska, AK'
		and dt.DormRoomTypeName = 'Triple'
		)
	set @ret = 1
	return @ret 
	end
go

