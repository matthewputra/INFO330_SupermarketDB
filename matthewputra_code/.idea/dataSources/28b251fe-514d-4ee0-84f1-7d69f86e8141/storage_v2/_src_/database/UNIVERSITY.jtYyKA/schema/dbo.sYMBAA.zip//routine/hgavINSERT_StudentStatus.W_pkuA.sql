CREATE PROCEDURE hgavINSERT_StudentStatus
@Fname VARCHAR(20),
@Lname VARCHAR(20),
@Birth Date,
@Status VARCHAR(50),
@Begin Date,
@End Date
AS
DECLARE @Stu_ID INT, @Sta_ID INT


SET @Stu_ID = (SELECT StudentID FROM tblSTUDENT WHERE StudentFname = @Fname
												AND StudentLname = @Lname
												AND StudentBirth = @Birth)
IF @Stu_ID IS NULL 
	BEGIN
		PRINT 'Hey...@Stu_ID is NULL; check spelling'
		RAISERROR ('@Stu_ID cannot be NULL; statement terminiating', 11,1)
		RETURN

	END									

SET @Sta_ID = (SELECT StatusID FROM tblSTATUS WHERE StatusName = @Status)

IF @Sta_ID IS NULL 
	BEGIN
		PRINT 'Hey...@Sta_ID is NULL; check spelling';
		THROW 56772, '@Sta_ID Cannot be Null', 1;
	END

BEGIN TRAN G1
INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate)
VALUES (@Stu_ID, @Sta_ID, @Begin, @End)

IF @@ERROR <> 0
	BEGIN
	PRINT 'error at the very end; rolling back tran'
	ROLLBACK TRan G1
	END
ELSE 
	Commit Tran G1
go

