
CREATE PROCEDURE get_UnitID
@UnitName VARCHAR(50),
@U_ID INT OUTPUT
AS 

SET @U_ID = (SELECT BuildingID FROM tblBUILDING Where BuildingName = @UnitName)
go

