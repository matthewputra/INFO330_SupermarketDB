CREATE PROCEDURE whuGetStatusID
@StatusName VARCHAR(50),
@StatusID INT OUTPUT
AS
SET @StatusID = (Select StatusID FROM tblSTATUS WHERE StatusName = @StatusName)
go

