CREATE PROCEDURE uspNewClassofCourse
@Year char(4),
@Section varchar(10),
@CourseName varchar(50),
@Quarter varchar(10),
@Classroom varchar(50),
@SchedName varchar(50),
@Schedbt TIME,
@Schedet TIME
AS
DECLARE @CourseID INT, @QuarterID INT, @ClassroomID INT, @ScheduleID INT
SET @CourseID = (SELECT CourseID
				 FROM tblCOURSE
				 WHERE CourseName = @CourseName)
SET @QuarterID = (SELECT QuarterID
				  FROM tblQUARTER
				  WHERE QuarterName = @Quarter)
SET @ClassroomID = (SELECT ClassroomID
					FROM tblCLASSROOM
					WHERE ClassroomName = @Classroom)
SET @ScheduleID = (SELECT ScheduleID
				   FROM tblSCHEDULE
				   WHERE ScheduleID = @ScheduleID
				   AND SchedBeginTime = @Schedbt
				   AND SchedEndTime = @Schedet)
INSERT INTO tblCLASS(CourseID, QuarterID, [YEAR], ClassroomID, ScheduleID, Section)
VALUES(@CourseID, @QuarterID, @Year, @ClassroomID, @ScheduleID, @Section)
go

