CREATE FUNCTION fn_mbCalcNumRegistered(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
        (SELECT COUNT(CL.StudentID)
            FROM tblCLASS_LIST CL
            JOIN tblCLASS tC on CL.ClassID = tC.ClassID
        WHERE tC.ClassID = @PK)
    RETURN @RET
END
go

