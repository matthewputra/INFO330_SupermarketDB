-- an existing student to an existing class.
CREATE PROCEDURE uspClassList
    @Fname VARCHAR(60),
    @Lname VARCHAR(60),
    @Bdate DATE,
    @CourseName VARCHAR(75),
    @Quarter VARCHAR(30),
    @Year CHAR(4),
    @Section VARCHAR(4),
    @Grade DECIMAL(3,2),
    @Rdate DATE,
    @Rfee NUMERIC(10,2)
AS
DECLARE @C_ID INT, @S_ID INT
SET @C_ID = (SELECT C.ClassID
            FROM tblCLASS AS C
            JOIN tblCOURSE AS CO ON C.CourseID = CO.CourseID
            JOIN tblQUARTER AS Q ON C.QuarterID = Q.QuarterID
            WHERE CO.CourseName = @CourseName AND
                  Q.QuarterName = @Quarter AND
                  C.[YEAR] = @Year AND
                  C.Section = @Section)
SET @S_ID = (SELECT S.StudentID
            FROM tblSTUDENT AS S
            WHERE S.StudentFname = @Fname AND
                  S.StudentLname = @Lname AND
                  S.StudentBirth = @Bdate)
INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, @Grade, @Rdate, @Rfee);
go

