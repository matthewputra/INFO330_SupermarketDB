CREATE FUNCTION apengProfs400BioPhilSummer()
RETURNS INTEGER
AS
BEGIN
	DECLARE @Ret INT = 0 --This needs to match the RETURNS value. 0 means that the data has not violated rules
	IF EXISTS ( --Conditions for violation
	SELECT *
	FROM tblINSTRUCTOR ins
	JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE inst ON ins.InstructorID = inst.InstructorID
	JOIN tblINSTRUCTOR_TYPE it ON inst.InstructorTypeID = it.InstructorTypeID
	JOIN tblINSTRUCTOR_CLASS ic ON ins.InstructorID = ic.InstructorID
	JOIN tblCLASS c ON ic.ClassID = c.ClassID
	JOIN tblQUARTER q ON c.QuarterID = q.QuarterID
	JOIN tblCOURSE cr ON c.CourseID = cr.CourseID --This is the logic to test for 
	JOIN tblDEPARTMENT dpt ON cr.DeptID = dpt.DeptID
	WHERE it.InstructorTypeName IN ('Assistant Professor', 'Associate Professor') AND
	q.QuarterName = 'Summer' AND
	dpt.DeptName IN ('Philosophy', 'Biology') AND
	cr.CourseNumber LIKE '4%')
	SET @Ret = 1 --If data matches the violation conditions, change @Ret into 1 
	RETURN @Ret
END
go

