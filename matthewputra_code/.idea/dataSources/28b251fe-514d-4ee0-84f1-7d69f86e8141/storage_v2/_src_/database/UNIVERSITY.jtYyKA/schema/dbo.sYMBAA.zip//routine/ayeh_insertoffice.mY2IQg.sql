CREATE PROCEDURE ayeh_insertoffice
@bldName varchar(125),
@ot_name varchar(50),
@oname varchar(25)
AS
    DECLARE @bID INT, @otID INT
     --SET @bID = (SELECT BuildingID FROM tblBUILDING WHERE BuildingName = @bldName)
    --Replace with a stored proc to run parallel
    EXEC ayehGetbID
        @BuildingName = @bldName,
        @BldgID = @bID OUTPUT -- MAKE sure to add output, handoff @BldgID to @bID

--error handling --> ex of old-school RAISEERROR
    IF @bID IS NULL
        BEGIN
            print'hey..system cant locate an ID ' ;
            RAISERROR ('@bID is null; the INSERT statement is being terminated', 11, 1);
            RETURN
        END

    --SET @otID = (SELECT OfficeTypeID FROM tblOFFICE_TYPE WHERE OfficeTypeName = @ot_name)
    EXEC ayehGetotID
    @OffType = @ot_name,
    @OffTypeID = @otID OUTPUT --@OffTypeID is a parameter, @otID is a variable
--error handling

    IF @otID IS NULL
        BEGIN
            PRINT 'Hey...system cannot locate an ID value for office type';
            THROW 50445,'@bID is NULL; the INSERT statement is being terminated', 1;
        end --above 50000

INSERT INTO tblOFFICE(OfficeName, OfficeTypeID, BuildingID)
VALUES(@oname, @otID, @bID)
go

