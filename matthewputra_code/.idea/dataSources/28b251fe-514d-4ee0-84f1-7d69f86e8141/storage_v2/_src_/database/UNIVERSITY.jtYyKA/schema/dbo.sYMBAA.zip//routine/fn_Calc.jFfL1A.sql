CREATE FUNCTION fn_Calc(@PK INT)
RETURNS INT
    AS
BEGIN
    DECLARE @RET INT = (SELECT COUNT(cl.studentid)
        from tblClass_list cl
        INNER JOIN tblClass c on Cl.classID = c.classid
        WHERE c.classid = @pk)
    return @RET
end
go

