CREATE PROCEDURE whuGetStudentID
@StuFName VARCHAR(50),
@StuLName VARCHAR(50),
@StuDOB DATE,
@StudentID INT OUTPUT
AS
SET @StudentID = (Select StudentID FROM tblSTUDENT 
				  WHERE StudentFname = @StuFName 
				  AND StudentLname = @StuLName
				  AND StudentBirth = @StuDOB)
go

