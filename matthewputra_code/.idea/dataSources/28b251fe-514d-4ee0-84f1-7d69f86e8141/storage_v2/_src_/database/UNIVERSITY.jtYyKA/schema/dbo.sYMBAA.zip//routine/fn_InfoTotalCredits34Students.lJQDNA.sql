/* 1) Write the SQL to create a computed column to track #Info credits above 3.4 for each student */

CREATE FUNCTION fn_InfoTotalCredits34Students(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = (select SUM(C.Credits)
						from tblCOURSE C
						JOIN tblDEPARTMENT D ON D.DeptID = C.DeptID
						JOIN tblCOLLEGE CO ON CO.CollegeID = D.CollegeID
						JOIN tblCLASS CL ON CL.CourseID = C.CourseID
						JOIN tblCLASS_LIST CLL ON CLL.ClassID = CL.ClassID
						JOIN tblSTUDENT S ON S.StudentID = CLL.StudentID
					where S.StudentID = @PK
					AND CO.CollegeName = 'Information School'
					AND CLL.Grade > 3.4)
	RETURN @Ret
END
go

