
CREATE FUNCTION fn_NoFlorida2118Creds()
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (SELECT S.StudentID
				FROM tblSTUDENT S
					JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
					JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
					JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
				WHERE S.StudentPermState = 'Florida, FL'
				AND StudentBirth > DateAdd(Year, -21, GetDate())
				AND RegistrationDate > DateAdd(MONTH, -4, GetDate())
				GROUP BY S.StudentID
				HAVING SUM(CR.Credits) >18) 
				
	SET @Ret = 1
RETURN @Ret
END
go

