CREATE PROC GerRatingID
@Rating_Name VARCHAR(50),
@Rating_ID  INT OUTPUT
AS
    SET @Rating_ID = (SELECT RatingID
                     FROM   RATING
                     WHERE  RatingName = @Rating_Name)
go

