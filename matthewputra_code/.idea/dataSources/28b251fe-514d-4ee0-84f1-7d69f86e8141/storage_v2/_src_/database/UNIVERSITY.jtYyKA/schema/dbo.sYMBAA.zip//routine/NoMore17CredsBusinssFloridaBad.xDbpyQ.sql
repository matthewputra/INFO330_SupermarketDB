CREATE FUNCTION dbo.NoMore17CredsBusinssFloridaBad()
-- parentheses: function
RETURNS INT
-- INT: make evaluation simple
-- return any kind of data type
-- single word: varchar
AS
    BEGIN
        DECLARE @RET INT = 0
--         @RET: return
--         populate a variable and send it back
--         start out with a default value
        IF EXISTS(
            SELECT tS.StudentID, SUM(tC.Credits)
            FROM tblCollege C
                JOIN tblDEPARTMENT tD on C.CollegeID = tD.CollegeID
                JOIN tblCOURSE tC on tD.DeptID = tC.DeptID
                JOIN tblCLASS t on tC.CourseID = t.CourseID
                JOIN tblCLASS_LIST tCL on t.ClassID = tCL.ClassID
                JOIN tblSTUDENT tS on tCL.StudentID = tS.StudentID
                JOIN tblQUARTER tQ on t.QuarterID = tQ.QuarterID
            WHERE tS.StudentPermState = 'Florida, FL'
            AND C.CollegeName LIKE '%BUSINESS%'
            AND tQ.QuarterName = 'WINTER'
--             make it for one and only one quarter in one year
--             SELECT YEAR(GETDATE()): 2020
            AND YEAR(tCL.RegistrationDate) = YEAR(GETDATE())
            GROUP BY tS.StudentID
            HAVING SUM(tC.Credits) > 13
            )
--         evaluation: evaluate on something if that exists
--         some logic to find bad data
        SET @RET = 1
--         if we find bad data, set...
        RETURN @RET
    END
go

