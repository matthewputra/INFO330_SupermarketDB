CREATE FUNCTION fn_WA$495()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS (SELECT S.StudentID
				FROM tblCLASS_LIST CL
					JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
					JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
					JOIN tblSTUDENT S ON CL.StudentID = S.StudentID
				WHERE S.StudentPermState = 'Washington, WA'
				AND CL.RegistrationFee >= 495
				GROUP BY S.StudentID)
	SET @RET = 1
	RETURN @RET 
	END
go

