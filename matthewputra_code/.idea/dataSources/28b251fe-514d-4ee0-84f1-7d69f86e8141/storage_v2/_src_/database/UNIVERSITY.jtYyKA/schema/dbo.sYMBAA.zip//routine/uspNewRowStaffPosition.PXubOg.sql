CREATE PROCEDURE uspNewRowStaffPosition
@Fname varchar(60),
@Lname varchar(60),
@Address varchar(120),
@City varchar(75),
@State varchar(25),
@Zip varchar(25),
@Bdate date,
@NetID varchar(20),
@Email varchar(80),
@Gender char(1),
@Position varchar(50),
@Dept varchar(75),
@Begin datetime
AS
DECLARE @STAFF_ID INT, @POSITION_ID INT, @DEPT_ID INT
INSERT INTO tblSTAFF (StaffFName, StaffLName, StaffAddress, StaffCity, StaffState, StaffZip, StaffBirth, StaffNetID, StaffEmail, Gender)
VALUES (@Fname, @Lname, @Address, @City, @State, @Zip, @Bdate, @NetID, @Email, @Gender)
SET @STAFF_ID = SCOPE_IDENTITY()
SET @POSITION_ID = (
    SELECT PositionID
    FROM tblPOSITION
    WHERE PositionName = @Position
    )
SET @DEPT_ID = (
    SELECT DeptID
    FROM tblDEPARTMENT
    WHERE DeptName = @Dept
    )
INSERT INTO tblSTAFF_POSITION (StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES (@STAFF_ID, @POSITION_ID, @Begin, NULL, @DEPT_ID)
go

