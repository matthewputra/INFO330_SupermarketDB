CREATE PROCEDURE UpdateEndDateStaffPos
@ProdName varchar(50),
@F varchar(20),
@L varchar(20),
@Birth date,
@Pname varchar(20),
@End date
AS
DECLARE @S_ID INT, @P_ID INT, @SP_ID INT
SET @S_ID = (SELECT StaffID FROM tblSTAFF
				WHERE StaffFName = @F
				AND StaffLName = @L
				AND StaffBirth = @Birth)
SET @P_ID = (SELECT PositionID FROM tblPOSITION
				WHERE PositionName = @Pname)
SET @SP_ID = (SELECT StaffPositionID FROM tblSTAFF_POSITION 
				WHERE StaffID = @S_ID
				AND PositionID = @P_ID)
IF @S_ID IS NULL
	BEGIN
		PRINT '@S_ID is NULL... this will not work. Check spelling'
		RAISERROR ('@S_ID cannot be NULL', 11, 1)
		RETURN
	END
IF @P_ID IS NULL
	BEGIN
		PRINT '@P_ID is NULL... this will not work. Check spelling'
		RAISERROR ('@P_ID cannot be NULL', 11, 1)
		RETURN
	END
IF @SP_ID IS NULL
	BEGIN
		PRINT '@SP_ID is NULL... this will not work. Check spelling'
		RAISERROR ('@SP_ID cannot be NULL', 11, 1)
		RETURN
	END
BEGIN TRAN J1
UPDATE tblSTAFF_POSITION
SET EndDate = @End
WHERE StaffPositionID = @SP_ID
IF @@ERROR <> 0
	ROLLBACK TRAN J1
ELSE
	COMMIT TRAN J1

go

