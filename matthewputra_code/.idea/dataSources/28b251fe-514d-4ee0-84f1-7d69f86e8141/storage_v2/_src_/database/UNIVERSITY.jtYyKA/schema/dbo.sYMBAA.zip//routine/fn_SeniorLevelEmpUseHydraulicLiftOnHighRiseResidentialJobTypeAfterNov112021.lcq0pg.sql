CREATE FUNCTION fn_SeniorLevelEmpUseHydraulicLiftOnHighRiseResidentialJobTypeAfterNov112021()
RETURNS INT
BEGIN
DECLARE @RET INT = 0
    IF EXISTS (SELECT *
                FROM tblEMPLOYEE E
                JOIN tblEMPLOYEE_SKILL ES ON E.EmpID = ES.EmpID
                JOIN tblLEVEL L ON ES.LevelID = L.LevelID
                JOIN tblSKILL S ON ES.SkillID = S.SkillID
                JOIN tblSKILL_TYPE ST ON S.SkillTypeID = S.SkillTypeID
                JOIN tblCUST_JOB_TASK CJT ON ES.EmpSkillID = CJT.EmpSkillID
                JOIN tblJOB J ON CJT.JobID = J.JobID
                JOIN tblJOB_TYPE JT ON J.JobTypeID = JT.JobTypeID
                JOIN tblEQUIPMENT EQ ON CJT.EquipID = EQ.EpuipID
                JOIN tblEQUIPMENT_TYPE EQT ON EQ.EquipTypeID = EQT.EquipTypeID
    WHERE L.LevelName = 'Senior'
    -- (SELECT GetDate() - (365.25 * 21))
    AND SkillTypeName = 'Heavy Machinery'
    AND JobTypeName = 'high-rise residential'
    AND EquipName = 'Hydraulic Lift'
    AND JobBeginDate > 'November 11, 2021'
    )
    BEGIN
    SET @RET = 1
    END
    RETURN @RET
END
go

