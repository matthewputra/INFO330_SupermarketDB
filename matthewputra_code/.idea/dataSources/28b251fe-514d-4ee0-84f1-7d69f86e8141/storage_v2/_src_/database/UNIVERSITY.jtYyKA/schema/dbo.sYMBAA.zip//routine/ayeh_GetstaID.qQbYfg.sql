CREATE PROCEDURE ayeh_GetstaID
@StatName varchar(50),
@StatusID INT OUTPUT
AS
    SET @StatusID =(SELECT StatusID FROM tblSTATUS WHERE StatusName = @StatName)
go

