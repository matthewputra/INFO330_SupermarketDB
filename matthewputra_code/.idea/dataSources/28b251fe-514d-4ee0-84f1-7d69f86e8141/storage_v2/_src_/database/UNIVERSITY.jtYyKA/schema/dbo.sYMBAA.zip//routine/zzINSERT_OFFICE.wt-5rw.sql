CREATE PROCEDURE zzINSERT_OFFICE
@BldgName varchar (50),
@OTName varchar(50),
@OName varchar(25)
AS
DECLARE @B_ID INT, @OT_ID INT --declare what we wanna INSERT.

/*
    SET @B_ID=(SELECT BuildingID FROM UNIVERSITY.dbo.tblBUILDING WHERE BuildingName=@BldgName)
*/

EXEC zzGetBuildingID
@Building=@BldgName,
@BldgID=@B_ID OUTPUT

IF @B_ID IS NULL
    BEGIN
        PRINT 'impromptu messaging'
        RAISERROR ('@B_ID is null',11,1)--11 is severity, 1 is always 1
        end

IF @B_ID IS NULL
    BEGIN
        PRINT 'System cannot locate the ID value for the Blg'
        RAISERROR (50901,11,1)--11 is severity, 1 is always 1
        RETURN
        end
/*
    SET @OT_ID=(SELECT OfficeTypeID FROM tblOFFICE_TYPE WHERE OfficeTypeName=@OTName)
*/

EXEC zzGetOfficeTypeID
@OffType=@OTName,
@OffTypeID=@OT_ID OUTPUT

IF @OT_ID IS NULL
    BEGIN
        PRINT 'System cannot locate the ID value for the Blg';
        THROW 50445, 'The error message is...@@B_ID is null; INSERT being terminated',1;
    end

INSERT INTO tblOFFICE (OFFICENAME, OFFICETYPEID, BUILDINGID)
VALUES (@OName,@OT_ID,@B_ID)
go

