--Write the code to create a stored procedure to register an existing student to an existing class.
CREATE PROCEDURE uspExistingClass
@Fname varchar(20),
@Lname varchar(20),
@StudentBirth Date,
@RegDate Date,
@RegFee Numeric(6,2),
@year char(4),
@coursename varchar(50),
@section char(3),
@quartername varchar(20)

AS DECLARE @ClassID int, @StudentID int

SET @ClassID = (select classid from tblClass cs
                INNER JOIN tblQuarter q on cs.quarterid = q.quarterid
                INNER JOIN tblCourse cr on cs.courseid = cr.courseid
                WHERE q.quartername = @quartername AND
                      cr.coursename = @coursename AND
                      cs.year = @year AND
                      cs.section = @section)

SET @StudentID = (select studentid from tblStudent s
                  WHERE s.studentFname = @Fname AND
                        s.studentLname = @Lname AND
                        s.StudentBirth = @studentbirth)

INSERT INTO tblClassList (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@ClassID, @StudentID, NULL, @RegDate, @RegFee)
go

