CREATE PROCEDURE uspdsHireStaff
	/* Retrieve StaffID */
	@SFName VARCHAR(20),
	@SLName VARCHAR(20),
	@SBirth Date,
	/* Retrieve PositionID */
	@PName VARCHAR(20),
	/* Other vals */
	@BDate Date,
	@EDate Date,
	/* DeptID */
	@DName VARCHAR(20)
	AS
	DECLARE @S_ID INT, @P_ID INT, @D_ID INT
	SET @S_ID = (SELECT StaffID FROM tblSTAFF WHERE StaffFName = @SFName AND StaffLName = @SLName AND StaffBirth = @SBirth)
	SET @P_ID = (SELECT PositionID FROM tblPOSITION WHERE PositionName = @PName)
	SET @D_ID = (SELECT DeptID FROM tblDEPARTMENT WHERE DeptName = @DName)
	INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
	VALUES(@S_ID, @P_ID, @BDate, @EDate, @D_ID)
go

