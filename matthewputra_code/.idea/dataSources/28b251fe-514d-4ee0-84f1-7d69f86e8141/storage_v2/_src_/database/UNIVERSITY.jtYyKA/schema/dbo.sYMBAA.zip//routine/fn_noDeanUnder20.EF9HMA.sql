CREATE FUNCTION fn_noDeanUnder20()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT=0
    IF EXISTS(SELECT *
            FROM tblPOSITION P
                JOIN tblSTAFF_POSITION SP ON P.PositionID = SP.PositionID
                JOIN tblSTAFF S ON SP.StaffID = S.StaffID
            WHERE P.PositionName='Dean'
            AND DATEDIFF(DAY,S.StaffBirth,GETDATE())/365.25 < 20  )
    SET @Ret=1
RETURN @Ret
end
go

