CREATE FUNCTION fn_mbCalcNumInfoCreds3_0(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
        (SELECT SUM(Credits)
            FROM tblSTUDENT S
            JOIN tblCLASS_LIST tCL on S.StudentID = tCL.StudentID
            JOIN tblCLASS tC on tCL.ClassID = tC.ClassID
            JOIN tblCOURSE t on tC.CourseID = t.CourseID
        WHERE S.StudentID = @PK
        AND CourseName LIKE 'INFO%'
        AND Grade > 3.0)
    RETURN @RET
END
go

