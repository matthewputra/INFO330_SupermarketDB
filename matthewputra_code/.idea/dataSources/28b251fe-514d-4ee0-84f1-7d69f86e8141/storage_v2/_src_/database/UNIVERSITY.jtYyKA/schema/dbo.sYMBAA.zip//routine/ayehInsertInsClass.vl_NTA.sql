CREATE PROCEDURE ayehInsertInsClass
@InstrFname varchar(30),
@InstrLname varchar(30),
@Birth Date,
@Course varchar(50),
@Quarter varchar(20),
@Year char(4),
@Section char(2)
    AS
DECLARE @InstrID INT
DECLARE @ClassID INT
    SET @InstrID = (SELECT InstructorID FROM tblINSTRUCTOR WHERE InstructorFname = @InstrFname AND InstructorLname = @InstrLname AND InstructorBirth = @Birth)--fname,lname not unqiaue add dob
    SET @ClassID = (SELECT ClassID FROM tblCLASS C
        JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
        JOIN tblQuarter Q ON Q.QuarterID = C.QuarterID
    WHERE CR.CourseName = @Course AND C.[YEAR] = @Year AND C.Section = @Section AND Q.QuarterName = @Quarter)
INSERT INTO tblINSTRUCTOR_CLASS (InstructorID, ClassID) -- these are required columns in the table
VALUES(@InstrID, @ClassID)
go

