CREATE PROCEDURE iano_EndDateStaffPosition
@PosName varchar(30),
@F varchar(30),
@L varchar(30),
@Birth Date,
@D varchar(30),
@NewEndDate Date
AS
    DECLARE @S_ID INT, @P_ID INT, @D_ID INT

SET @S_ID = (SELECT StaffID
    FROM tblSTAFF
    WHERE StaffFName = @F
        AND StaffLName = @L
        AND StaffBirth = @Birth)

SET @P_ID = (SELECT PositionID
    FROM tblPOSITION
    WHERE PositionName = @PosName)

SET @D_ID = (SELECT DeptID
    FROM tblDEPARTMENT
    WHERE DeptName = @D)

BEGIN TRAN I1

UPDATE tblSTAFF_POSITION
SET EndDate = @NewEndDate
WHERE DeptID = @D_ID
    AND StaffID = @S_ID
    AND PositionID = @P_ID

COMMIT TRAN I1

EXEC iano_EndDateStaffPosition
@PosName = 'Office Manager',
@F = 'Dean',
@L = 'Bueter',
@Birth = '1968-03-17',
@D = 'Art',
@NewEndDate = '1985-07-25'
go

