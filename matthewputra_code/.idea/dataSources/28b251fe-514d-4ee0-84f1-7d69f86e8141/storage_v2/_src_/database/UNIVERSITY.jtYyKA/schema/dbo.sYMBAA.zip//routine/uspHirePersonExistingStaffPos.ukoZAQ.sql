
CREATE PROCEDURE uspHirePersonExistingStaffPos
@PosName varchar(50),
@PosTypeName varchar(50),
@FName varchar(20),
@LName varchar(20),
@Birth date,
@Begin date,
@End date,
@Dept varchar(50)
AS
DECLARE @S_ID INT, @P_ID INT, @D_ID INT
SET @S_ID = 
(SELECT StaffID
FROM tblSTAFF S
WHERE S.StaffFName = @FName
AND S.StaffLName = @LName
AND S.StaffBirth = @Birth)
SET @P_ID = 
(SELECT PositionID
FROM tblPOSITION P
JOIN tblPOSITION_TYPE PT ON P.PositionTypeID = PT.PositionTypeID
WHERE P.PositionName = @PosName
AND PT.PositionTypeName = @PosTypeName
)
SET @D_ID = 
(SELECT DeptID
FROM tblDEPARTMENT D
JOIN tblCollege C ON D.CollegeID = C.CollegeID
WHERE D.DeptName = @Dept
)

BEGIN TRAN G1
INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES(@S_ID, @P_ID, @Begin, @End, @D_ID)
COMMIT TRAN G1
go

