CREATE FUNCTION fn_TotalClassesSince1953(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = (SELECT COUNT(CL.ClassID)
                        FROM tblCOURSE C
                        JOIN tblCLASS CL ON C.CourseID = CL.CourseID
                        WHERE C.CourseID = @PK
                        AND CL.[YEAR] >= 1953)
    RETURN @Ret
END
go

