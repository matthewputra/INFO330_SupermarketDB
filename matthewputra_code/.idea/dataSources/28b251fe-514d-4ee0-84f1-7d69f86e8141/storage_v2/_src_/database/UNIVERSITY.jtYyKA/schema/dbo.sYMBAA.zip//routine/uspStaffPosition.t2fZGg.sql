CREATE PROCEDURE uspStaffPosition
    @FName varchar(20),
    @LName varchar(20),
    @BDay Date,
    @InsType varchar(50),
    @Begin Date,
    @End Date
AS
    DECLARE @I_ID INT, @INS_ID INT
    SET @I_ID = (
        SELECT InstructorID
        FROM tblINSTRUCTOR
        WHERE InstructorFName = @FName
        AND InstructorLName = @LName
        AND InstructorBirth = @BDay
        )
    SET @INS_ID = (
        SELECT InstructorTypeID
        FROM tblINSTRUCTOR_TYPE
        WHERE InstructorTypeName = @InsType
        )
    INSERT INTO tblINSTRUCTOR_INSTRUCTOR_TYPE(InstructorID, InstructorTypeID, BeginDate, EndDate)
    VALUES (@I_ID, @INS_ID, @Begin, @End)
go

