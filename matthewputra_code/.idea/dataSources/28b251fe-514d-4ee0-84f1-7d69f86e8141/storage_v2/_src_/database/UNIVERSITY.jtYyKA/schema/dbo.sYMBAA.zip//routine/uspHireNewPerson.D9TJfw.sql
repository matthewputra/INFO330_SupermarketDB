CREATE PROCEDURE uspHireNewPerson
    @Fname varchar(20),
    @Lname varchar(20),
    @Bday date,
    @PositionName varchar(20),
    @DeptName varchar(20),
    @BeginDate date,
    @EndDate date
    AS
    DECLARE @PositionID INT, @StaffID INT, @DeptID INT
    SET @PositionID = (SELECT PositionID
        FROM tblPOSITION P
        WHERE P.PositionName = @PositionName
        )
    SET @StaffID = (SELECT StaffID
        FROM tblSTAFF ST
        WHERE ST.StaffFname = @Fname
        AND ST.StaffLname = @Lname
        AND ST.StaffBirth = @Bday
        )
    SET @DeptID = (SELECT DeptID
        FROM tblDEPARTMENT D
        WHERE D.DeptName = @DeptName
        )

    INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
    VALUES(@StaffID, @PositionID, @BeginDate, @EndDate, @DeptID)
go

