CREATE FUNCTION fn_alinAgeOfBuilding (@PK INT)
RETURNS NUMERIC(4,1)
AS 
BEGIN
	DECLARE @RET NUMERIC(4,1) = (SELECT DateDiff(day, YearOpened, GetDate()) / 365.25
								 FROM tblBUILDING
								 WHERE BuildingID = @PK)
	RETURN @RET
END
go

