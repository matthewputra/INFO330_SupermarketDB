CREATE FUNCTION fn_instructor_restriction_400lvlcourse()
RETURNS INT
AS 
BEGIN 
DECLARE @RET INT = 0
	IF EXISTS (SELECT*
	FROM tblINSTRUCTOR I
		JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID = IC.InstructorID
		JOIN tblCLASS C ON IC.ClassID = C.ClassID
		JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
		JOIN tblDEPARTMENT D ON CO.DeptID = D.DeptID
		JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
		JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IT ON I.InstructorID = IT.InstructorID
		JOIN tblINSTRUCTOR_TYPE T ON IT.InstructorTypeID = T.InstructorTypeID
	WHERE DeptName = 'Biology' OR DeptName = 'Philosophy'
	AND CourseNumber >= 400
	AND QuarterName = 'Summer'
	AND InstructorTypeName = 'Assistant Professor' OR InstructorTypeName = 'Associate Professor')
	BEGIN
		SET @RET = 1
	END
RETURN @RET
END
go

