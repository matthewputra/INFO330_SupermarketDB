CREATE PROCEDURE jessy_INSERT_tblSTAFF_POSITION
@FName varchar(30),
@LName varchar(30),
@BirthDate date,
@PosName varchar(30),
@DName varchar(30),
@BDate date,
@EDate date

AS

DECLARE @StaID INT, @PosID INT, @DeID INT
SET @StaID  = (select StaffID from tblSTAFF where StaffFName = @FName and StaffLName = @LName and StaffBirth = @BirthDate)
SET @PosID = (select PositionID from tblPOSITION where PositionName = @PosName)
SET @DeID = (select DeptID from tblDEPARTMENT where DeptName = @DName)

INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES (@StaID, @PosID, @BDate, @EDate, @DeID)
go

