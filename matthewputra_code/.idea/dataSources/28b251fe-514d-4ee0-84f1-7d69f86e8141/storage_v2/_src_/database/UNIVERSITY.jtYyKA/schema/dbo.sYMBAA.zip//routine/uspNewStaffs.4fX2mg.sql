CREATE PROCEDURE uspNewStaffs
@Fname varchar(20),
@Lname varchar(20),
@Addy varchar(50),
@city varchar(20),
@state varchar(20),
@zip INT,
@Birth DATE,
@NetID INT,
@Email varchar(25),
@gender varchar(10)
AS
INSERT INTO tblSTAFF (
StaffFName,
StaffLName,
StaffAddress,
StaffCity,
StaffState,
StaffZip,
StaffBirth,
StaffNetID,
StaffEmail,
Gender)
VALUES
(@Fname,
@Lname,
@Addy,
@city,
@state,
@zip,
@Birth,
@NetID,
@Email,
@gender)
go

