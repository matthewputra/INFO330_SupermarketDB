CREATE PROCEDURE melhenry_FindQuarterID
@QuarName VARCHAR (30)
AS
DECLARE @QID INT

SET @QID = (SELECT QuarterID
            FROM tblQUARTER
            WHERE QuarterName = @QuarName)
go

