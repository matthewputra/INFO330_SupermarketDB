CREATE PROCEDURE RegisterClassForExistingStudent
@CourseName varchar(75),
@QuarterName varchar(30),
@Year char(4),
@ClassroomName varchar(125),
@ScheduleName varchar(75),
@SectionName varchar(4),
@Fname varchar(60),
@Lname varchar(60),
@Birth date,
@Grade decimal(3,2),
@RegisDate date,
@RegisFee numeric(10,2)
AS
BEGIN
DECLARE @ClassID INT, @StudentID INT
SET @ClassID=(SELECT CS.ClassID FROM tblCLASS CS
                JOIN tblCOURSE CR on CS.CourseID = CR.CourseID
                JOIN tblQUARTER Q on CS.QuarterID = Q.QuarterID
                JOIN tblCLASSROOM CM on CS.ClassroomID = CM.ClassroomID
                JOIN tblSCHEDULE SC on CS.ScheduleID = SC.ScheduleID
                WHERE CourseName=@CourseName
                AND QuarterName=@QuarterName
                AND [YEAR]=@Year
                AND ClassroomName=@ClassroomName
                AND ScheduleName=@ScheduleName
                AND Section=@SectionName )

IF @ClassID IS NULL
    BEGIN
        PRINT 'Hey, @ClassID is null ';
        THROW 50445, '@ClassID cannot be null. The insert statement is being terminated.',11;
    end

SET @StudentID = (SELECT S.StudentID FROM tblSTUDENT S
                    JOIN tblSTUDENT_STATUS SS ON S.StudentID = SS.StudentID
                    JOIN tblSTATUS STA ON SS.StatusID = STA.StatusID
                    WHERE StudentFname=@Fname
                    AND StudentLname=@Lname
                    AND StudentBirth=@Birth
                    AND StatusName IN ('Matriculated','Academic Probation','Re-instated')
                    AND S.DateOfDeath > GETDATE() )
IF @StudentID IS NULL
    BEGIN
        PRINT 'Hey, @StudentID is null ';
        THROW 50445, '@StudentID cannot be null. The insert statement is being terminated.',11;
    end

BEGIN TRAN G1
INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@ClassID,@StudentID,@Grade,@RegisDate,@RegisFee)
IF @@ERROR <>0
    BEGIN
        PRINT 'The transaction G1 is being rolled back.'
        ROLLBACK TRAN G1
    end
ELSE
    BEGIN
      PRINT 'Everything looks good. Transaction G1 is being committed.'
      COMMIT TRAN G1
    end
END
go

