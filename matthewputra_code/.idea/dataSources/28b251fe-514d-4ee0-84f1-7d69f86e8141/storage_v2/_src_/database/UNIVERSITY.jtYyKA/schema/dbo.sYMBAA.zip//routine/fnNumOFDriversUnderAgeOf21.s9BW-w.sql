


-- TotalCompanyStores (Proposed: Number Of Drivers Under Age Of 21)
-- should a position be driver also two staffs
-- ask what the @ int in the beggining is for and what it should be 

CREATE FUNCTION fnNumOFDriversUnderAgeOf21 (@PositionID INT)
RETURNS numeric(6,2)
AS
BEGIN
DECLARE @RET numeric(6,2) =
   	(SELECT Count(E.EmployeeID)
       FROM tblPOSITION P
       JOIN tblJOB J ON J.PositionID = P.PositionID
       JOIN tblEMPLOYEE E ON E.EmployeeID = J.EmployeeID
       WHERE P.PositionID = @PositionID
       AND P.PositionName = 'Driver'
       AND DATEDIFF(YEAR, E.EmployeeDOB, GETDATE()) < 21)
 
RETURN @RET
END
go

