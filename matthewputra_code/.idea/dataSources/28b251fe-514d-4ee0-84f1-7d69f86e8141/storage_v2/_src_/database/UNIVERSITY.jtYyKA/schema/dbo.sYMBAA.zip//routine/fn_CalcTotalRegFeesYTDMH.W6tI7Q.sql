CREATE FUNCTION fn_CalcTotalRegFeesYTDMH(@PK INT)
RETURNS numeric(18,2)
AS
BEGIN
    DECLARE @RET numeric(18,2) = (SELECT SUM(RegistrationFee)
    FROM tblCLASS_LIST CL
        JOIN tblCLASS CS on CL.ClassID = CS.ClassID
        JOIN tblCOURSE CR on CS.CourseID = CR.CourseID
        JOIN tblDEPARTMENT D on CR.DeptID = D.DeptID
        JOIN tblCOLLEGE C on D.CollegeID = C.CollegeID
    WHERE C.CollegeID = @PK
    AND YEAR(RegistrationDate) = YEAR(GETDATE()))
RETURN @RET
END
go

