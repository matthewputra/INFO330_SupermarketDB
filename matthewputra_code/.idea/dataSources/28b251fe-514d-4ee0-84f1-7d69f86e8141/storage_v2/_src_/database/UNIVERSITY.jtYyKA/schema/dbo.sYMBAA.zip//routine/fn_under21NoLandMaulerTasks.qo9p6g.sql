CREATE FUNCTION fn_under21NoLandMaulerTasks()
RETURNS INT
BEGIN
DECLARE @RET INT = 0
    IF EXISTS (SELECT *
                FROM tblEMPLOYEE E
                JOIN tblEMPLOYEE_SKILL ES ON E.EmpID = ES.EmpID
                JOIN tblCUST_JOB_TASK CJT ON ES.EmpSkillID = CJT.EmpSkillID
                JOIN tblTASK T ON CJT.TaskID = T.TaskID
                JOIN tblTOOL TL ON CJT.ToolID = TL.ToolID
                JOIN tblTOOL_TYPE TP ON TL.ToolTypeID = TP.ToolTypeID
    WHERE E.EmpBirthDate > (SELECT GetDate() - (365.25 * 21))
    AND ToolTypeName = 'Land Mauler'
    )
    BEGIN
    SET @RET = 1
    END
    RETURN @RET
END
go

