CREATE FUNCTION mlTotalRegistration(@PK INT)
RETURNS INT
AS
    BEGIN
        DECLARE @RET INT=(SELECT SUM(RegistrationFee) FROM tblCLASS_LIST CLL
        JOIN tblCLASS CL ON CLL.ClassID=CL.ClassID
        JOIN tblCOURSE CR ON CL.CourseID=CR.CourseID
        JOIN tblDEPARTMENT D ON D.DeptID=CR.DeptID
        JOIN tblCOLLEGE C ON D.CollegeID=C.CollegeID
        WHERE C.CollegeID=@PK
        AND DATEDIFF(year,cll.RegistrationDate,GetDate())<=2
        AND C.CollegeID=@PK)
    RETURN @RET
    end
go

