CREATE FUNCTION fn_ERTotalRegFees(@PK INT)
RETURNS numeric(20,2)
AS
BEGIN
	DECLARE @RET numeric(15,2) =
	(
		SELECT SUM(CL.RegistrationFee)
		FROM tblDEPARTMENT	D
			JOIN tblCOURSE CO ON CO.DeptID = D.DeptID
			JOIN tblCLASS C ON C.CourseID = CO.CourseID
			JOIN tblCLASS_LIST CL ON C.CLassID = C.ClassID
			JOIN tblCOLLEGE COL ON D.CollegeID = COL.CollegeID
		WHERE COL.CollegeID = @PK
		AND YEAR(RegistrationDate) = YEAR(GetDate())
	)
RETURN @RET
END
go

