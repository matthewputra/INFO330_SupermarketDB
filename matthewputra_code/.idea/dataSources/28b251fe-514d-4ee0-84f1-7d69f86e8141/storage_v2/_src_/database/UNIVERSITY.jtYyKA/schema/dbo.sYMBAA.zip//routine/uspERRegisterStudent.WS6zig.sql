CREATE PROCEDURE uspERRegisterStudent
@registrationDate Date,
@registrationFee INT,
@fname varchar(20),
@lname varchar(20),
@birth Date,
@courseName varchar(50),
@year INT,
@quarter varchar(20)
AS
DECLARE @classID INT, @studentID INT

SET @classID = (
	SELECT ClassID
	FROM tblCLASS C
		JOIN tblCOURSE CO ON CO.CourseID = C.CourseID
		JOIN tblQUARTER Q ON Q.QuarterID = C.QuarterID
	WHERE Q.QuarterName = @quarter
	AND CO.CourseName = @courseName
	AND C.[YEAR] = @year
)

SET @studentID = (
	SELECT StudentID
	FROM tblSTUDENT
	WHERE StudentFname = @fname
	AND StudentLname = @lname
	AND StudentBirth = @birth
)

BEGIN TRAN E1
INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES(@classID, @studentID, NULL, @registrationDate, @registrationFee)
COMMIT TRAN E1
go

