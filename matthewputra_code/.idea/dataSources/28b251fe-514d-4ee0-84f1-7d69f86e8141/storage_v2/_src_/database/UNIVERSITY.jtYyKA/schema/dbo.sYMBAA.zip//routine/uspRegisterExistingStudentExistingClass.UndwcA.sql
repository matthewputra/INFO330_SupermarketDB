
--Write the code to create a stored procedure to register an existing student to an existing class

CREATE PROCEDURE uspRegisterExistingStudentExistingClass
@F varchar(20),
@L varchar(20),
@B date,
@Quarter varchar(10),
@Course varchar(50),
@Year char(4),
@Section char(3),
@RegDate date,
@RegFee numeric(6,2)
AS
DECLARE @C_ID INT, @S_ID INT
SET @C_ID = 
(SELECT ClassID
FROM tblCLASS CS
JOIN tblQUARTER Q ON CS.QuarterID = Q.QuarterID
JOIN tblCOURSE C ON CS.CourseID = C.CourseID
WHERE Q.QuarterName = @Quarter
AND C.CourseName = @Course
AND CS.[YEAR] = @Year
AND CS.Section = @Section)
SET @S_ID =
(SELECT StudentID
FROM tblSTUDENT 
WHERE StudentFname = @F
AND StudentLname = @L
AND StudentBirth = @B)

BEGIN TRAN G3
INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES(@C_ID, @S_ID, NULL, @RegDate, @RegFee)
COMMIT TRAN G3
go

