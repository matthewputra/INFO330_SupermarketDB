
create function fn_yiucalcregistered(@pk int)

returns int 

as begin 
	declare @ret int = 
	(select count(cl.studentid)
		from tblclass_list cl
		join tblCLASS C on cl.classID = c.classid
			where c.ClassID = @pk
	)

	return @ret 
	end
go

