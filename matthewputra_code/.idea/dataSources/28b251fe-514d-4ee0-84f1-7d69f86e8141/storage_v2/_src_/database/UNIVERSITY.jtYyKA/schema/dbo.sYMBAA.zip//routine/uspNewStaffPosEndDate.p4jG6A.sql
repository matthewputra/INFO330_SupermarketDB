CREATE PROC uspNewStaffPosEndDate
@StaffF varchar(20),
@StaffL varchar(20),
@StaffB Date,
@PosName varchar(20),
@EndDate Date
AS
BEGIN
	DECLARE @StaffID INT, @PosID INT
	SET @StaffID = (SELECT StaffID FROM tblSTAFF
					WHERE StaffFname = @StaffF
						AND StaffLname = @StaffL
						AND StaffBirth = @StaffB)
	SET @PosID = (SELECT PositionID FROM tblPOSITION
					WHERE PositionName = @PosName)

BEGIN TRAN T1
UPDATE tblSTAFF_POSITION
SET EndDate = @EndDate
WHERE StaffID = @StaffID
	AND PositionID = @PosID
COMMIT TRAN T1
END
go

