CREATE PROCEDURE HIIII
    @SName varchar(20),
    @SLame varchar(20),
    @Bday date,
    @RegisDate Date,
    @RegisFee numeric,
    @CRName varchar(50),
    @SchedName varchar(50)
AS
DECLARE @C_ID INT, @S_ID INT
    SET @C_ID = (
        SELECT ClassID
        FROM tblCLASS C
            JOIN tblCOURSE CR on CR.CourseID = C.CourseID
            JOIN tblSCHEDULE SC on SC.ScheduleID = C.ScheduleID
        WHERE CR.CourseName = @CRName
        AND SC.ScheduleName = @SchedName
        )
    SET @S_ID = (
        SELECT StudentID
        FROM tblSTUDENT
        WHERE StudentFname = @SName
            AND StudentLname = @SLame
            AND StudentBirth = @Bday
        )
INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, NULL, @RegisDate, @RegisFee)
go

