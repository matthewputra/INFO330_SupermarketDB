CREATE FUNCTION fn_CalcNumRegistered1(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
        (SELECT COUNT(CL.StudentID)
            FROM tblCLASS_LIST CL
            JOIN tblCLASS C on CL.ClassID = C.ClassID
            WHERE CL.ClassID = @PK)
RETURN @RET
END
go

