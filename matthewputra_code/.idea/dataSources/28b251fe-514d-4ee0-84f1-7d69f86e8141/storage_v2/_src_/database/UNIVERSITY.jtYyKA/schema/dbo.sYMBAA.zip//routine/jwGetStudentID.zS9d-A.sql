CREATE PROCEDURE jwGetStudentID
@StudFName varchar(50),
@StudLname varchar(50),
@Studmail varchar(100),
@StudID INT OUTPUT AS 
SET @StudID = (SELECT StudentID from tblSTUDENT WHERE
				StudentFname = @StudFName AND StudentLname = @StudLname AND
				StudentMail = @Studmail)
go

