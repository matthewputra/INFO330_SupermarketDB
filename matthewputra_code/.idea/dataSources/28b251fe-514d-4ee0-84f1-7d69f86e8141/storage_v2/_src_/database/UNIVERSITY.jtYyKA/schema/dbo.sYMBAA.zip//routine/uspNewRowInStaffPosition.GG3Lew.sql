CREATE PROCEDURE uspNewRowInStaffPosition
@CName varchar(20),
@FName varchar(20),
@LName varchar(20),
@BDate Date,
@PName varchar(20)
AS DECLARE @S_ID INT, @P_ID INT
SET @S_ID = (SELECT StaffID FROM tblStaff
		WHERE StaffFName = @FName
		AND StaffLName = @LName
		AND StaffBirth = @BDate)
SET @P_ID = (SELECT PositionID FROM tblPOSITION 
		WHERE PositionName = @PName)

INSERT INTO tblSTAFF_POSITION(StaffID, PositionID)
Values(@S_ID, @P_ID)
go

