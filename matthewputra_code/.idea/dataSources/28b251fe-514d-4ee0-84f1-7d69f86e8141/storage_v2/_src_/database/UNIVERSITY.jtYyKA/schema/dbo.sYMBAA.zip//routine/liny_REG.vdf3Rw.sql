CREATE PROCEDURE liny_REG
@Fname varchar(30),
@Lname varchar(30),
@Bday Date,
@RegDate Date,
@RegFee numeric(10, 2),
@Year char(4),
@CRName varchar(75),
@Section varchar(4),
@Quarter varchar(30),
@Grade numeric(2, 1) = NULL

AS

DECLARE @CL_ID INT
DECLARE @S_ID INT

SET @CL_ID = (SELECT ClassID
			  FROM tblClass CL
				JOIN tblQUARTER Q ON CL.QuarterID = Q.QuarterID
				JOIN tblCOURSE CR ON CL.CourseID = CR.CourseID
			  WHERE Q.QuarterName = @Quarter
			  AND CR.CourseName = @CRName
			  AND CL.[YEAR] = @Year
			  AND CL.Section = @Section)

SET @S_ID = (SELECT StudentID
			 FROM tblSTUDENT
			 WHERE StudentFname = @Fname
			 AND StudentLname = @Lname
			 AND StudentBirth = @Bday)

INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@CL_ID, @S_ID, @Grade, @RegDate, @RegFee)
go

