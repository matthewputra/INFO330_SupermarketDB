
CREATE PROCEDURE melhenryGetBuildingID
@Building VARCHAR (50),
@bldgID INT OUTPUT
AS
SET @bldgID = (SELECT BuildingID FROM tblBuilding WHERE BuildingName = @Building)
go

