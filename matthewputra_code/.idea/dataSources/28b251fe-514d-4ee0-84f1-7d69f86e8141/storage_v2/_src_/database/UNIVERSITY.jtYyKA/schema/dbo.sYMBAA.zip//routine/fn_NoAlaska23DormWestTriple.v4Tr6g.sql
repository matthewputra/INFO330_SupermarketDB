CREATE FUNCTION fn_NoAlaska23DormWestTriple()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF EXISTS (SELECT S.StudentID
                FROM tblSTUDENT S
                    JOIN tblSTUDENT_DORMROOM SD on S.StudentID = SD.StudentID
                    JOIN tblDORMROOM D on SD.DormRoomID = D.DormRoomID
                    JOIN tblDORMROOM_TYPE DT on D.DormRoomTypeID = DT.DormRoomTypeID
                    JOIN tblBUILDING B on D.BuildingID = B.BuildingID
                    JOIN tblLOCATION L on B.LocationID = L.LocationID
                WHERE S.StudentPermState = 'Alaska'
                AND DT.DormRoomTypeName = 'Triple'
                AND L.LocationName = 'West Campus'
                AND S.StudentBirth < DATEADD(Year, -23, GETDATE()))

    SET @RET = 1
RETURN @RET
END
go

