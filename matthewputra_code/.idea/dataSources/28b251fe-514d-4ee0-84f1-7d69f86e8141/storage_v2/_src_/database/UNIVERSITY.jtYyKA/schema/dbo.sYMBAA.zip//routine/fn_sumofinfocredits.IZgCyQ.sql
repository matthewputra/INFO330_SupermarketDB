CREATE FUNCTION fn_sumofinfocredits(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = (
    SELECT SUM(CO.Credits)
        FROM tblSTUDENT S
            JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
            JOIN tblCLASS C ON CL.ClassID = C.ClassID
            JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
            JOIN tblDEPARTMENT D ON CO.DeptID = D.DeptID
            JOIN tblCOLLEGE CG ON D.CollegeID = CG.CollegeID
        WHERE CL.Grade > 3.4
        AND CG.CollegeName = 'Information School'
        AND S.StudentID = @PK
    )
RETURN @RET
END
go

