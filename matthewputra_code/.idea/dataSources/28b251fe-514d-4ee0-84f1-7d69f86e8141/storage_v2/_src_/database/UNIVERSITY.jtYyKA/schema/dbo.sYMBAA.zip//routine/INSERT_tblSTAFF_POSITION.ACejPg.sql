CREATE PROCEDURE INSERT_tblSTAFF_POSITION
@F VARCHAR(20),
@L VARCHAR(20),
@Address VARCHAR(200),
@City VARCHAR(20),
@State VARCHAR(2),
@Zip VARCHAR(10),
@Birth DATE,
@NetID VARCHAR(20),
@Email VARCHAR(50),
@Gender VARCHAR(20),
@PosName VARCHAR(50),
@BeginDate DATE,
@DeptName VARCHAR(50)
AS
INSERT INTO tblSTAFF(stafffname, stafflname, staffaddress, staffcity, staffstate, staffzip,
                     staffbirth, staffnetid, staffemail, gender)
VALUES(@F, @L, @Address, @City, @State, @Zip, @Birth, @NetID, @Email, @Gender)
DECLARE @StaffID INT, @PosID INT, @DeptID INT
SET @StaffID = (SELECT StaffID
    FROM tblSTAFF
    WHERE StaffFName = @F
        AND StaffLName = @L
        AND StaffBirth = @Birth
    )
SET @PosID = (SELECT PositionID
    FROM tblPOSITION
    WHERE PositionName = @PosName
    )
SET @DeptID = (SELECT DeptID
    FROM tblDEPARTMENT
    WHERE DeptName = @DeptName
    )
INSERT INTO tblSTAFF_POSITION(staffid, positionid, begindate, enddate, deptid)
VALUES(@StaffID, @PosID,@BeginDate, NULL, @DeptID)
go

