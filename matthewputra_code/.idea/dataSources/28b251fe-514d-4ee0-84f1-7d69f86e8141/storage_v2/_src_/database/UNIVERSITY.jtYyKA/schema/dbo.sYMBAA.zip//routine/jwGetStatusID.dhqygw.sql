CREATE PROCEDURE jwGetStatusID
@StatName varchar(50),
@StatID INT OUTPUT AS
SET @StatID = (SELECT StatusID from tblSTATUS WHERE
				StatusName = @StatName)
go

