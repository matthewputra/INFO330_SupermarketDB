CREATE PROCEDURE mlINSERT_STUDENT_PROCEDURE
@stfname varchar(60),
@stlname varchar(60),
@stbirth date,
@StatusName varchar(125),
@BeginDate date,
@EndDate date
AS
    DECLARE @StudentID INT, @StatusID INT
    SET @StudentID=(SELECT StudentID FROM tblSTUDENT WHERE StudentFname=@stfname
                AND StudentLname=@stlname and StudentBirth=@stbirth)
    SET @StatusID=(SELECT StatusID from tblSTATUS WHERE StatusName=@StatusName)
INSERT INTO tblStudent_Status(StudentID, StatusID, BeginDate, EndDate)
VALUES (@StudentID,@StatusID,@BeginDate,@EndDate);
go

