/* 1) Write the SQL to create a computed column to track #Info credits above 3.4 for each student */

/* CREATE FUNCTION fn_ */

/* 2) Business Rule: "No student older than 23 from Alaska can be assigned a dorm room on West Campus of dorm room type 'Triple'"  */

CREATE FUNCTION fn_NoAlaskaStudentInTriple()
RETURNS INT
AS
BEGIN

DECLARE @Ret INT = 0
IF EXISTS ( -- sql code select whichever violates the logic
		   select *
		   from tblSTUDENT S
			   JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
			   JOIN tblDORMROOM D ON D.DormRoomID = SD.DormRoomID
			   JOIN tblDORMROOM_TYPE DT ON DT.DormRoomTypeID = D.DormRoomTypeID
			   JOIN tblBUILDING B ON B.BuildingID = D.BuildingID
			   JOIN tblLOCATION L ON L.LocationID = B.LocationID
			where S.StudentBirth < DATEADD(YEAR, -23, GETDATE())
			AND S.StudentPermState = 'Alaska, AK'
			AND L.LocationName = 'West Campus'
			AND DT.DormRoomTypeName = 'Triple')
	SET @Ret = 1
RETURN @RET
END
go

