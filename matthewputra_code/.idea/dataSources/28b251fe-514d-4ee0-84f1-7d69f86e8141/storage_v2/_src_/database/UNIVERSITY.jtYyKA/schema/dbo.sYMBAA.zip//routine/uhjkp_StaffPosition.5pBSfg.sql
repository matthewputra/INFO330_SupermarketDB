CREATE PROCEDURE uhjkp_StaffPosition
    @FName varchar(20),
    @LName varchar(20),
    @BDay Date,
    @PName varchar(50),
    @Begin Date,
    @End Date,
    @DName varchar(50)
AS
    DECLARE @Pos_ID INT, @Staff_ID INT, @Dept_ID INT
    SET @Pos_ID = (
        SELECT PositionID
        FROM tblPOSITION
        WHERE PositionName = @PName
        )
    SET @Staff_ID = (
        SELECT StaffID
        FROM tblSTAFF
        WHERE StaffFName = @FName
        AND StaffLName = @LName
        AND StaffBirth = @BDay
        )
    SET @Dept_ID = (
        Select DeptID
        FROM tblDEPARTMENT
        WHERE DeptName = @DName
        )
INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES (@Staff_ID, @Pos_ID, @Begin, @End, @Dept_ID)
go

