CREATE FUNCTION fn_Info34Students(@PK INT)
RETURNS FLOAT
AS
BEGIN
	DECLARE @Ret FLOAT = (select SUM(C.Credits)
					from tblCOURSE C
						JOIN tblDEPARTMENT D ON D.DeptID = C.DeptID
						JOIN tblCOLLEGE CO ON CO.CollegeID = D.CollegeID
						JOIN tblCLASS CL ON CL.CourseID = C.CourseID
						JOIN tblCLASS_LIST CLL ON CLL.ClassID = CL.ClassID
						JOIN tblSTUDENT S ON S.StudentID = CLL.StudentID
					where S.StudentID = @PK
					AND CO.CollegeName = 'Information School'
					AND C.Credits > 3.4
					GROUP BY S.StudentID, S.StudentFname, S.StudentLname)
	RETURN @Ret
END
go

