

CREATE PROCEDURE gthayINSERT_OFFICE
@BldgName varchar(50),
@OT_Name varchar (50),
@O_Name varchar(25)
AS
DECLARE @B_ID INT, @OT_ID INT

/*
SET @B_ID = (SELECT BuildingID FROM tblBUILDING WHERE BuildingName = @BldgName)
-- error-handling goes here --> example of old-school RAISERROR
*/
EXECUTE gthayGetBuildingID
@Building = @BldgName,
@BldgID = @B_ID OUTPUT

IF @B_ID IS NULL
	BEGIN
		PRINT 'This is an example of impromptu messaging with RAISERROR'
		RAISERROR  ('@B_ID IS NULL', 11, 1) with log
		PRINT 'hi...this is after RAISERROR but before RETURN'
		RETURN
	END

/*	
SET @OT_ID = (SELECT OfficeTypeID FROM tblOFFICE_TYPE WHERE OfficeTypeName = @OT_Name)
-- another set of error-handling goes here
*/
EXECUTE gthayGetOfficeTypeID
@OffType = @OT_Name,
@OffTypeID = @OT_ID OUTPUT

IF @OT_ID IS NULL
	BEGIN
		PRINT 'Hey...system cannot locate an ID value for the Office Type just submitted';
		THROW 50901,'@B_ID is NULL; the INSERT statement is being terminated',1;
	END


INSERT INTO tblOFFICE (OfficeName, OfficeTypeID, BuildingID)
VALUES (@O_Name, @OT_ID, @B_ID)

go

