CREATE FUNCTION fn_JC_MaxRegFeeForWAStudents495()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS (SELECT *
				FROM tblSTUDENT S
					JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
				WHERE S.StudentPermState = 'Washington, WA'
				AND CL.RegistrationFee < '495')
	SET @RET = 1
RETURN @RET
END
go

