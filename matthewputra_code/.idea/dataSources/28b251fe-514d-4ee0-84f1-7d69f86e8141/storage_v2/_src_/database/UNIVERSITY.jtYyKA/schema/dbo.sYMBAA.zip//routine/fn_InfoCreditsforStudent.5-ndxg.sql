CREATE FUNCTION dbo.fn_InfoCreditsforStudent(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
        (SELECT SUM(CR.Credits)
         FROM tblCOURSE CR
             JOIN tblCLASS CS ON CR.CourseID = CS.CourseID
             JOIN tblCLASS_LIST CL ON CS.ClassID = CL.ClassID
             JOIN tblSTUDENT S ON CL.StudentID = S.StudentID
         WHERE CR.CourseName LIKE '%INFO%'
         AND CL.Grade > 3.4
         AND S.StudentID = @PK)
RETURN @RET
END
go

