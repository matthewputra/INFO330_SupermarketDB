/*
1) Write the SQL to create a computed column to track #Info credits above 3.4
   for each student
2) Business Rule: "No student older than 23 from Alaska can be assigned a dormroom
   on West Campus of dormroom type 'triple' "
*/

/* 1 */
CREATE FUNCTION fn_infoCredsAbove34(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 
		(SELECT SUM(CO.Credits)
		 FROM tblCOURSE CO
			JOIN tblDEPARTMENT D ON CO.DeptID = D.DeptID
			JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
			JOIN tblCLASS CL ON CO.CourseID = CL.CourseID
			JOIN tblCLASS_LIST CLL ON CL.ClassID = CLL.ClassID
			JOIN tblSTUDENT S ON CLL.StudentID = S.StudentID
		 WHERE S.StudentID = @PK
		 AND C.CollegeName = 'Information School'
		 AND CLL.Grade > 3.4)
RETURN @RET
END
go

