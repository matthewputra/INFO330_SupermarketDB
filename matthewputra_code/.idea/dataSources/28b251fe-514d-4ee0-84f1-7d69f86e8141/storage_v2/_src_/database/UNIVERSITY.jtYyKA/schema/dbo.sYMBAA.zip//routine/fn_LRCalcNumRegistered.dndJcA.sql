CREATE FUNCTION fn_LRCalcNumRegistered(@PK int)
Returns int
As
Begin
declare @Ret int =
    (select count(Cl.StudentID)
    from tblCLass_List CL
    join tblClass C on CL.ClassID = C.ClassID
        where CL.ClassID = @PK)
return @Ret
    end
go

