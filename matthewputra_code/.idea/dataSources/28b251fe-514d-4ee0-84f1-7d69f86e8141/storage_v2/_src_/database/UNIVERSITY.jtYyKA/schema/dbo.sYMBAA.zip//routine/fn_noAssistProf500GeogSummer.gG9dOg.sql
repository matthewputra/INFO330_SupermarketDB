
CREATE FUNCTION fn_noAssistProf500GeogSummer()
RETURNS INTEGER
AS
BEGIN
	DECLARE @Ret INTEGER = 0
	IF EXISTS (SELECT *
		FROM tblINSTRUCTOR I
			JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON I.InstructorID = IIT.InstructorID
			JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID = IT.InstructorTypeID
			JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID = IC.InstructorID
			JOIN tblCLASS C ON IC.ClassID = C.ClassID
			JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
			JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
			JOIN tblDEPARTMENT D ON D.DeptID = CR.DeptID
		WHERE IT.InstructorTypeName = 'Assistant Professor'
		AND Q.QuarterName = 'Summer'
		AND C.[Year] >= '2018'
		AND D.DeptName = 'Geography'
		AND CR.CourseNumber LIKE '5%')
		
	SET @Ret = 1
RETURN @Ret
END
go

