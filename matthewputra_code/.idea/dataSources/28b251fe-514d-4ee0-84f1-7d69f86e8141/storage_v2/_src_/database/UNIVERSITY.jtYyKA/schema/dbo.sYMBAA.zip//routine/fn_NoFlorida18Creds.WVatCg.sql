CREATE FUNCTION fn_NoFlorida18Creds()
RETURNs INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF
	EXISTS (SELECT S.StudentID
			FROM tblSTUDENT S
				JOIN tblCLASS_LIST CL ON S.StudentID = Cl.StudentID
				JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
				JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
			WHERE S.StudentPermState = 'Florida, FL'
			AND StudentBirth > DateAdd(Year, -21, GetDate())
			AND RegistrationDate > DateAdd(Month, -4, GetDate()) --little wonky, registration date in last four months
			GROUP BY S.StudentID
			HAVING SUM(CR.Credits) > 18)

	SET @Ret = 1

RETURN @RET
END
go

