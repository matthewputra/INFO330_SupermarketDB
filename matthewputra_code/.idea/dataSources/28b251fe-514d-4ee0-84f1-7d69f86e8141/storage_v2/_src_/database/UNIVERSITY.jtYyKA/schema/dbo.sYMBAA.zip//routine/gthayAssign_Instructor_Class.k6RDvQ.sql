
CREATE PROCEDURE [dbo].[gthayAssign_Instructor_Class]
@BeginYear char(4),
@EndYear char(4)
AS
-- declare variables to handle INSERT

DECLARE @I_ID INT, @C_ID INT, @Run INT, @Rand_I INT
-- assemble list of classesfrom timeframe into #tempClasses

SELECT ClassID
INTO #tempCLASSES
FROM tblCLASS
WHERE [YEAR] BETWEEN @BeginYear AND @EndYear

-- assemble list of eligible instructors 
IF EXISTS (SELECT * FROM sys.objects WHERE name = '#tempTeachers')
	BEGIN
	DROP TABLE #tempTeachers

	CREATE TABLE #tempTeachers
	(PK_ID INT IDENTITY(1,1) primary key not null,
		InstructorID INT NOT NULL)
	END
INSERT INTO #tempTeachers
SELECT InstructorID
FROM tblINSTRUCTOR
WHERE Year(DeathDate) > @EndYear
	AND YEAR(InstructorBirth) BETWEEN (SELECT @BeginYear - 62) AND (SELECT @BeginYear - 35)


-- row count of #tempClasses -- declare @Run
SET @Run = (SELECT COUNT(*) FROM #tempCLASSES)

-- row count of #tempTeachers --> put in @Rand_I
SET @Rand_I = (SELECT COUNT(*) FROM #tempTeachers)

-- open WHILE loop > @Run
WHILE @Run > 0
BEGIN


-- select min(classID) from #tempClasses
SET @C_ID = (SELECT Min(ClassID) FROM #tempCLASSES)

-- select random instructor
SET @Rand_I = (SELECT @Rand_I * Rand() + 1)
PRINT @I_ID

SET @I_ID = (SELECT InstructorID FROM #tempTeachers WHERE PK_ID = @Rand_I)

-- error-handling for NULL
IF @I_ID IS NULL
		BEGIN
		SET @Rand_I = (SELECT COUNT(*) FROM #tempTeachers)
		SET @Rand_I = (SELECT @Rand_I * Rand() + 1)
		SET @I_ID = (SELECT InstructorID FROM #tempTeachers WHERE PK_ID = @Rand_I)
		END

IF @I_ID IS NULL
		BEGIN
		SET @Rand_I = (SELECT COUNT(*) FROM #tempTeachers)
		SET @Rand_I = (SELECT @Rand_I * Rand() + 1)
		SET @I_ID = (SELECT InstructorID FROM #tempTeachers WHERE PK_ID = @Rand_I)
		END
IF @I_ID IS NULL
		BEGIN
		SET @Rand_I = (SELECT COUNT(*) FROM #tempTeachers)
		SET @Rand_I = (SELECT @Rand_I * Rand() + 1)
		SET @I_ID = (SELECT InstructorID FROM #tempTeachers WHERE PK_ID = @Rand_I)
		END

INSERT INTO tblINSTRUCTOR_CLASS(InstructorID, ClassID)
VALUES (@I_ID, @C_ID)

-- Delete row from #tempClasses 

DELETE FROM #tempCLASSES WHERE ClassID = @C_ID
-- decrement @Run
SET @Run = @Run - 1
END

-- drop #temp tables

DROP TABLE #tempCLASSES
DROP TABLE #tempTeachers
go

