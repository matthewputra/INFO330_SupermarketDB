CREATE FUNCTION fn_CalcInfoCredsAbove3_4(@PK INT)
RETURNS INT
AS
BEGIN
        DECLARE @RET INT =
            (SELECT SUM(CR.Credits)
                FROM tblCLASS_LIST CL
                    JOIN tblCLASS tC on CL.ClassID = tC.ClassID
                    JOIN tblCOURSE CR ON tC.CourseID = CR.CourseID
                    JOIN tblDEPARTMENT tD on CR.DeptID = tD.DeptID
                WHERE td.DeptName = 'Information School'
                    AND CL.Grade > 3.4
                    AND CL.StudentID = @PK
                )
RETURN @RET
END
go

