CREATE FUNCTION fn_InfoCredsAboveThreePointFour(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = (
        SELECT CL.Grade
        FROM tblCLASS_LIST CL
            JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
            JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
            JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
            JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
        WHERE CL.Grade > 3.4
        AND CL.StudentID = @PK)
RETURN @RET
END
go

