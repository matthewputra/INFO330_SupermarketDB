CREATE PROCEDURE uspNewClassOfExistingCourse
@Course varchar(75),
@Quarter varchar(30),
@Year char(4),
@CMName varchar(125),
@Schedule varchar(75),
@Section varchar(4)
AS
DECLARE @COURSE_ID INT, @QUARTER_ID INT, @CLASSROOM_ID INT, @SCHEDULE_ID INT
SET @COURSE_ID = (
    SELECT CourseID
    FROM tblCOURSE
    WHERE CourseName = @Course
    )
SET @QUARTER_ID = (
    SELECT QuarterID
    FROM tblQUARTER
    WHERE QuarterName = @Quarter
    )
SET @CLASSROOM_ID = (
SELECT ClassroomID
FROM tblCLASSROOM
WHERE ClassroomName = @CMName
)
SET @SCHEDULE_ID = (
    SELECT ScheduleID
    FROM tblSCHEDULE
    WHERE ScheduleName = @Schedule
    )
INSERT INTO tblCLASS (CourseID, QuarterID, YEAR, ClassroomID, ScheduleID, Section)
VALUES (@COURSE_ID,@QUARTER_ID, @Year, @CLASSROOM_ID, @SCHEDULE_ID, @Section)
go

