CREATE   FUNCTION fnChk_BioPhil_Summer_400()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS(
		SELECT IT.InstructorTypeName, I.InstructorFName, I.InstructorLName, I.InstructorID,
		C.ClassID FROM tblINSTRUCTOR_TYPE IT
		JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON IT.InstructorTypeID = IIT.InstructorTypeID
		JOIN tblINSTRUCTOR I ON IIT.InstructorID = I.InstructorID
		JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID = IC.InstructorID
		JOIN tblCLASS C ON IC.ClassID = C.ClassID
		JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
		JOIN tblCOURSE CS ON C.CourseID = CS.CourseID
		JOIN tblDEPARTMENT D ON CS.DeptID = D.DeptID
		JOIN tblCOLLEGE CO ON D.CollegeID = CO.CollegeID
		WHERE (D.DeptName = 'Biology' OR D.DeptName = 'Philosophy')
		AND Q.QuarterName = 'Summer'
		AND CS.CourseNumber >= 400
		AND IT.InstructorTypeName NOT IN ('Associate Professor', 'Assistant Professor')
		--this means the instructor type is not Associate Professor or an Assistant Professor,
		--so return 1 (fail the constraint)
	)
	BEGIN
		SET @RET = 1
	END
RETURN @RET
END
go

