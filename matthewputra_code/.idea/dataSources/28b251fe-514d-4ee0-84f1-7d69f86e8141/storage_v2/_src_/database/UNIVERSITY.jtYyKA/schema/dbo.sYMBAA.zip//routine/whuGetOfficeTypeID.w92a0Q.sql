
CREATE PROCEDURE whuGetOfficeTypeID
@OffType VARCHAR(50),
@OffTypeID INT OUTPUT
AS 
SET @OffTypeID = (SELECT OfficeTypeID FROM tblOFFICE_TYPE WHERE OfficeTypeName = @OffType)
go

