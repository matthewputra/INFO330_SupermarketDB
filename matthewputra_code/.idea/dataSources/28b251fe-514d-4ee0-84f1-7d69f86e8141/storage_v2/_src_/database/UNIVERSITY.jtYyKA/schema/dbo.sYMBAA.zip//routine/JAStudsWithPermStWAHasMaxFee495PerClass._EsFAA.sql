Create Function JAStudsWithPermStWAHasMaxFee495PerClass (@PK INT)
Returns numeric (10,2)
As 
Begin 
		Declare @Ret Numeric (10,2) = (Select RegistrationFee 
		From tblCLASS_LIST CL
		Join tblSTUDENT S on CL.StudentID = S.StudentID
		Where RegistrationFee <= '495'
		and S.StudentPermState = '%WA')
Return @Ret
End
go

