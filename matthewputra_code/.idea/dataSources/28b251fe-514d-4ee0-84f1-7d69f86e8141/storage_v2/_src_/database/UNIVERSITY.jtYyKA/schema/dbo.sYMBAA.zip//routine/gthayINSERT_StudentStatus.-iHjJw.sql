CREATE PROCEDURE gthayINSERT_StudentStatus
@Fname varchar(20),
@Lname varchar(20),
@Birth Date,
@Status varchar(50),
@Begin Date,
@End Date
AS
DECLARE @Stu_ID INT, @Sta_ID INT
/*
--old-school look-up 'in-line'
SET @Stu_ID = (SELECT StudentID 
				FROM tblSTUDENT 
				WHERE StudentFname = @Fname 
				AND StudentLname = @Lname 
				AND StudentBirth = @Birth)
 
convert the green code above into a stored procedure!!

CREATE PROCEDURE gthayGetStudentID
@F varchar(20),
@L varchar(20),
@B Date,
@StudentID INT OUTPUT
AS

SET @StudentID = (SELECT StudentID 
				FROM tblSTUDENT 
				WHERE StudentFname = @F
				AND StudentLname = @L
				AND StudentBirth = @B)

*/
EXEC gthayGetStudentID
@F = @Fname,
@L = @Lname,
@B = @Birth,
@StudentID = @Stu_ID OUTPUT


IF @Stu_ID IS NULL
	BEGIN
		PRINT 'Hey...@Stu_ID is NULL; check spelling of names'
		RAISERROR ('@Stu_ID cannot be NULL; statement terminating',11,1)
		RETURN
	END
/*
SET @Sta_ID = (SELECT StatusID 
				FROM tblSTATUS 
				WHERE StatusName = @Status)


convert the green code above into a nested stored procedure!!

CREATE PROCEDURE gthayGetStausID
@StatusName varchar(50),
@StatusID INT OUTPUT
AS
SET @StatusID = (SELECT StatusID 
				FROM tblSTATUS 
				WHERE StatusName = @StatusName)
*/
EXEC gthayGetStausID
@StatusName = @Status,
@StatusID = @Sta_ID OUTPUT


IF @Sta_ID IS NULL
	BEGIN
		PRINT 'Mistake with spelling of statusname as @Sta_ID is null';
		THROW 56772, '@Sta_ID cannot be NULL', 1;
	END

BEGIN TRAN 
INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate)
VALUES (@Stu_ID, @Sta_ID, @Begin, @End) 
IF @@ERROR <> 0
	BEGIN
		PRINT 'error at the very end; rolling-back tran'
		ROLLBACK TRAN 
	END
ELSE
	COMMIT TRAN

go

