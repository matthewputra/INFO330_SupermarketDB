CREATE FUNCTION mb_NoAlaska23WestCampusTripleDorm()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = 0
    IF EXISTS (SELECT S.StudentID FROM tblSTUDENT S
                    JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
                    JOIN tblDORMROOM D ON SD.DormRoomID = D.DormRoomID
                    JOIN tblDORMROOM_TYPE DT ON D.DormRoomTypeID = DT.DormRoomTypeID
                    JOIN tblBUILDING B ON D.BuildingID = B.BuildingID
                    JOIN tblLOCATION L ON B.LocationID = L.LocationID
                WHERE S.StudentPermState = 'Alaska, AK'
                AND StudentBirth > DateAdd(year, -23, GetDate())
                AND DormRoomTypeDescr = 'Triple'
                AND LocationName = 'West Campus')
    SET @Ret = 1
    RETURN @Ret
END
go

