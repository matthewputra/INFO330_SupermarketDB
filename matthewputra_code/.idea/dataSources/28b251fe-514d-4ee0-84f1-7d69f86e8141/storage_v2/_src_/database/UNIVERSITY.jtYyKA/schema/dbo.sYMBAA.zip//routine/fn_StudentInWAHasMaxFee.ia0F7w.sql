CREATE FUNCTION dbo.fn_StudentInWAHasMaxFee()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF EXISTS(SELECT *
              FROM tblCLASS_LIST CL
                  JOIN tblSTUDENT S ON CL.StudentID = S.StudentID
              WHERE S.StudentPermState = 'Washington,WA'
              AND CL.RegistrationFee > 495)
    SET @RET = 1
RETURN @RET
END
go

