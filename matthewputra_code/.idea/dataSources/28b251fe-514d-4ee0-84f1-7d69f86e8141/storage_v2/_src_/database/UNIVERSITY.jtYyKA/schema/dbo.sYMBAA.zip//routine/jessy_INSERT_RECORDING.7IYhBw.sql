/* 1. Write the query to determine which customers meet the following conditions
	a. Have streamed more than 500 minutes of classical music from artists originating from the region of South America
	b. Downloaded at least 12 recordings that were recording in 'Studio G' with Greg Hay on lead vocal. */
	/*
select C.CustomerID, C.CustFname, C.CustLname, SUM(R.DurationSeconds/60) AS StreamMinutes
from CUSTOMER C
	JOIN SUBSCRIPTION S ON S.CustomerID = C.CustomerID
	JOIN ACCESS A ON A.SubscriptionID = S.SubscriptionID
	JOIN RECORDING R ON R.RecordingID = A.RecordingID
	JOIN GENRE G ON G.GenreID = R.GenreID
	JOIN PERFORMANCE P ON P.RecordingID = R.RecordingID
	JOIN ARTIST AR ON AR.ArtistID = P.ArtistID
	JOIN COUNTRY CO ON CO.CountryID = AR.CountryID
	JOIN REGION RE ON RE.RegionID = CO.RegionID
	JOIN (select C.CustomerID, C.CustFname, C.CustLname, COUNT(DISTINCT R.RecordingID) AS TotalRecordings
		  from CUSTOMER C
			  JOIN SUBSCRIPTION S ON S.CustomerID = C.CustomerID
			  JOIN ACCESS A ON A.SubscriptionID = S.SubscriptionID
			  JOIN ACCESS_TYPE ACT ON ACT.AccessTypeID = A.AccessTypeID
			  JOIN RECORDING R ON R.RecordingID = A.RecordingID
			  JOIN STUDIO ST ON ST.Studio = R.StudioID
			  JOIN PERFORMANCE P ON P.RecordingID = R.RecordingID
			  JOIN ARTIST AR ON AR.ArtistID = P.ArtistID
			  JOIN PERFORMANCE_ROLE PR ON PR.PerformanceID = P.PerformanceID
			  JOIN [ROLE] RO ON RO.RoleID = PR.RoleID
		  where ST.StudioName = 'Studio G'
		  AND ACT.AccessTypeName LIKE '%Download%'
		  AND AR.ArtistFname = 'Greg'
		  AND AR.ArtistLname = 'Hay'
		  AND RO.RoleName LIKE '%lead vocal%'
		  GROUP BY C.CustomerID, C.CustFname, C.CustLname
		  HAVING COUNT(DISTINCT R.RecordingID) > 12) sub ON sub.CustomerID = C.CustomerID
where RE.RegionName = 'South America'
AND G.GenreName LIKE '%Classical%'
AND ACT.AccessTypeName LIKE '%Stream%'
GROUP BY C.CustomerID, C.CustFname, C.CustLname, TotalRecordings
HAVING SUM(R.DurationSeconds/60) > 500
*/
/* Write a stored procedure to populate a new row into the table RECORDING. */

CREATE PROCEDURE jessy_INSERT_RECORDING
@RName varchar(30),
@RDate date,
@SName varchar(30),
@SoName varchar(30),
@MName varchar(30),
@GName varchar(30),
@DTime INT

AS

DECLARE @SID INT, @SoID INT, @MID INT, @GID INT
SET @SID  = (select StudioID from STUDIO where StudioName = @SName)
SET @SoID = (select SongID from SONG where SongName = @SoName)
SET @MID = (select MoodID from MOOD where MoodName = @MName)
SET @GID = (select GenreID from GENRE where GenreName = @GName)

INSERT INTO RECORDING(RecordingName, RecordingDate, StudioID, SongID, MoodID, GenreID, DurationSeconds)
VALUES (@RName, @RDate, @SID, @SoID, @MID, @GID, @DTime)
go

