CREATE PROCEDURE nickbonn_GetStaffID
@Fname varchar(60),
@Lname varchar(60),
@BDate Date,
@Staffy INT OUTPUT
AS

SET @Staffy = (SELECT StaffID 
            from tblSTAFF 
            WHERE StaffFName = @Fname 
            AND StaffLName = @Lname
            AND StaffBirth = @BDate)
go

