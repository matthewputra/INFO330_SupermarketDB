-- Write the code to create a stored procedure to hire a new person to an existing staff position.
CREATE PROCEDURE uspinsertStaff
@Fname varchar(20),
@Lname varchar(20),
@Birth Date,
@Position varchar(20),
@BegDate Date,
@EndDate Date,
@DeptName varchar(20)

AS
    DECLARE @StaffID Int, @PositionID int, @DeptID int
set @staffid = (select staffid from tblStaff where
                stafffname = @fname AND
                stafflname = @lname AND
                staffbirth = @birth)
set @positionid = (select positionid from tblposition where positionname = @position)
set @deptid = (select deptid from tblDepartment where deptname = @deptname)

    INSERT INTO tblStaff_Position(StaffID, PositionID, BeginDate, EndDate, DeptID)
    VALUES (@staffid, @positionid, @BegDate, @EndDate, @deptID)
go

