
--Write the code to create a stored procedure to create a new class of an existing course.
CREATE PROCEDURE jceng_NewClass
@Course varchar(30),
@Credits char(2),
@DeptName varchar(30),
@CollegeName varchar(30), 
@QuarterName varchar(30),
@Year char(4), 
@ClassroomName varchar(30),
@ClassroomType varchar(30),
@BuildingName varchar(30),
@LocationName varchar(30),
@ScheduleName varchar(30),
@Section varchar(30)

AS

DECLARE @COURSE_ID INT
DECLARE @Q_ID INT
DECLARE @CLASSROOM_ID INT
DECLARE @SCH_ID INT

SET @COURSE_ID = (SELECT CourseID FROM tblCOURSE WHERE CourseName = @Course AND Credits = @Credits)
SET @Q_ID = (SELECT QuarterID FROM tblQUARTER WHERE QuarterName = @QuarterName)
SET @CLASSROOM_ID = (SELECT ClassroomID 
                    FROM tblCLASSROOM CR
                    JOIN tblBuilding B ON CR.BuildingID = B.BuildingID 
                    JOIN tblLocation L ON B.LocationID = L.LocationID
                    JOIN tblCLASSROOM_TYPE CRT ON CR.ClassroomTypeID = CRT.ClassroomTypeID
                    WHERE ClassroomName = @ClassroomName
                    AND BuildingName = @BuildingName
                    AND LocationName = @LocationName
                    AND ClassroomTypeName = @ClassroomType)
SET @Sch_ID = (SELECT ScheduleID FROM tblSCHEDULE WHERE ScheduleName = @ScheduleName)

INSERT INTO tblCLASS (CourseID, QuarterID, [YEAR], ClassroomID, ScheduleID, Section)
VALUES (@COURSE_ID, @Q_ID, @Year, @CLASSROOM_ID, @SCH_ID, @Section)
go

