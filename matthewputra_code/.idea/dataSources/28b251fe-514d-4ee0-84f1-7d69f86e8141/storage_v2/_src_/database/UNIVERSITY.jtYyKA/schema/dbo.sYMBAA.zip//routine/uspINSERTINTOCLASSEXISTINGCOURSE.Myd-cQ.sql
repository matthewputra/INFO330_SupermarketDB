CREATE PROCEDURE uspINSERTINTOCLASSEXISTINGCOURSE
--CourseID
@CNAME VARCHAR(20),
@CNumber VARCHAR(20),

--QuarterID
@QName VARCHAR(20),

--classroomid
@RoomName VARCHAR(20),

--SCHEDULEID
@SchedName VARCHAR(20),
@SBegin time,
@SEnd time,

--nonIDs
@Year char(4),
@Sec VARCHAR(12)

AS
DECLARE @C_ID INT, @Q_ID INT,  @CM_ID INT, @S_ID INT

SET @C_ID = (
    SELECT CourseID
        FROM tblCOURSE
            WHERE CourseName = @CNAME
            AND CourseNumber = @CNumber
    )

SET @Q_ID = (
    SELECT QuarterID
        FROM tblQUARTER
            WHERE QuarterName = @QName
    )

SET @CM_ID = (
    SELECT ClassroomID
        FROM tblCLASSROOM
            WHERE ClassroomName = @CNAME
    )

SET @S_ID = (
    SELECT ScheduleID
        FROM tblSCHEDULE
            WHERE ScheduleName = @SchedName
            AND SchedBeginTime = @SBegin
            AND SchedEndTime = @SEnd
    )

INSERT INTO tblCLASS(CourseID, QuarterID, YEAR, ClassroomID, ScheduleID, Section)
VALUES(@C_ID, @Q_ID, @Year, @C_ID, @S_ID, @Sec)
go

