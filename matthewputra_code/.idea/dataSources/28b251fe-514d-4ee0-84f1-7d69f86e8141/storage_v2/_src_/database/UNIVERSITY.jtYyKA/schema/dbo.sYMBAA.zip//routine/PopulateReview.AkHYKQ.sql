CREATE PROC PopulateReview
@SubName VARCHAR(50),
@AcTName VARCHAR(50),
@RecName  VARCHAR(50),
@AcDT DATETIME,
@RName VARCHAR(50),
@RevDate DATE,
@RevBody VARCHAR(200)
AS
    DECLARE @A_ID INT, @R_ID INT

    EXEC GetAccessID
    @Subs_Name   = @SubName,
    @AcType_Name = @AcTName,
    @Rec_Name    = @RecName,
    @AcDateTime  = @AcDT,
    @Access_ID   = @A_ID  OUTPUT
    IF @A_ID IS NULL
        BEGIN
            PRINT '@A_ID can not be NULL'
            RAISERROR('@A_ID can not be NULL', 11, 1)
            RETURN
        END

    EXEC GerRatingID
    @Rating_Name  = @RName,
    @Rating_ID    = @R_ID OUTPUT
    IF @R_ID IS NULL
        BEGIN
            PRINT '@R_ID can not be NULL'
            RAISERROR('@R_ID can not be NULL', 11, 1)
            RETURN
        END

    BEGIN TRAN T1
        INSERT INTO REVIEW (AccessID, RatingID, ReviewDate, ReviewBody)
        VALUES             (@A_ID   , @R_ID   , @RevDate  , @RevBody)
    IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN T1
        END
    ELSE
        COMMIT TRAN T1
go

