CREATE PROCEDURE zwNewStudentStatus
@sfname VARCHAR(30),
@slname VARCHAR(30),
@dob DATE,
@status VARCHAR(30),
@begin DATE,
@end DATE
AS
DECLARE @studentID INT, @statusID INT

EXEC zwGetStudentID @Fname = @sfname, @Lname = @slname, @DOB = @dob, @StudentID = @studentID OUTPUT;

PRINT @studentID

IF @studentID IS NULL
BEGIN
	PRINT 'StudentID was missing'
	RAISERROR('StudentID was not found in new status procedure', 11, 1)
	RETURN
END

EXEC zwGetStatusID @StatusName = @status, @StatusID = @statusID OUTPUT;

PRINT @statusID

IF @statusID IS NULL
BEGIN
	PRINT 'StatusID was missing'
	RAISERROR('StatusID was not found in new status procedure', 11, 1)
	RETURN
END

BEGIN TRAN A

INSERT INTO tblSTUDENT_STATUS(StatusID, StudentID,BeginDate,EndDate)
VALUES(@statusID, @studentID, @begin, @end)


IF @@ERROR <> 0
BEGIN
	PRINT 'Error in insert'
	ROLLBACK TRAN A
	RETURN
END
ELSE
	COMMIT TRAN A
go

