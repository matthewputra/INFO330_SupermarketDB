CREATE FUNCTION fn_InfoCredsMore3_4(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
    (SELECT SUM(CR.Credits)
    FROM tblCOLLEGE C
        JOIN tblDEPARTMENT D on C.CollegeID = D.CollegeID
        JOIN tblCOURSE CR on D.DeptID = CR.DeptID
        JOIN tblCLASS CS on CR.CourseID = CS.CourseID
        JOIN tblCLASS_LIST CL on CS.ClassID = CL.ClassID
        JOIN tblSTUDENT S on CL.StudentID = S.StudentID
    WHERE S.StudentID = @PK
    AND CL.Grade > 3.4
    AND C.CollegeName = 'Information School')
RETURN @RET
END
go

