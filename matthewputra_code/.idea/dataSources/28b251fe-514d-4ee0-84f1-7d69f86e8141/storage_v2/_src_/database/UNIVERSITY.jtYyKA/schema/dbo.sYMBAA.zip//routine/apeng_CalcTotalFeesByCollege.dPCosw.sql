CREATE FUNCTION dbo.apeng_CalcTotalFeesByCollege(@PK INT) --We need a parameter here to hold placeholder PK values
RETURNS NUMERIC(20,2) --Numeric: 
AS
BEGIN
	DECLARE @Ret Numeric(20,2) = (
		SELECT SUM(cl.RegistrationFee)--No default value since we are calculating it
		FROM tblSTUDENT s
		JOIN tblCLASS_LIST cl ON s.StudentID = cl.StudentID
		JOIN tblCLASS cs ON cl.ClassID = cs.ClassID
		JOIN tblCOURSE cr ON cs.CourseID = cr.CourseID
		JOIN tblDEPARTMENT d ON cr.DeptID = d.DeptID
		JOIN tblCOLLEGE c ON d.CollegeID = c.CollegeID
		WHERE
		cs.YEAR < (SELECT DateAdd(Year, -2, GetDate())) AND
		s.StudentID = @PK)
RETURN @Ret
End
go

