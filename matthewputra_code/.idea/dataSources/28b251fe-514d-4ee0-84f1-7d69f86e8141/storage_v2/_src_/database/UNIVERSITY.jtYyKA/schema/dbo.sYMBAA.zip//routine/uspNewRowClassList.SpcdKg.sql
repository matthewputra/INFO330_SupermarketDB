CREATE PROCEDURE uspNewRowClassList
@Course varchar(75),
@Quarter varchar(30),
@Year char(4),
@Section varchar(4),
@Fname varchar(20),
@Lname varchar(20),
@Bdate Date,
@Grade decimal(3,2),
@RegDate Date,
@RegFee numeric(10,2)
AS
DECLARE @CLASS_ID INT, @STUDENT_ID INT
SET @CLASS_ID = (
    SELECT ClassID
    FROM tblCLASS CS
        JOIN tblQUARTER Q ON CS.QuarterID = Q.QuarterID
        JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
    WHERE CR.CourseName = @Course
    AND Q.QuarterName = @Quarter
    AND CS.[YEAR] = @Year
    AND CS.Section = @Section
    )
SET @STUDENT_ID = (
    SELECT StudentID
    FROM tblSTUDENT
    WHERE StudentFname = @Fname
    AND StudentLname = @Lname
    AND StudentBirth = @Bdate
    )
INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@CLASS_ID, @STUDENT_ID, @Grade, @RegDate, @RegFee)
go

