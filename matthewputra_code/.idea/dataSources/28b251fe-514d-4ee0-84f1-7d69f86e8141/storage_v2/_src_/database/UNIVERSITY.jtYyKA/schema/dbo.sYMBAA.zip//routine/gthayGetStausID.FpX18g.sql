CREATE PROCEDURE gthayGetStausID
@StatusName varchar(50),
@StatusID INT OUTPUT
AS
SET @StatusID = (SELECT StatusID 
				FROM tblSTATUS 
				WHERE StatusName = @StatusName)
go

