CREATE PROCEDURE zzINSERT_STUDENT_STATUS
@Fname varchar(60),
@Lname varchar(60),
@StaName varchar (125),
@Birth Date,
@BeginDate DATE,
@EndDate DATE
AS
DECLARE @studentID INT
DECLARE @statusID INT

SET @studentID = (SELECT StudentID
                    FROM tblSTUDENT
                    WHERE StudentLname=@Lname
                    AND StudentFname=@Fname
                    AND StudentBirth=@Birth)

SET @statusID =(SELECT StatusID
                FROM tblSTATUS
                WHERE StatusName=@StaName)

INSERT INTO tblSTUDENT_STATUS (StudentID,StatusID,BeginDate,EndDate)
VALUES (@studentID, @statusID,@BeginDate,@EndDate)
go

