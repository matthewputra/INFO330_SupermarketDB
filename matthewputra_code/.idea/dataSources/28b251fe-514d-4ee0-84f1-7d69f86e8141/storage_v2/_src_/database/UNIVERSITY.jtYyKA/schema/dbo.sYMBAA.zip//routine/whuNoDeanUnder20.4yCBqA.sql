CREATE FUNCTION whuNoDeanUnder20()
RETURNS INTEGER
AS
BEGIN
	DECLARE @Ret INTEGER -- match to the datatype from returns
	IF
	EXISTS (
	SELECT *
	FROM tblCOLLEGE C
		JOIN tblDEPARTMENT D ON C.CollegeID = C.CollegeID
		JOIN tblSTAFF_POSITION SP ON D.DeptID = SP.DeptID
		JOIN tblPOSITION P ON SP.PositionID = P.PositionID
		JOIN tblSTAFF S ON SP.StaffID = S.StaffID
	WHERE P.PositionName = 'Dean'
	AND DATEDIFF(year, S.StaffBirth, GETDATE()) < 21
	)
	SET @Ret = 1
RETURN @Ret
END
go

