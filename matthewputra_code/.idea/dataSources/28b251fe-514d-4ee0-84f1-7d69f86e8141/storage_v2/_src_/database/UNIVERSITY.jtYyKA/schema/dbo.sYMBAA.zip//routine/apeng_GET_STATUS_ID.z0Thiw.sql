CREATE PROCEDURE apeng_GET_STATUS_ID
@StatusName varchar(50),
@StatID INT OUTPUT
AS
SET @StatID = (SELECT StatusID FROM tblSTATUS WHERE StatusName = @StatusName)
go

