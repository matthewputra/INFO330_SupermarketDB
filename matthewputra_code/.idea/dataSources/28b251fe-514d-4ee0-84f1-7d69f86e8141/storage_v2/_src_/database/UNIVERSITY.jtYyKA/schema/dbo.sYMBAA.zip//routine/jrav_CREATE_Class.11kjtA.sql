CREATE PROCEDURE jrav_CREATE_Class
@Course varchar(75),
@Quarter varchar(30),
@Year char(4),
@Classroom varchar(125),
@ScheduleName varchar(75),
@Section varchar(4)

AS

DECLARE @CR_ID INT
DECLARE @QR_ID INT
DECLARE @CLR_ID INT
DECLARE @S_ID INT

SET @CR_ID = (SELECT CourseID FROM tblCOURSE WHERE CourseName = @Course)
SET @QR_ID = (SELECT QuarterID FROM tblQUARTER WHERE QuarterName = @Quarter)
SET @CLR_ID = (SELECT ClassroomID FROM tblCLASSROOM WHERE ClassroomName = @Classroom)
SET @S_ID = (SELECT ScheduleID FROM tblSCHEDULE WHERE ScheduleName = @ScheduleName)

INSERT INTO tblCLASS (CourseID, QuarterID, [YEAR], ClassroomID, ScheduleID, Section)
VALUES (@CR_ID, @QR_ID, @Year, @CLR_ID, @S_ID, @Section)
go

