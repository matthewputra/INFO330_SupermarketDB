CREATE PROCEDURE sailijINSERT_STUDENT_STATUS

@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@StatusName varchar(30),
@BeginDate Date,
@EndDate Date
AS
DECLARE @StudentID INT, @StatusID INT
SET @StudentID = (SELECT StudentID 
			FROM tblSTUDENT 
			WHERE StudentFname = @Fname AND StudentLname = @Lname
AND StudentBirth = @Birth)

SET @StatusID = (SELECT StatusID  
FROM tblStatus WHERE StatusName = @StatusName
)

INSERT INTO tblSTUDENT_STATUS(StudentID, StatusID, BeginDate, EndDate) 
VALUES (@StudentID,@StatusID, @BeginDate, @EndDate)

go

