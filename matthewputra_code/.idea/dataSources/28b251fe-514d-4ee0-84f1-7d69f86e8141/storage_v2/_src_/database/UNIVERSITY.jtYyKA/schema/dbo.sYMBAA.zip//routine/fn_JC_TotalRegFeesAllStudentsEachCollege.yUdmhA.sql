CREATE FUNCTION fn_JC_TotalRegFeesAllStudentsEachCollege(@PK INT)
RETURNS INT -- numeric - returning money
AS
BEGIN
	DECLARE @RET INT = (SELECT SUM(CL.RegistrationFee)
						FROM tblCOLLEGE C
							JOIN tblDEPARTMENT D ON C.CollegeID = D.CollegeID
							JOIN tblCOURSE CR ON D.DeptID = CR.DeptID
							JOIN tblCLASS CS ON CR.CourseID = CS.CourseID
							JOIN tblCLASS_LIST CL ON CS.ClassID = CL.ClassID
						WHERE C.CollegeID = @PK
						-- Year pulls year from a date 
						AND YEAR(CL.RegistrationDate) = YEAR(GETDATE())) 
RETURN @RET
END
go

