
CREATE PROCEDURE zwGetStudentID
@Fname VARCHAR(30),
@Lname VARCHAR(30),
@DOB DATE,
@StudentID INT OUTPUT
AS
	SET @StudentID = (SELECT StudentID FROM tblSTUDENT WHERE StudentFname = @Fname AND StudentLname = @Lname AND StudentBirth = @DOB)
	RETURN
go

