
--Write the code to create a stored procedure to create a new class of an existing course 

CREATE PROCEDURE uspNewClassExistingCourse
@Quarter varchar(10),
@Course varchar(50),
@Year char(4),
@Classroom varchar(50),
@Building varchar(50),
@SchedName varchar(50),
@SchedBegin time,
@SchedEnd time,
@Section char(3)
AS
DECLARE @C_ID INT, @Q_ID INT, @CR_ID INT, @S_ID INT
SET @C_ID =
(SELECT CourseID
FROM tblCOURSE 
WHERE CourseName = @Course)
SET @Q_ID =
(SELECT QuarterID
FROM tblQUARTER 
WHERE QuarterName = @Quarter)
SET @CR_ID = 
(SELECT ClassroomID
FROM tblCLASSROOM CR
JOIN tblBUILDING B ON CR.BuildingID = B.BuildingID
WHERE B.BuildingName = @Building
AND CR.ClassroomName = @Classroom)
SET @S_ID =
(SELECT ScheduleID
FROM tblSCHEDULE S
WHERE ScheduleName = @SchedName
AND SchedBeginTime = @SchedBegin
AND SchedEndTime = @SchedEnd)

BEGIN TRAN G2
INSERT INTO tblCLASS(CourseID, QuarterID, [YEAR], ClassroomID, ScheduleID, Section)
VALUES(@C_ID, @Q_ID, @Year, @CR_ID, @S_ID, @Section)
COMMIT TRAN G2
go

