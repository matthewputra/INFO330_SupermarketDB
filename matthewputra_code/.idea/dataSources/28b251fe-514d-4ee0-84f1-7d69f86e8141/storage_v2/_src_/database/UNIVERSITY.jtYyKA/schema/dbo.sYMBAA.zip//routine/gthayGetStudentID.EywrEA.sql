CREATE PROCEDURE gthayGetStudentID
@F varchar(20),
@L varchar(20),
@B Date,
@StudentID INT OUTPUT
AS

SET @StudentID = (SELECT StudentID 
				FROM tblSTUDENT 
				WHERE StudentFname = @F
				AND StudentLname = @L
				AND StudentBirth = @B)
go

