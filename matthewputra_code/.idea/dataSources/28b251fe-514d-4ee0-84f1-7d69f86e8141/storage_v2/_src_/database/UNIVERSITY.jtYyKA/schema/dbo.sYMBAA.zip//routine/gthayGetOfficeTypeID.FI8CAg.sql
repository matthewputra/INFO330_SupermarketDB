
CREATE PROCEDURE gthayGetOfficeTypeID
@OffType varchar(50),
@OffTypeID INT OUTPUT
AS

SET @OffTypeID = (SELECT OfficeTypeID FROM tblOFFICE_TYPE WHERE OfficeTypeName = @OffType)
go

