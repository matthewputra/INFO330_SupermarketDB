CREATE FUNCTION mlTotalCredit(@PK INT)
RETURNS INT
AS
    BEGIN
        DECLARE @RET INT=(SELECT SUM(CR.Credits) AS Total_credits from tblSTUDENT S
            JOIN tblCLASS_LIST CL on S.StudentID = CL.StudentID
            JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
            JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
            JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
            JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
            JOIN tblCLASSROOM SC ON CS.ClassroomID = SC.ClassroomID
            JOIN tblBUILDING B on SC.BuildingID = B.BuildingID
            JOIN tblLOCATION L ON B.LocationID = L.LocationID
            WHERE C.CollegeName='Arts and Sciences'
            AND CL.Grade>=3.4
            AND L.LocationName like '%Quad%'
            AND S.StudentID=@PK)
    RETURN @RET
    end
go

