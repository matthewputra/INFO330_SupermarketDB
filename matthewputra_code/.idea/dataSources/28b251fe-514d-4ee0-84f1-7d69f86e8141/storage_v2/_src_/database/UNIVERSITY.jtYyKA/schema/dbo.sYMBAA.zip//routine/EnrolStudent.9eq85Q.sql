CREATE   PROCEDURE EnrolStudent
@StudFName varchar(50),
@StudLName varchar(50),
@CrsName varchar(50),
@Yr CHAR(4),
@Sect varchar(4),
@Qtr varchar(30),
@Regdate DATE,
@Regfee numeric(10,2),
@Grade numeric(2,1),
@CLRoom varchar(30)
AS
DECLARE @S_ID INT, @CL_ID INT, @CO_ID INT, @Q_ID INT, @CLR_ID INT
SET @S_ID = (SELECT StudentID FROM tblSTUDENT where StudentFname=@StudFName and StudentLname=@StudLName)
SET @CO_ID =  (SELECT CourseID FROM tblCOURSE where CourseName=@CrsName)
SET @Q_ID = (SELECT QuarterID from tblQUARTER where QuarterName=@Qtr)
SET @CLR_ID= (SELECT ClassroomID from tblCLASSROOM where ClassroomName=@CLRoom)
SET @CL_ID = (SELECT ClassID from tblCLASS where CourseID=@CO_ID and QuarterID=@Q_ID and YEAR=@Yr and Section=@Sect AND ClassroomID=@CLR_ID)
-- error-handling --> we know the entire procedure will fail at the transaction if this is NULL
IF @S_ID IS NULL
BEGIN
PRINT 'Error: Student does not exist!!'
RAISERROR ('@S_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END

IF @CO_ID IS NULL
BEGIN
PRINT 'Error: Course does not exist!!'
RAISERROR ('@CO_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END

IF @CLR_ID IS NULL
BEGIN
PRINT 'Error: Classroom does not exist!!'
RAISERROR ('@CLR_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END

IF @Q_ID IS NULL
BEGIN
PRINT 'Error: Quarter does not exist!!'
RAISERROR ('@Q_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END

IF @CL_ID IS NULL
BEGIN
PRINT 'Error: Class does not exist!!'
RAISERROR ('@CL_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END
BEGIN TRAN G1
INSERT INTO tblCLASS_LIST values(@CL_ID,@S_ID,@Grade,@Regdate,@Regfee)
-- error-handling
IF @@ERROR <> 0
BEGIN
PRINT '@@ERROR is showing a number <> 0; transaction is being terminated'
ROLLBACK TRAN G1
END
ELSE
COMMIT TRAN G1
go

