CREATE PROCEDURE uspINSERTINTOCLASSDave
     -- the following are for CourseID
    @CName varchar(20),
    @CNumber varchar(20),
     -- the following is for QuarterID
    @QName varchar(20),
     -- the following is for ClassroomID
    @RoomName varchar(20),
     -- the following are for ScheduleID
    @SchedName varchar(20),
    @SBegin time,
    @SEnd time,
    -- non id's
    @Year char(4),
    @Sec varchar(12)
AS
    DECLARE @C_ID INT, @Q_ID INT, @CM_ID INT, @S_ID INT
    SET @C_ID = (
        SELECT CourseID
        FROM tblCOURSE CR
        WHERE CourseName = @CName
        AND CourseNumber = @CNumber
        )
    SET @Q_ID = (
        SELECT QuarterID
        FROM tblQUARTER
        WHERE QuarterName = @QName
        )
    SET @CM_ID = (
        SELECT ClassroomID
        FROM tblCLASSROOM
        WHERE ClassroomName = @RoomName
        )
    SET @S_ID = (
        SELECT ScheduleID
        FROM tblSCHEDULE
        WHERE ScheduleName = @SchedName
        AND SchedBeginTime = @SBegin
        AND SchedEndTime = @SEnd
        )
    INSERT INTO tblCLASS(CourseID, QuarterID, ClassroomID, ScheduleID, YEAR, Section)
    VALUES(@C_ID, @Q_ID, @CM_ID, @S_ID, @Year, @Sec)
go

