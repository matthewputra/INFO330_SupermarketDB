-- 2. BUSINESS RULE: No student older than 23 from Alaska can be assigned a dormroom on West Campus of dormroom type 'Triple'
CREATE FUNCTION fn_NoOld23DormWestTrip()
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF
	EXISTS (SELECT S.StudentID
			FROM tblSTUDENT S
				JOIN tblSTUDENT_DORMROOM SDR ON S.StudentID = SDR.StudentID
				JOIN tblDORMROOM DR ON SDR.DormRoomID = DR.DormRoomID
				JOIN tblDORMROOM_TYPE DT ON DR.DormRoomTypeID = DT.DormRoomTypeID
				JOIN tblBUILDING B ON DR.BuildingID = B.BuildingID
				JOIN tblLOCATION L ON B.LocationID = L.LocationID 
			WHERE S.StudentBirth < DateAdd(Year, -23, GetDate())
			AND S.StudentPermState = 'Alaska, AL'
			AND DT.DormRoomTypeName = 'Triple'
			AND L.LocationName = 'West Campus' )
	SET @Ret = 1
RETURN @Ret
END
go

