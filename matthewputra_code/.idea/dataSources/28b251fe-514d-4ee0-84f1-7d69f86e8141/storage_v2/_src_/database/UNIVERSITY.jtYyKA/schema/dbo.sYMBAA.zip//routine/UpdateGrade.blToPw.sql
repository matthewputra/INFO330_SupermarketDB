CREATE PROCEDURE UpdateGrade
@NewGrade decimal (3,2),
@Course varchar(50),
@F varchar(30),
@L varchar(30),
@Birth date,
@Section char(3),
@Quarter varchar(30),
@Year char(4)
AS
DECLARE @S_ID INT, @C_ID INT
SET @S_ID = (SELECT StudentID FROM tblSTUDENT 
			WHERE StudentFname = @F
			AND StudentLname = @L
			AND StudentBirth = @Birth)
SET @C_ID = (SELECT C.ClassID FROM tblCLASS C
				JOIN tblCourse CR ON C.CourseID = CR.CourseID
				JOIN tblQuarter Q ON C.QuarterID = Q.QuarterID
			WHERE CR.CourseName = @Course
			AND C.Section = @Section
			AND C.[YEAR] = @Year
			AND Q.QuarterName = @Quarter)
IF @S_ID IS NULL
	BEGIN
		PRINT '@S_ID could not be found';
		THROW 546654, '@S_ID cannot be NULL', 1;
		RETURN
	END
IF @C_ID IS NULL
	BEGIN
		PRINT '@C_ID could not be found';
		THROW 546654, '@C_ID cannot be NULL', 1;
	END
BEGIN TRAN J1
UPDATE tblCLASS_LIST
SET Grade = @NewGrade
WHERE StudentID = @S_ID
AND ClassID = @C_ID
IF @@ERROR <> 0
	ROLLBACK TRAN J1
ELSE
	COMMIT TRAN J1
go

