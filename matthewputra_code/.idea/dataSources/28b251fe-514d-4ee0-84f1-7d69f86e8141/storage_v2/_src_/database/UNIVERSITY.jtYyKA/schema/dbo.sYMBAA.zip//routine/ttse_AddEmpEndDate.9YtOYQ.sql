CREATE PROCEDURE ttse_AddEmpEndDate
@F varchar(30),
@L varchar(30),
@Birth Date,
@Position varchar(40),
@End Date
AS
DECLARE @S_ID INT, @P_ID INT
SET @S_ID = (SELECT StaffID FROM tblSTAFF WHERE StaffFname = @F AND StaffLname = @L AND StaffBirth = @Birth)
SET @P_ID = (SELECT PositionID FROM tblPOSITION WHERE PositionName = @Position)

BEGIN TRAN T
UPDATE tblSTAFF_POSITION
SET EndDate = @End
WHERE StaffID = @S_ID
AND PositionID = @P_ID
COMMIT TRAN T
go

