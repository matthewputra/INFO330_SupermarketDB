CREATE PROCEDURE usp_hjgavin_PopClass_List
@StudentFName VARCHAR (60),
@StudentLName VARCHAR (60),
@NetID VARCHAR (20),
@CourseName VARCHAR (75),
@QuarterName VARCHAR (30),
@Year char(4),
@SectionName char (4),
@RegistrationDate Date

AS
DECLARE @StID INT
DECLARE @ClassID INT
DECLARE @CourseID INT
DECLARE @QID INT

SET @StID = (SELECT StudentID
FROM tblSTUDENT
WHERE StudentFName = @StudentFname
AND StudentLName = @StudentLName
AND StudentNetID = @NetID)

	IF @StID IS NULL
	BEGIN
	PRINT '@Stid cannot be null'	
	RAISERROR ('Check search for student ID', 11, 1)
RETURN
END


SET @CourseID = (SELECT @CourseID
FROM tblCOURSE
WHERE CourseName = @CourseName)

 
SET @QID = (SELECT QuarterID
FROM tblQUARTER
WHERE QuarterName = @QuarterName)

 

SET @ClassID = (SELECT CLassID
FROM tblCLASS
WHERE CourseID = @CourseID
AND QuarterID = @QID
AND [Year] = @Year
AND Section = @SectionName)


BEGIN Tran G1
INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate)
VALUES (@ClassID, @StID, NULL, @RegistrationDate)
IF @@ERROR <> 0
ROLLBACK Tran G1
ELSE
COMMIT Tran G1
go

