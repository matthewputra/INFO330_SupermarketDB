CREATE FUNCTION No_23AlaskaTripleDorm()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF EXISTS (SELECT S.StudentID
        FROM tblSTUDENT S
            JOIN tblSTUDENT_DORMROOM tSD on S.StudentID = tSD.StudentID
            JOIN tblDORMROOM tD on tSD.DormRoomID = tD.DormRoomID
            JOIN tblDORMROOM_TYPE tDT on tD.DormRoomTypeID = tDT.DormRoomTypeID
            JOIN tblBUILDING t on tD.BuildingID = t.BuildingID
            JOIN tblLOCATION tL on t.LocationID = tL.LocationID
        WHERE tL.LocationName = 'WEST CAMPUS'
        AND tDT.DormRoomTypeName = 'Triple'
        AND S.StudentPermState = 'Alaska, AK'
        AND S.StudentBirth < DATEADD(YEAR, -23, GETDATE())
        )
    SET @RET = 1
RETURN @RET
end
go

