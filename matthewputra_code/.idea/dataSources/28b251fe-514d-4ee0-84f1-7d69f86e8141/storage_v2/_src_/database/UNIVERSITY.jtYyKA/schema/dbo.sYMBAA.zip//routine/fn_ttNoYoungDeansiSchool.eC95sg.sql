CREATE FUNCTION fn_ttNoYoungDeansiSchool () -- Business rule, no parameter
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0 --Default is zero
		IF EXISTS (SELECT *
			FROM tblCOLLEGE C
				JOIN tblDEPARTMENT D ON C.CollegeID = D.CollegeID
				JOIN tblSTAFF_POSITION SP ON D.DeptID = SP.DeptID
				JOIN tblPOSITION P ON SP.PositionID = P.PositionID
				JOIN tblSTAFF S ON SP.StaffID = S.StaffID
			WHERE C.CollegeName = 'Information School'
			AND S.StaffBirth > DateAdd(Year, -41, GetDate())
		)
	SET @RET = 1
RETURN @RET
END
go

