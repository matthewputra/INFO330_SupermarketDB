CREATE PROCEDURE anukriti_GetStaffID
@FName VARCHAR(60),
@LName VARCHAR(60),
@DOB Date,
@Staffy INT OUTPUT
AS
SET  @Staffy = (SELECT StaffID
                FROM tblSTAFF
                WHERE StaffFName = @FName
                AND StaffLName = @LName
                AND StaffBirth = @DOB)
go

