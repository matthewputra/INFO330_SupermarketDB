
CREATE FUNCTION fn_CalcStaffAge(@PK INT)
RETURNS numeric(3,1)
AS
BEGIN
	DECLARE @RET numeric(3,1) =
		(SELECT DATEDIFF(Day, StaffBirth, GetDate()) /365.25
		FROM tblSTAFF
		WHERE StaffID = @PK)

	RETURN @RET
END
go

