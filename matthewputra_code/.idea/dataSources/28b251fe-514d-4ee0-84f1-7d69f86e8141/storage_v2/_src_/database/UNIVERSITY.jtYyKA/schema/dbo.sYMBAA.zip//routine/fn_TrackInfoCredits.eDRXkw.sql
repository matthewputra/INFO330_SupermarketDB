CREATE FUNCTION fn_TrackInfoCredits(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
        (SELECT SUM(CR.Credits)
        FROM tblCOURSE CR
            JOIN tblCLASS CS on CR.CourseID = CS.CourseID
            JOIN tblCLASS_LIST CL on CS.ClassID = CL.ClassID
            JOIN tblSTUDENT S on CL.StudentID = S.StudentID
            JOIN tblDEPARTMENT D on CR.DeptID = D.DeptID
            JOIN tblCOLLEGE C on D.CollegeID = C.CollegeID
        WHERE C.CollegeName = 'Information School'
        AND CL.Grade > 3.4
        AND S.StudentID = @PK)

RETURN @RET
END
go

