
-- Stored Procedures - Store - EventVehicle

-- EventVehicle 

-- should event not have event name?
-- 
CREATE PROCEDURE get_EventID
@BeginDateT DATETIME,
@EndDateT DATETIME,
@E_ID INT OUTPUT
AS 

Set @E_ID = (SELECT EventID FROM tblEVENT Where BeginDateTime = @BeginDateT)
go

