CREATE  FUNCTION fn_ss251_NoOfClassesSince1953(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = (
        SELECT COUNT(CL.ClassID)
        FROM tblCOURSE CO
            JOIN tblCLASS CL ON CL.CourseID = CO.CourseID
        WHERE CO.CourseID = @PK AND CL.YEAR >= 1953
        )
    RETURN @Ret
END
go

