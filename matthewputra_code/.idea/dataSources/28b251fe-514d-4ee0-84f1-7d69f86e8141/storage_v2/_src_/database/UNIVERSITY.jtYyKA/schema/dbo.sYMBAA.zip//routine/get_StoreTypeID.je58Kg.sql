
CREATE PROCEDURE get_StoreTypeID
@StoreTypeName VARCHAR(100),
@ST_ID INT OUTPUT
AS 

SET @ST_ID = (SELECT StoreTypeID FROM tblSTORE_TYPE Where StoreTypeName = @StoreTypeName)
go

