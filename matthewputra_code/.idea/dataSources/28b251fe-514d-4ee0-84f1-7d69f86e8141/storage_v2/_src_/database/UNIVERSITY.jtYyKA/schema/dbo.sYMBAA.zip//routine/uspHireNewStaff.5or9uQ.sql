
CREATE PROCEDURE uspHireNewStaff
@fname varchar(20),
@lname varchar(20),
@address varchar(30),
@city varchar(30),
@state varchar(20),
@zip varchar(10),
@birth Date,
@netid Integer,
@email varchar(30),
@gender varchar(20)
AS
DECLARE @StaffID INT, @PosID INT
-- SET @StaffID = ()
-- SET @PosID = ()
BEGIN TRAN E1
INSERT INTO tblSTAFF(StaffFName, StaffLName, StaffAddress, StaffCity, StaffState, StaffZip, StaffBirth, StaffNetID, StaffEmail, Gender)
VALUES(@fname, @lname, @address, @city, @state, @zip, @birth, @netid, @email, @gender)
COMMIT TRAN E1

-- 7.Write the code to create a stored procedure to create a new class of an existing course.


-- 8.Write the code to create a stored procedure to register an existing student to an existing class.
go

