CREATE PROCEDURE jwAddStudenttoClass
@RegDate Date,
@RegFee numeric(10,2),
-- to determine StudentID
@SFname varchar(100),
@SLname varchar(100),
@SBirth Date,
@PermAddress varchar(150),
@SState varchar(50),
-- to determine ClassID
@Sec varchar(2),
@Yr char(4),
   -- to determine CourseID
@CrsName varchar(50),
@Creds INT,
@CrsNum varchar(5),
   -- to determine QuarterID
@QName varchar(50)

AS 

DECLARE @C_ID INT, @S_ID INT

SET @C_ID = (SELECT ClassID FROM tblCLASS C 
			 JOIN tblCOURSE CS on C.CourseID = CS.CourseID
			 JOIN tblQuarter Q on C.QuarterID = Q.QuarterID
			 WHERE CS.CourseName = @CrsName AND CS.Credits = @Creds
			 AND CS.CourseNumber = @CrsNum AND Q.QuarterName = @QName
			 AND C.Section = @Sec AND C.[YEAR] = @Yr)

SET @S_ID = (SELECT StudentID FROM tblSTUDENT WHERE
			 StudentFname = @SFname AND StudentLname = @SLname AND
			 StudentPermAddress = @PermAddress AND StudentBirth = @SBirth AND
			 StudentPermState = @SState)

IF @C_ID IS NULL
		BEGIN
			PRINT 'ClassID is Null: Check the Spelling of the Course, Section, Year, Number of Credits, or Course Number';
			THROW 567003, '@C_ID cannot be NULL', 1;
		END
IF @S_ID IS NULL
		BEGIN
			PRINT 'StudentID is Null: Check the Spelling of the Student First or Last Name, Address, or Birth Date';
			THROW 567003, '@C_ID cannot be NULL', 1;
		END

INSERT INTO tblCLASS_LIST(ClassID, StudentID, RegistrationDate, RegistrationFee)
VALUES(@C_ID, @S_ID, @RegDate, @RegFee)
go

