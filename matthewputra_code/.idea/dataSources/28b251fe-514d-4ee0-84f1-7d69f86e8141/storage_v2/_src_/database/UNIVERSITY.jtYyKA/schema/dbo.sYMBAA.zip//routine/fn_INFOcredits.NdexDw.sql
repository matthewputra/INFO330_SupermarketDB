CREATE FUNCTION fn_INFOcredits(@PK INT)
   RETURNS INT
   AS
   BEGIN
   DECLARE @Ret INT = (SELECT SUM(CR.Credits)
       FROM tblSTUDENT S
       JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
       JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
       JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
       JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
       JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
       WHERE C.CollegeName = 'Information School'
       AND CL.Grade > 3.4
       AND S.StudentID = @PK ) --anchor it)
RETURN @Ret
END
go

