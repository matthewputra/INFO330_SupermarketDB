CREATE FUNCTION whu_BioPhil400LevelSummerAssistnatAssociateProf()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0 
	IF EXISTS (	
	SELECT * 
	FROM tblDEPARTMENT D 
		JOIN tblCOURSE CR ON D.DeptID = CR.DeptID
		JOIN tblCLASS CS ON CR.CourseID = CS.CourseID
		JOIN tblQUARTER Q ON CS.QuarterID = Q.QuarterID
		JOIN tblINSTRUCTOR_CLASS IC ON CS.ClassID = IC.ClassID
		JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON IC.InstructorID = IIT.InstructorID
		JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID = IT.InstructorTypeID
	WHERE CR.CourseNumber LIKE '4%'
	AND ( D.DeptName = 'BIOLOGY' OR D.DeptName = 'PHILOSOPHY')
	AND Q.QuarterName = 'Summer'
	AND IT.InstructorTypeName NOT IN ('Assistant Professor', 'Associate Professor')
	)
	BEGIN
	SET @RET = 1
	END
RETURN @RET
END
go

