CREATE PROCEDURE apengSTUDENT_REGISTRATION

@StudentFname varchar(30),
@StudentLname varchar(30),
@Birth Date,
@Course varchar(50),
@Year char(4),
@Section char(3),
@Quarter varchar(30),
@Fee DECIMAL(16,2)
AS
DECLARE @StudentID INT --These are the required columns for tblInstructor_Class. Both are foreign keys/integers
DECLARE @ClassID INT --No values yet
DECLARE @Date DATE = GETDATE()

SET @StudentID = (
	SELECT
		StudentID
	FROM
		tblSTUDENT
	WHERE
		StudentFname = @StudentFname AND
		StudentLname = @StudentLname AND
		StudentBirth = @Birth)

IF @StudentID IS NULL
	BEGIN
		RAISERROR ('@StudentID cannot be NULL. Please check your spelling. Session terminated.',11,1)
		RETURN
	END


SET @ClassID = (
	SELECT
		ClassID
	FROM
		tblCLASS c
		JOIN tblCOURSE cr ON c.CourseID = cr.CourseID
		JOIN tblQUARTER q ON c.QuarterID = q.QuarterID
	WHERE
		cr.CourseName = @Course
		AND c.YEAR = @Year
		AND q.QuarterName = @Quarter
		AND c.Section = @Section)

IF @ClassID IS NULL
	BEGIN
		RAISERROR ('@ClassID cannot be NULL. Please check your spelling. Session terminated.',11,1)
		RETURN
	END

INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@ClassID, @StudentID, NULL, @Date, @Fee)
go

