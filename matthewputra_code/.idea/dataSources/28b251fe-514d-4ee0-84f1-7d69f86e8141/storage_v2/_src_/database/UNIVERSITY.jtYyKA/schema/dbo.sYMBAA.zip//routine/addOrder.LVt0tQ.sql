
-- add order stored proc
CREATE PROC addOrder
    @CustFname varchar(30),
    @CustLname varchar(30),
    @CustDOB Date,
    @EmpFname VARCHAR(30),
    @EmpLname VARCHAR(30),
    @EmpDOB VARCHAR(30),
    @ProdName varchar(50),
    @OrderDate Date,
    @Quantity INT
AS

DECLARE @CustID INT
DECLARE @ProdID INT
DECLARE @EmpID INT
-- populate variables
SET @CustID = (SELECT CustID
FROM tblCUSTOMER
WHERE CustFname = @CustFname
    AND CustLname = @CustLname
    AND CustDOB = @CustDOB)
--error-handling goes here
IF @CustID IS NULL
		BEGIN
    PRINT 'Hey...find the right customer cuz this thing is empty'
    RAISERROR ('Cannot process and order without a real customer', 11,1)
    RETURN
END
SET @EmpID = (SELECT EmpID
FROM tblEMPLOYEE
WHERE EmpFname = @EmpFname
    AND EmpLname = @EmpLname
    AND EmpDOB = @EmpDOB)
--error-handling goes here
IF @EmpID IS NULL
		BEGIN
    PRINT 'Hey...find the right employee cuz this thing is empty'
    RAISERROR ('Cannot process and order without a real employee', 11,1)
    RETURN
END

SET @ProdID = (SELECT ProdID
FROM tblPRODUCT
WHERE ProdName = @ProdName)
IF @ProdID IS NULL
        BEGIN
    PRINT 'Invalid product name'
    RAISERROR ('Cannot process without real product', 11,1)
    RETURN
END

BEGIN TRAN G1
INSERT INTO tblORDER
    (OrderDate, CustID, ProdID, EmpID, Quantity)
VALUES
    (@OrderDate, @CustID, @ProdID, @EmpID, @Quantity)
IF @@ERROR <> 0
	ROLLBACK TRAN G1
ELSE
	COMMIT TRAN G1
go

