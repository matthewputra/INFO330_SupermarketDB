CREATE FUNCTION fn_NoFromAlaskaTripleWestCampus()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = 0
    IF EXISTS(SELECT *
              FROM tblSTUDENT S
                JOIN tblSTUDENT_DORMROOM SD on S.StudentID = SD.StudentID
                JOIN tblDORMROOM D on SD.DormRoomID = D.DormRoomID
                JOIN tblDORMROOM_TYPE DT on D.DormRoomTypeID = DT.DormRoomTypeID
                JOIN tblBUILDING B on D.BuildingID = B.BuildingID
                JOIN tblLOCATION L on B.LocationID = L.LocationID
              WHERE S.StudentPermState = 'Alaska'
                AND S.StudentBirth > DATEADD(YEAR, -23, GETDATE())
                AND DT.DormRoomTypeName = 'Triple'
                AND L.LocationName = 'West Campus'
        )
    SET @Ret = 1
RETURN @Ret
END
go

