CREATE FUNCTION INFOCredits(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
        (SELECT COUNT(CR.Credits)
        FROM tblCollege CG
            JOIN tblDEPARTMENT D on D.CollegeID = CG.CollegeID
            JOIN tblCOURSE CR on CR.DeptID = D.DeptID
            JOIN tblCLASS C ON C.COURSEID = CR.CourseID
            JOIN tblCLASS_LIST CL on C.ClassID = CL.ClassID
            JOIN tblSTUDENT S on CL.StudentID = S.StudentID
        WHERE S.StudentID = @PK
            AND CG.CollegeName = 'Information School'
            AND CL.Grade > 3.4
            )
Return @RET
END
go

