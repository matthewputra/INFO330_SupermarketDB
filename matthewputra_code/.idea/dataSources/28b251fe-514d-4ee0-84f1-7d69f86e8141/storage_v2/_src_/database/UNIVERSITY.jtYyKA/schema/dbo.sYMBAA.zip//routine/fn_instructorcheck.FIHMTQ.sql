CREATE FUNCTION dbo.fn_instructorcheck()
RETURNS INT
AS
BEGIN 
DECLARE @ret INT=0
IF EXISTS 
(SELECT *
 FROM tblQUARTER Q 
JOIN tblCLASS CL ON Q.QuarterID=CL.QuarterID 
JOIN tblCOURSE CO ON CO.CourseID=CL.CourseID 
JOIN tblDEPARTMENT DE ON DE.DeptID=CO.DeptID 
JOIN tblINSTRUCTOR_CLASS INC ON INC.ClassID=CL.ClassID
JOIN tblINSTRUCTOR INS ON INS.InstructorID=INC.InstructorID 
JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON IIT.InstructorID=INS.InstructorID
JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID=IT.InstructorTypeID
WHERE DE.DeptName='Biology' or DE.DeptName='Philosophy'
AND Q.QuarterName='Summer'
AND IT.InstructorTypeName not in ('Assistant Professor', 'Associate Professor')
AND CO.CourseName LIKE '%4__')
BEGIN 
SET @ret=1
END 
RETURN @ret
END
go

