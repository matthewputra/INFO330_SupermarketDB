
-- Store 

CREATE PROCEDURE get_CompanyID
@CompanyName VARCHAR(100),
@C_ID INT OUTPUT
AS 

Set @C_ID = (SELECT CompanyID FROM tblCOMPANY Where CompanyName = @CompanyName)
go

