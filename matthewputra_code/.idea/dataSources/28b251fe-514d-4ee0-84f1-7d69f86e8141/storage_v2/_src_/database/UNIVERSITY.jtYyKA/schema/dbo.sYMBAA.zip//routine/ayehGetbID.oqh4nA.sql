CREATE PROCEDURE ayehGetbID
    @BuildingName varchar(50),
    @BldgID INT OUTPUT
    AS
    SET @BldgID = (SELECT BuildingID FROM tblBUILDING WHERE BuildingName = @BuildingName)
go

