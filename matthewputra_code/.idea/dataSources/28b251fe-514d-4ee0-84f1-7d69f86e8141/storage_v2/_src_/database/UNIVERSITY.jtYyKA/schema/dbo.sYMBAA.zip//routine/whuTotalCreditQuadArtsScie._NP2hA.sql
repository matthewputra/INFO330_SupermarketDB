CREATE FUNCTION whuTotalCreditQuadArtsScie(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = (
	SELECT SUM(CR.Credits)
	FROM tblSTUDENT S
		JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
		JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
		JOIN tblCOURSE CR ON CR.CourseID = CS.CourseID
		JOIN tblDEPARTMENT D ON D.DeptID = CR.DeptID
		JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeDescr
		JOIN tblCLASSROOM CM ON CM.ClassroomID = CS.ClassroomID
		JOIN tblBUILDING B ON B.BuildingID = CM.BuildingID
		JOIN tblLOCATION L ON L.LocationID = B.LocationID
	WHERE C.CollegeName = 'Arts and Science'
	AND CL.Grade >= 3.4
	AND L.LocationName = '%Quad%'
	AND CS.[YEAR] >= '2000'
	AND S.StudentID = @PK)
RETURN @RET 
END
go

