CREATE PROCEDURE SK_UpdateStaffPositionforEndDate
    @PositionName varchar(50),
    @StaffFname varchar(60),
    @StaffLname varchar(60),
    @StaffBirth date,
    @BeginDate datetime,
    @NewEndDate datetime,
    @DeptName varchar(75)
AS
    DECLARE @P_ID INT, @S_ID INT, @D_ID INT

SET @S_ID = (SELECT StaffID FROM tblSTAFF S
                    WHERE S.StaffFname = @StaffFname
                    AND S.StaffLname = @StaffLname
                    AND S.StaffBirth = @StaffBirth)

        IF @S_ID IS NULL
        BEGIN
                PRINT '@S_ID could not be found';
                THROW 546654, '@S_ID cannot be NULL', 1;
        END

SET @P_ID = (SELECT PositionID FROM tblPOSITION P
                    WHERE P.PositionName = @PositionName)

    IF @P_ID IS NULL
        BEGIN
                PRINT '@P_ID could not be found';
                THROW 546654, '@P_ID cannot be NULL', 1;
        END

SET @D_ID = (SELECT DeptID FROM tblDEPARTMENT D
                    WHERE D.DeptName = @DeptName)

      IF @D_ID IS NULL
        BEGIN
                PRINT '@D_ID could not be found';
                THROW 546654, '@D_ID cannot be NULL', 1;
        END

    BEGIN TRAN S
UPDATE tblSTAFF_POSITION
SET EndDate = @NewEndDate
WHERE PositionID = @P_ID
AND StaffID = @S_ID
AND DeptID = @D_ID
AND BeginDate = @BeginDate
     IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN S
        END
ELSE
COMMIT TRAN S
go

