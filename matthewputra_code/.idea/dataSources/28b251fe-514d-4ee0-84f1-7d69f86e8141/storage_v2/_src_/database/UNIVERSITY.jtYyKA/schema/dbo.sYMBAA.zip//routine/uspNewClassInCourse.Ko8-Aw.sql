CREATE PROC uspNewClassInCourse
	@CourseName	varchar(15),
	@CourseDes	varchar(100), 
	@Credits	float,
	@Qname		varchar(10),
	@SchedName	varchar(15),
	@Year		char(4),
	@CName		varchar(20)
AS
	DECLARE @COURSE_ID INT, @Q_ID INT, @SC_ID INT, @C_ID INT
	SET @COURSE_ID = (SELECT CourseID FROM tblCOURSE C
					  WHERE C.CourseName = @CourseName
					  AND C.Credits = @Credits
					  AND C.CourseDescr = @CourseDes)
	SET @Q_ID = (SELECT QuarterID FROM tblQUARTER Q
				 WHERE Q.QuarterName = @Qname)
	SET @SC_ID = (SELECT ScheduleID FROM tblSCHEDULE S
				  WHERE S.ScheduleName = @SchedName)
	SET @C_ID = (SELECT ClassroomID FROM tblCLASSROOM CL
				 WHERE CL.ClassroomName = @CName)
BEGIN TRAN newClass1
	INSERT INTO tblCLASS
		(CourseID, QuarterID, [YEAR], ClassroomID, ScheduleID)
	values(@COURSE_ID, @Q_ID, @Year, @C_ID, @SC_ID)
COMMIT TRAN newClass1
go

