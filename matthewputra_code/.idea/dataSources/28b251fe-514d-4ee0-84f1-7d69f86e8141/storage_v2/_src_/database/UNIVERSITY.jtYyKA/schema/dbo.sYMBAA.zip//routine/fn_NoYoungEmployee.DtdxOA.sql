CREATE FUNCTION fn_NoYoungEmployee()
RETURNS INT
AS
    BEGIN
        DECLARE @Ret INT = 0
        IF EXISTS(SELECT CJT.JobTaskID
            FROM EMPLOYEE AS E
            JOIN EMPLOYEE_SKILL AS ES ON E.EmpID = ES.EmpID
            JOIN CUST_JOB_TASK AS CJT ON ES.EmpSkillID = CJT.EmpSkillID
            JOIN TOOL AS T ON CJT.ToollID = T.ToollID
            JOIN TOOL_TYPE AS TT ON T.ToolTypeID = TT.ToolTypeID
            WHERE E.EmpBirthDate > DATEADD(year, -21, GETDATE()) AND
                  TT.ToolTypeName = 'Land Mauler')
        SET @Ret = 1
        RETURN @Ret
    END
go

