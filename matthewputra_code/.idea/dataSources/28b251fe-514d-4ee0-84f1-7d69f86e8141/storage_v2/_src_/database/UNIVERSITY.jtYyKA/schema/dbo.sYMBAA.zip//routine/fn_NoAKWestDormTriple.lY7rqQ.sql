CREATE FUNCTION fn_NoAKWestDormTriple()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF
    EXISTS(
        SELECT S.StudentID
        FROM tblSTUDENT S
            JOIN tblSTUDENT_DORMROOM SD on S.StudentID = SD.StudentID
            JOIN tblDORMROOM D on SD.DormRoomID = D.DormRoomID
            JOIN tblDORMROOM_TYPE DT on D.DormRoomTypeID = DT.DormRoomTypeID
            JOIN tblBUILDING B on D.BuildingID = B.BuildingID
            JOIN tblLOCATION L on B.LocationID = L.LocationID
            JOIN tblBUILDING_TYPE BT on B.BuildingTypeID = BT.BuildingTypeID
        WHERE L.LocationName = 'West Campus'
        AND BT.BuildingTypeName LIKE 'Dorm%'
        AND DT.DormRoomTypeName = 'Triple'
        AND S.StudentPermState = 'Alaska, AK'
        AND S.StudentBirth < DATEADD(year, -23, getdate())
        GROUP BY S.StudentID
        )
    SET @RET = 1
    RETURN @RET
    END
go

