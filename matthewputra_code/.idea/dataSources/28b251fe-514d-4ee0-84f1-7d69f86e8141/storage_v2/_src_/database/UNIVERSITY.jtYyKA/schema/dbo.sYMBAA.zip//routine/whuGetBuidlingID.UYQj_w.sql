CREATE PROCEDURE whuGetBuidlingID
@Building VARCHAR(50),
@BldgID INT OUTPUT -- ensure to include OUTPUT 
AS 
SET @BldgID = (SELECT BuildingID FROM tblBUILDING WHERE BuildingName = @Building)
go

