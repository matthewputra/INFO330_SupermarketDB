CREATE FUNCTION fn_NoStudOlder23AlaskatoWCampusTriple()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS (SELECT *
			FROM tblSTUDENT S
				JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
				JOIN tblDORMROOM D ON SD.DormRoomID = D.DormRoomID
				JOIN tblDORMROOM_TYPE DT ON D.DormRoomTypeID = DT.DormRoomTypeID
				JOIN tblBUILDING B ON D.BuildingID = B.BuildingID
				JOIN tblLOCATION L ON B.LocationID = L.LocationID
			WHERE L.LocationName = 'West Campus'
			AND DT.DormRoomTypeName = 'Triple'
			AND S.StudentPermState = 'Alaska, AK'
			AND StudentBirth > DATEADD(Year, 23, GETDATE())
			GROUP BY S.StudentID)
	SET @RET = 1
	RETURN @RET
	END
go

