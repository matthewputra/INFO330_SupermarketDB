
--8 Write the code to create a stored procedure to register an existing student to an existing class.
CREATE PROCEDURE uspSTUDENTREGISTRATION
@FName VARCHAR(20),
@LName VARCHAR(20),
@SBirth DATE,
@CourseName VARCHAR (50),
@QName VARCHAR (20),
@Section CHAR(2)
AS 
DECLARE @C_ID INT, @S_ID INT
SET @C_ID = (SELECT ClassID
			FROM tblCLASS C
			JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
			JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
			WHERE CO.CourseName = @CourseName
			AND C.Section = @Section
			AND Q.QuarterName = @QName
			)
SET @S_ID = (SELECT StudentID
			FROM tblSTUDENT
			WHERE StudentFName = @FName
			AND StudentLName = @LName
			AND StudentBirth = @SBirth
			)
INSERT INTO tblCLASS_LIST (ClassID, StudentID)
VALUES (@C_ID, @S_ID)
go

