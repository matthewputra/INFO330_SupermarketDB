CREATE FUNCTION fn_calc_num_reg_students(@PK INT) -- must anchor to PK
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = (SELECT COUNT(CL.StudentID)
				FROM tblCLASS_LIST CL
					JOIN tblCLASS C ON CL.ClassID = C.ClassID
				WHERE CL.ClassID = @PK)
RETURN @RET
END
go

