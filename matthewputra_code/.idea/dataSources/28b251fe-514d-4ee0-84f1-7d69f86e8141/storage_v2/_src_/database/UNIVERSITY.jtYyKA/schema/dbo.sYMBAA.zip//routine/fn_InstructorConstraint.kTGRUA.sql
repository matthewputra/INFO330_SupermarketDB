CREATE   FUNCTION fn_InstructorConstraint()
RETURNS INT
AS
BEGIN
   DECLARE @RET INT = 0
   IF EXISTS(SELECT * FROM tblINSTRUCTOR_CLASS IC
           JOIN tblCLASS C ON IC.ClassID=C.ClassID
           JOIN tblCOURSE CO ON C.CourseID=CO.CourseID
		   JOIN tblQUARTER Q ON C.QuarterID=Q.QuarterID
		   JOIN tblINSTRUCTOR I ON IC.InstructorID=I.InstructorID
		   JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON I.InstructorID=IIT.InstructorID
		   JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID=IT.InstructorTypeID
           WHERE (CO.CourseName LIKE 'BIOL4%' OR CourseName LIKE 'PHIL4%')
           AND (IT.InstructorTypeName not in( 'Associate Professor','Assistant Professor'))
		   AND Q.QuarterName='Summer')
   SET @RET = 1
   RETURN @RET
END
go

