
CREATE FUNCTION fn_ERNo23AlaskaTriple()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS
	(
		SELECT *
		FROM tblSTUDENT S
			JOIN tblSTUDENT_DORMROOM SD ON SD.StudentID = S.StudentID
			JOIN tblDORMROOM D ON SD.DormRoomID = D.DormRoomID
			JOIN tblBUILDING B ON D.BuildingID = B.BuildingID
			JOIN tblLOCATION L ON L.LocationID = B.LocationID
			JOIN tblDORMROOM_TYPE DT ON D.DormRoomTypeID = DT.DormRoomTypeID
		WHERE S.StudentBirth < DATEADD(YEAR, -23, GETDATE())
		AND S.StudentPermState = 'Alaska, AK'
		AND L.LocationName = 'West Campus'
		AND DT.DormRoomTypeName = 'triple'
	)
	SET @RET = 1
RETURN @RET
END
go

