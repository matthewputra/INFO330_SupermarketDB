
CREATE PROCEDURE uspAddPersToPos
@PosName varchar(20),
@Fname varchar(20),
@Lname varchar(20),
@Birth DATE,
@NetID INT,
@begin DATE,
@end DATE,
@DeptName varchar(20)
AS
DECLARE @StaffID INT, @PosID INT, @DeptID INT
SET @StaffID = (SELECT StaffID
				FROM tblSTAFF
				WHERE StaffFName = @Fname
					AND StaffLName = @Lname
					AND StaffBirth = @Birth
					AND StaffNetID = @NetID)
SET @PosID = (SELECT PositionID
			  FROM tblPOSITION
			  WHERE PositionName = @PosName)
SET @DeptID = (SELECT @DeptID
			   FROM tblDEPARTMENT
			   WHERE DeptName = @DeptName)
INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES(@StaffID, @PosID, @begin, @end, @DeptID)
go

