CREATE PROCEDURE abgthay_INSERT_Registration
@Fname varchar(60),
@Lname varchar(60),
@Birth Date,
@RegFee Numeric(10,2),
@RegDate Date,
@Grade Numeric(3, 2) = NULL,
@CourseName varchar(75),
@Year char(4), 
@Section varchar(4),
@Quarter varchar(30)

AS 

DECLARE @C_ID INT
DECLARE @S_ID INT

SET @C_ID = (SELECT ClassID 
			FROM tblCLASS c
				JOIN tblQUARTER Q ON c.QuarterID = q.QuarterID
				JOIN tblCOURSE cr ON c.courseID = cr.CourseID
			WHERE Q.QuarterName = @Quarter
			AND CR.CourseName = @CourseName
			AND c.[Year] = @Year
			AND c.Section = @Section)

SET @S_ID = (SELECT StudentID
			FROM tblSTUDENT
			WHERE StudentFname = @Fname
			AND StudentLName = @Lname
			AND StudentBirth = @Birth)
			
INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee) 
VALUES (@C_ID, @S_ID, @Grade, @RegDate, @RegFee)
go

