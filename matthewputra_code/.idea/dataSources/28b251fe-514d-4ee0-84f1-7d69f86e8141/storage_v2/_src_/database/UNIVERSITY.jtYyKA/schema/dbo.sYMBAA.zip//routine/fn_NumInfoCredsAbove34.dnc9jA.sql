CREATE FUNCTION fn_NumInfoCredsAbove34 (@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT =
		(SELECT COUNT(CR.Credits)
			FROM tblCOURSE CR
			JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
			JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
			JOIN tblCLASS CS ON CR.CourseID = CS.CourseID
			JOIN tblCLASS_LIST CL ON CS.ClassID = CL.ClassID
			JOIN tblSTUDENT S ON CL.StudentID = S.StudentID
			WHERE CL.Grade > 3.4
			AND C.CollegeName = 'Information School'
			AND S.StudentID = @PK)
		RETURN @RET 
		END
go

