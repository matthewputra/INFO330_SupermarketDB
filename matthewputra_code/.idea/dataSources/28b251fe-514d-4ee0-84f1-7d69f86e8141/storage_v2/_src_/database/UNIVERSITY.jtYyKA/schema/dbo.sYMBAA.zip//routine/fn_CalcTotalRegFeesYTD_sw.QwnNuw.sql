CREATE FUNCTION fn_CalcTotalRegFeesYTD_sw(@PK INT)
RETURNS NUMERIC(30,2)
AS
BEGIN
	DECLARE @RET NUMERIC(30,2) = (
	
	SELECT SUM(RegistrationFee)
		FROM tblCLASS_LIST CL
			JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
			JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
			JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
			JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
		WHERE C.CollegeID = @PK
			AND YEAR(RegistrationDate) = YEAR(GetDate())
		)

RETURN @RET
END
go

