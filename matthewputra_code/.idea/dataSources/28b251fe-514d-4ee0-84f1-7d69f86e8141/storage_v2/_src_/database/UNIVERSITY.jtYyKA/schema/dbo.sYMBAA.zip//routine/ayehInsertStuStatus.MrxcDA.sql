CREATE PROCEDURE ayehInsertStuStatus
@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@Bdate Date,
@Edate Date,
@Status varchar(30)
AS
DECLARE @StudentID INT
DECLARE @StatusID INT
SET @StudentID = (SELECT S.StudentID FROM tblStudent S JOIN tblStudent_Status SS ON SS.StudentID = S.StudentID
    JOIN tblSTATUS S2 ON S2.StatusID = SS.StatusID
    WHERE S.StudentFname = @Fname AND S.StudentLname = @Lname AND S.StudentBirth = @Birth)
SET @StatusID = (SELECT StatusID FROM tblStatus WHERE StatusName = @Status)
INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate) -- these are required columns in the table
VALUES(@StudentID, @StatusID, @Bdate, @Edate)
go

