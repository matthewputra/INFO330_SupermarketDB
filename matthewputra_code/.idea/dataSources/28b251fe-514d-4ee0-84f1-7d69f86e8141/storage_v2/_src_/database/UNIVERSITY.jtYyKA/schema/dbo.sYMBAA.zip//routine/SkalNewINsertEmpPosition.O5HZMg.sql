CREATE PROCEDURE SkalNewINsertEmpPosition
@F varchar(20),
@L varchar(20),
@B Date,
@PosName varchar(50),
@Begin Date,
@End Date
AS
DECLARE @E_ID INT, @P_ID INT
SET @P_ID = (SELECT PositionID
    FROM tblPOSITION
    WHERE PositionName = @PosName)
--error – handling will go here
BEGIN TRAN G1
INSERT INTO tblEMPLOYEE (EmpFname, EmpLname, EmpBirthDate)
VALUES (@F, @L, @B)

SET @E_ID = (SELECT Scope_Identity()) -- Whatever is supposed to be the input is Scope_Identity
--error – handling will go here

INSERT INTO tblEMPLOYEE_POSITION (EmpID, PositionID, BeginDate, EndDate)
VALUES (@E_ID, @P_ID, @Begin, @End)
--error – handling will go here
IF @@ERROR <> 0
                BEGIN

                                --PRINT ‘ error up ahead…somewhere…fail now! ’

                                ROLLBACK TRAN G1

                END
ELSE

                COMMIT TRAN G1
go

