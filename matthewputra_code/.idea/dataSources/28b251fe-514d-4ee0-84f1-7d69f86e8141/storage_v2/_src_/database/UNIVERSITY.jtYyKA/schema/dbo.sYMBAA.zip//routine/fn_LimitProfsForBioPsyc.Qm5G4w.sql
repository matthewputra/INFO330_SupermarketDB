CREATE FUNCTION fn_LimitProfsForBioPsyc()
RETURNS INTEGER
AS
BEGIN
    DECLARE @Ret INTEGER
    IF EXISTS (SELECT *
        FROM tblINSTRUCTOR_TYPE tIT
            JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE tIIT ON tIT.InstructorTypeID = tIIT.InstructorTypeID
            JOIN tblINSTRUCTOR tI ON tIIT.InstructorID = tI.InstructorID
            JOIN tblINSTRUCTOR_CLASS tIC ON tI.InstructorID = tIC.InstructorID
            JOIN tblCLASS tC ON tIC.ClassID = tC.ClassID
            JOIN tblCOURSE tCS ON tC.CourseID = tCS.CourseID
            JOIN tblDEPARTMENT tD ON tCS.DeptID = tD.DeptID
            JOIN tblQUARTER tQ ON tC.QuarterID = tQ.QuarterID
        WHERE tIT.InstructorTypeName = 'Assistant Professor'
        OR tIT.InstructorTypeName = 'Associate Professor'
        AND tCS.CourseName LIKE '%4__'
        AND tD.DeptName = 'Biology'
        OR tD.DeptName = 'Philosophy'
        AND tQ.QuarterName = 'Summer'
        )
    SET @Ret = 1
    RETURN @Ret
END
go

