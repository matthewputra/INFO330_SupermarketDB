CREATE FUNCTION dbo.NoRegisFee495forWA()
RETURNS INT 
AS 
BEGIN 
	DECLARE @RET INT = 0
		IF EXISTS(SELECT *
			FROM tblSTUDENT S
				JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
				JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
			WHERE S.StudentPermState = 'Washington, WA'
			AND CL.RegistrationFee > 495)

	SET @RET = 1
RETURN @RET
END
go

