/* Please write the SQL to create a stored procedure that UPDATEs the EndDate for a row in 
STAFF_POSITION explicit transaction */
CREATE PROCEDURE uspEEBEndStaff
@Fname VARCHAR(50),
@Lname VARCHAR(50),
@Birth DATE,
@PosName VARCHAR(50),
@DepName VARCHAR(50),
@EndDate DATE
AS
DECLARE @S_ID INT, @P_ID INT, @D_ID INT
SET @S_ID = (SELECT StaffID
			 FROM tblSTAFF
			 WHERE StaffFName = @Fname
			 AND StaffLName = @Lname
			 AND StaffBirth = @Birth)
SET @P_ID = (SELECT PositionID
			 FROM tblPOSITION
			 WHERE PositionName = @PosName)
SET @D_ID = (SELECT DeptID
			 FROM tblDEPARTMENT
			 WHERE DeptName = @DepName)
BEGIN TRAN G1
UPDATE tblSTAFF_POSITION
SET EndDate = @EndDate
WHERE StaffID = @S_ID
AND PositionID = @P_ID
AND DeptID = @D_ID
COMMIT TRAN G1
go

