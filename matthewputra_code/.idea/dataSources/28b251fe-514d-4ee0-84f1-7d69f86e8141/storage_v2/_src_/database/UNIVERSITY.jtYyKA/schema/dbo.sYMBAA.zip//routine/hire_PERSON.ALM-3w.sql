CREATE PROCEDURE hire_PERSON
@StaffFName varchar(30),
@StaffLName varchar(30),
@PositionName varchar(30)
AS

DECLARE @S_ID INT
DECLARE @P_ID INT

SET @S_ID = (SELECT StaffID FROM tblSTAFF WHERE StaffFName = @StaffFName AND StaffLName = @StaffLName)
SET @P_ID = (SELECT PositionID FROM tblPOSITION WHERE PositionName = @PositionName)

go

