CREATE FUNCTION fn_No23AlaskaTripleDorm()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF EXISTS (SELECT S.StudentID
        FROM tblSTUDENT S
            JOIN tblSTUDENT_DORMROOM SD on S.StudentID = SD.StudentID
            JOIN tblDORMROOM D on SD.DormRoomID = D.DormRoomID
            JOIN tblDORMROOM_TYPE DT on D.DormRoomTypeID = DT.DormRoomTypeID
            JOIN tblBUILDING B on D.BuildingID = B.BuildingID
            JOIN tblLOCATION L on B.LocationID = L.LocationID
        WHERE S.StudentPermState LIKE '%Alaska%'
        AND DT.DormRoomTypeName LIKE '%Triple%'
        AND L.LocationName LIKE '%West%'
        AND S.StudentBirth > DateAdd(YEAR, -23, GetDate())
        GROUP BY S.StudentID)
    SET @RET = 1
RETURN @RET
END
go

