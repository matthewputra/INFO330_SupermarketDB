CREATE PROCEDURE uspNEWCLASS_LIST
@Course varchar(50),
@Quarter varchar(20),
@Year char(4),
@Section char(4),
@Fname varchar(20),
@Lname varchar (20),
@Bdate Date,
@RegDate Date,
@RegFee Numeric (6,2)

AS

Declare @ClassID INT, @StudentID INT

SET @ClassID = (
SELECT ClassID
FROM tblCLASS CS
JOIN tblQUARTER QU
ON QU.QuarterID = CS.QuarterID
JOIN tblCOURSE CR
ON CS.CourseID = CR.CourseID
WHERE QU.QuarterName = @Quarter
AND CR.CourseName = @Course
AND CS.YEAR = @Year
AND CS.SECTION = @Section)

SET @StudentID = (
SELECT CL.StudentID
FROM tblCLASS_LIST CL
JOIN tblSTUDENT ST
ON ST.StudentID = CL.StudentID
WHERE ST.StudentFname = @Fname
AND ST.StudentLname = @Lname
AND ST.StudentBirth = @Bdate
AND CL.RegistrationDate = @RegDate
AND CL.RegistrationFee = @RegFee)

INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@ClassID, @StudentID, NULL, @RegDate, @RegFee)
go

