
CREATE PROCEDURE uspUpdateStaffPosEndDate
@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@PosName varchar(50),
@DeptName varchar(50),
@ColName varchar(50),
@Begin Date,
@NewEnd Date
AS
DECLARE @S_ID INT, @P_ID INT, @D_ID INT

SET @S_ID = (
SELECT StaffID
FROM tblSTAFF
WHERE StaffFName = @Fname
AND StaffLName = @Lname
AND StaffBirth = @Birth
)

SET @P_ID = (
SELECT PositionID
FROM tblPOSITION
WHERE PositionName = @PosName
)

SET @D_ID = (
SELECT D.DeptID
FROM tblDEPARTMENT D
	JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
WHERE DeptName = @DeptName
AND C.CollegeName = @ColName
)

BEGIN TRAN G1
UPDATE tblSTAFF_POSITION
SET EndDate = @NewEnd
WHERE StaffID = @S_ID
AND PositionID = @P_ID
AND DeptID = @D_ID
AND BeginDate = @Begin
COMMIT TRAN G1
go

