CREATE FUNCTION dbo.apeng_CalcTotalCreds(@PK INT) --We need a parameter here to hold placeholder PK values
RETURNS INT --Numeric: 
AS
BEGIN
	DECLARE @Ret INT = (
		SELECT SUM(cr.Credits)--No default value since we are calculating it
		FROM tblSTUDENT s
		JOIN tblCLASS_LIST cl ON s.StudentID = cl.StudentID
		JOIN tblCLASS cs ON cl.ClassID = cs.ClassID
		JOIN tblCOURSE cr ON cs.CourseID = cr.CourseID
		JOIN tblDEPARTMENT d ON cr.DeptID = d.DeptID
		JOIN tblCOLLEGE c ON d.CollegeID = c.CollegeID
		JOIN tblCLASSROOM cm ON cs.ClassroomID = cm.ClassroomID
		JOIN tblBUILDING bd ON cm.BuildingID = bd.BuildingID
		JOIN tblLOCATION l ON bd.LocationID = l.LocationID
		WHERE c.CollegeName = 'Arts and Sciences' AND
		cl.Grade >= 3.4 AND
		l.LocationName LIKE '%Quad&' AND
		cs.YEAR > '2000' AND
		s.StudentID = @PK)
RETURn @Ret
End
go

