CREATE FUNCTION fn_CalcTotalRegFeesYTD1(@PK INT)
RETURNS numeric(8,2)
AS
BEGIN
    DECLARE @RET numeric(8,2) = (
        SELECT SUM(RegistrationFee)
        FROM tblCLASS_LIST CT
            JOIN tblCLASS CS ON CT.ClassID = CS.ClassID
            JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
            JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
            JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
        WHERE C.CollegeName = @PK
        AND YEAR(RegistrationDate) = YEAR(GETDATE()))
RETURN @RET
END
go

