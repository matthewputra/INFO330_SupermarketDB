CREATE PROCEDURE ssmith_FireStaff
	@DepName varchar(75),
	@Fname varchar(60),
	@Lname varchar(60),
	@Birth date,
	@NetID varchar(20),
	@PosName varchar(50),
	@End date
AS
	DECLARE @S_ID INT, @P_ID INT, @D_ID INT
		SET @S_ID = (SELECT StaffID FROM tblSTAFF
						WHERE StaffFName = @Fname
						AND StaffLName = @Lname
						AND StaffBirth = @Birth
						AND StaffNetID = @NetID)
		SET @P_ID = (SELECT PositionID FROM tblPOSITION
						WHERE PositionName = @PosName)
		SET @D_ID = (SELECT DeptID FROM tblDEPARTMENT
						WHERE DeptName = @DepName)
BEGIN TRAN S1
	UPDATE tblSTAFF_POSITION
		SET EndDate = @End
			WHERE DeptID = @D_ID
			AND PositionID = @P_ID
			AND StaffID = @S_ID
COMMIT TRAN S1
go

