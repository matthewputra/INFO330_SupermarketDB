CREATE PROCEDURE IA_INSERT_Registration
@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@RegFee Numeric(10,2), 
@RegDate Date,
@Grade Numeric(2,1) = NULL,
@CourseName varchar(75),
@Year char(4),
@Section Varchar(4),
@Quarter varchar(30)

AS

DECLARE @C_ID INT
DECLARE @S_ID INT

SET @C_ID = (SELECT ClassID
			FROM tblCLASS C
				JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
				JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
			WHERE Q.QuarterName = @Quarter
			AND CR.CourseName = @CourseName
			AND C.[YEAR] = @Year
			AND C.Section = @Section)

SET @S_ID = (SELECT STudentID
			FROM tblSTUDENT
			WHERE StudentFname = @Fname
			AND StudentLname = @Lname
			AND StudentBirth = @Birth)


INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, @Grade, @RegDate, @RegFee)
go

