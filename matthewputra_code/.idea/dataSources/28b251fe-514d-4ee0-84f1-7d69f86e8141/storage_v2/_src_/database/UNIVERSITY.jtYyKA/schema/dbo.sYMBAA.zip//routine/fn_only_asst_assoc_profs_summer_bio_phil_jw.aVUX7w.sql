CREATE FUNCTION fn_only_asst_assoc_profs_summer_bio_phil_jw()
RETURNS INTEGER
AS
BEGIN
	DECLARE @RET INTEGER = 0
	IF EXISTS(
			  SELECT COUNT(*) AS NumAsstAssocProfs
			  FROM tblINSTRUCTOR_TYPE IT
				  JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON IT.InstructorTypeID = IIT.InstructorTypeID
				  JOIN tblINSTRUCTOR I ON IIT.InstructorID = I.InstructorID
				  JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID = IC.InstructorID
				  JOIN tblCLASS C ON IC.ClassID = C.ClassID
				  JOIN tblQuarter Q on C.QuarterID = Q.QuarterID
				  JOIN tblCOURSE CS ON C.CourseID = CS.CourseID
				  JOIN tblDEPARTMENT D on CS.DeptID = D.DeptID
			  WHERE IT.InstructorTypeName NOT IN ('Assistant Professor', 'Associate Professor')
				  AND D.DeptName LIKE '%Biology%' OR D.DeptName LIKE '%Philosophy%'
				  AND CS.CourseNumber BETWEEN 400 and 499
				  AND Q.QuarterName = 'Summer'
			  GROUP BY C.ClassID
				)
	SET @RET = 1
RETURN @RET
END
go

