CREATE FUNCTION fn_TasksPerEmployee(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = (
        SELECT COUNT(TaskName) AS TotalTasksPast2HalfYears -- or should I do TaskID???
        FROM tblEMPLOYEE E
            JOIN tblEMPLOYEE_SKILL ES ON E.EmpID = ES.EmpID
            JOIN tblCUST_JOB_TASK CJT ON ES.EmpSkillID = CJT.EmpSkillID
            JOIN tblTASK T ON CJT.TaskID = T.TaskID
        WHERE EmpID = @PK
        AND BeginDate > (GETDATE() - (365.25*2.5))
        GROUP BY EmpID
        )
RETURN @RET
END
go

