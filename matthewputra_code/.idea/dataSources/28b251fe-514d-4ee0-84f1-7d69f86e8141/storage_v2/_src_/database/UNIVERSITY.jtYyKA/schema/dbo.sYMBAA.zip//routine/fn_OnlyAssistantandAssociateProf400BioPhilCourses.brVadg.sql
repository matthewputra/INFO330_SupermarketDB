CREATE FUNCTION fn_OnlyAssistantandAssociateProf400BioPhilCourses()
RETURNS INT
AS
    BEGIN
        DECLARE @Ret INT = 0
        IF EXISTS(SELECT * FROM tblDEPARTMENT D
            JOIN tblCOURSE ON D.DeptID = tblCOURSE.DeptID
            JOIN tblCLASS t on tblCOURSE.CourseID = t.CourseID
            JOIN tblQUARTER Q ON t.QuarterID = Q.QuarterID
            JOIN tblINSTRUCTOR_CLASS tIC on t.ClassID = tIC.ClassID
            JOIN tblINSTRUCTOR tI on tIC.InstructorID = tI.InstructorID
            JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE tIIT on tI.InstructorID = tIIT.InstructorID
            JOIN tblINSTRUCTOR_TYPE tIT on tIIT.InstructorTypeID = tIT.InstructorTypeID
            WHERE CourseNumber LIKE '4%'
            AND (DeptName = 'Biology' OR DeptName = 'Philosophy')
            AND QuarterName = 'Summer'
            AND tIT.InstructorTypeName not in ( 'Assistant Professor','Associate Professor' ))
        BEGIN
            SET @Ret = 1
        end
        RETURN @Ret
    end
go

