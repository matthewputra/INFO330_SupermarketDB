CREATE PROCEDURE uspERNewClass
@quarter varchar(20),
@course varchar(50),
@year INT,
@scheduleName varchar(30),
@section varchar(3),
@classroom varchar(30)
AS
DECLARE @courseID INT, @quarterID INT, @classroomID INT, @scheduleID INT

SET @courseID = (
	SELECT CourseID
	FROM tblCOURSE C
	WHERE C.CourseName = @course
)

SET @quarterID = (
	SELECT QuarterID
	FROM tblQUARTER Q
	WHERE Q.QuarterName = @quarter
)

SET @classroomID = (
	SELECT ClassroomID
	FROM tblCLASSROOM CL
	WHERE CL.ClassroomName = @classroom
)

SET @scheduleID = (
	SELECT ScheduleID
	FROM tblSCHEDULE S
	WHERE S.ScheduleName = @scheduleName
)

BEGIN TRAN E1
INSERT INTO tblCLASS(CourseID, QuarterID, YEAR, ClassroomID, ScheduleID, Section)
VALUES(@courseID, @quarterID, @year, @classroomID, @scheduleID, @section)
COMMIT TRAN E1
go

