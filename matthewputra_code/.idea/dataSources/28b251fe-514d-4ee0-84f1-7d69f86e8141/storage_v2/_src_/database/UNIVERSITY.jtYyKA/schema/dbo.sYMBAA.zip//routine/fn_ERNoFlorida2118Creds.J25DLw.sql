CREATE FUNCTION fn_ERNoFlorida2118Creds()
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (
		SELECT S.StudentID
		FROM tblSTUDENT S
			JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
			JOIN tblCLASS C ON C.ClassID = CL.ClassID
			JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
		WHERE S.StudentPermState = 'Florida, FL'
		AND StudentBirth > DateAdd(Year, -21, GetDate())
		AND RegistrationDate > DateAdd(Month, -4, GetDate())
		GROUP BY S.StudentID
		HAVING SUM(CR.Credits) > 18
	)
	SET @Ret =	1
RETURN @Ret
END

go

