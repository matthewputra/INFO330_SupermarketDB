CREATE FUNCTION  ml_noAssistProf500GeogSummer()
 returns INTEGER -- usually INTERGER
 AS
     BEGIN
         DECLARE @Ret INT=0--matches what the function is expected to return, assume no violation,
         -- if we find violation, the return value will change +1
         IF EXISTS(SELECT * FROM tblINSTRUCTOR I JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT
             ON I.InstructorID = IIT.InstructorID JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID = IT.InstructorTypeID
             JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID = IC.InstructorID
             JOIN tblCLASS C ON IC.ClassID = C.ClassID
             JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
             JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
             JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
             WHERE IT.InstructorTypeName='Assistant Professor'
             AND Q.QuarterName='Summer'
             AND C.[YEAR]='2018'
             AND D.DeptName='Geography'--Course name is not consistent
             AND CR.CourseNumber like '5%')--logic goes here
         SET @Ret=1
     RETURN @Ret
     end
go

