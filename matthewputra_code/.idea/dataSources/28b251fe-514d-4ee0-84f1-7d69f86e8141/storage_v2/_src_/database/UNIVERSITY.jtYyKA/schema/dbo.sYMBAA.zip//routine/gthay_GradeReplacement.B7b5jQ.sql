CREATE PROCEDURE gthay_GradeReplacement
@F varchar(30),
@L varchar(30),
@Birth Date,
@Quarter varchar(30),
@Year char(4),
@Course varchar(50),
@Section char(3),
@NewGrade decimal (3,2)
AS

DECLARE @S_ID INT, @C_ID INT

SET @S_ID = (SELECT StudentID 
			FROM tblSTUDENT 
			WHERE StudentFname = @F 
			AND StudentLname = @L 
			AND StudentBirth = @Birth)
IF @S_ID IS NULL
	BEGIN
		PRINT '@S_ID could not be found';
		THROW 546654, '@S_ID cannot be NULL', 1;
	END


SET @C_ID = (SELECT ClassID
			FROM tblCLASS C
				JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
				JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
			WHERE C.[Year] = @Year
			AND Q.QuarterName = @Quarter
			AND CR.CourseName = @Course
			AND C.Section = @Section)
IF @C_ID IS NULL
	BEGIN
		PRINT '@C_ID could not be found';
		THROW 546654, '@C_ID cannot be NULL', 1;
	END

BEGIN TRAN H1
UPDATE tblCLASS_LIST
SET Grade = @NewGrade
WHERE CLassID = @C_ID
AND StudentID = @S_ID
IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN H1
	END
ELSE 
	COMMIT TRAN H1

go

