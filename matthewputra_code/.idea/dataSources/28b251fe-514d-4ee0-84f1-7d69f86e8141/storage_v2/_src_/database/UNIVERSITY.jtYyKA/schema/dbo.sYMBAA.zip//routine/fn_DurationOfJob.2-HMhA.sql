
CREATE FUNCTION fn_DurationOfJob(@PK INT)
RETURNS NUMERIC(4,1)
AS
BEGIN
	DECLARE @RET NUMERIC(4,1) = (SELECT DateDiff(Day, SP.BeginDate, GetDate()) /365.25
								FROM tblSTAFF S
									JOIN tblSTAFF_POSITION SP ON S.StaffID = SP.StaffID
								WHERE EndDate IS NULL
								AND SP.StaffPositionID = @PK)
	RETURN @RET
END

go

