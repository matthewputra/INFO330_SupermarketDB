CREATE PROCEDURE SK_UpdateClassListforGradeReplacement
    @StudentFname varchar(60),
    @StudentLname varchar(60),
    @StudentBirth date,
    @Quarter varchar(30),
    @Year char(4),
    @Course varchar(50),
    @Section char(3),
    @NewGrade decimal(3,2)
AS
    DECLARE @S_ID INT, @C_ID INT

SET @S_ID = (SELECT StudentID FROM tblSTUDENT
                    WHERE StudentFname = @StudentFname
                    AND StudentLname = @StudentLname
                    AND StudentBirth = @StudentBirth)

        IF @S_ID IS NULL
        BEGIN
                PRINT '@S_ID could not be found';
                THROW 546654, '@S_ID cannot be NULL', 1;
        END

SET @C_ID = (SELECT ClassID FROM tblCLASS C
                    JOIN tblCOURSE CR on C.CourseID = CR.CourseID
                    JOIN tblQUARTER Q on C.QuarterID = Q.QuarterID
                    WHERE C.[YEAR] = @Year
                    AND Q.QuarterName = @Quarter
                    AND CR.CourseName = @Course
                    AND C.Section = @Section)
    IF @C_ID IS NULL
        BEGIN
                PRINT '@C_ID could not be found';
                THROW 546654, '@C_ID cannot be NULL', 1;
        END


    BEGIN TRAN S
UPDATE tblCLASS_LIST
SET Grade = @NewGrade
WHERE ClassID = @C_ID
AND StudentID = @S_ID
     IF @@ERROR <> 0
        BEGIN
            ROLLBACK TRAN S
        END
ELSE
COMMIT TRAN S
go

