CREATE FUNCTION fn_InfoCredOver34(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT =
		(SELECT SUM(CR.Credits)
		FROM tblCOLLEGE C
			JOIN tblDEPARTMENT D ON C.CollegeID = D.CollegeID
			JOIN tblCOURSE CR ON D.DeptID = CR.DeptID
			JOIN tblCLASS CS ON CR.CourseID = CS.CourseID
			JOIN tblCLASS_LIST CL ON CS.ClassID = CL.ClassID
			JOIN tblSTUDENT S ON CL.StudentID = S.StudentID
		WHERE C.CollegeName = 'Information School'
		AND CL.Grade > 3.4
		AND S.StudentID = @PK
		)
RETURN @RET
END
go

