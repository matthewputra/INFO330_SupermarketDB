CREATE PROCEDURE jessy_INSERT_tblCLASS_LIST
@LName varchar(30),
@FName varchar(30),
@BirthDate date,
@CourName varchar(30),
@SchedName varchar(30),
@RoomName varchar(30),
@Sections varchar(30),
@Year INT,
@QuatName varchar(30),
@Grades FLOAT,
@RegisDate date,
@RegisFee INT

AS

DECLARE @CourID INT, @QuatID INT, @RoomID INT, @SchedID INT, @ClaID INT, @StudID INT
SET @CourID = (select CourseID from tblCOURSE where CourseName = @CourName)
SET @QuatID = (select QuarterID from tblQuarter where QuarterName = @QuatName)
SET @RoomID = (select ClassroomID from tblCLASSROOM where ClassroomName = @RoomName)
SET @SchedID = (select ScheduleID from tblSCHEDULE where ScheduleName = @SchedName)
SET @ClaID  = (select ClassID from tblCLASS where CourseID = @CourID
											and QuarterID = @QuatID
											and [YEAR] = @Year
											and ClassroomID = @RoomID
											and ScheduleID = @SchedID
											and Section = @Sections)
SET @StudID = (select StudentID from tblSTUDENT where StudentFname = @FName
												and StudentLname = @LName
												and StudentBirth = @BirthDate)

INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES(@ClaID, @StudID, @Grades, @RegisDate, @RegisFee)
go

