CREATE FUNCTION fn_StudentWAMaxFee495()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF
    EXISTS(
        SELECT S.StudentID, COUNT(CL.RegistrationFee)
        FROM tblSTUDENT S
            JOIN tblCLASS_LIST CL on S.StudentID = CL.StudentID
            JOIN tblCLASS CS on CL.ClassID = CS.ClassID
            JOIN tblCOURSE CR on CS.CourseID = CR.CourseID
        WHERE S.StudentPermState = 'Washington, WA'
        GROUP BY S.StudentID
        HAVING COUNT(CL.RegistrationFee) > 495
        )
    SET @RET = 1
    RETURN @RET
    END
go

