CREATE PROCEDURE ym68_NewStaffPosition
@Firsty varchar(60),
@Lasty varchar(60),
@Birthy Date,
@DeptName varchar(75),
@PositionName varchar(50),
@Begin Date,
@End Date
AS

DECLARE @S_ID INT, @D_ID INT, @P_ID INT

EXEC ym_GetStaffID
@Firsty = @Firsty,
@Lasty = @Lasty,
@Birthy = @Birthy,
@Staffy = @S_ID OUTPUT

-- error-handle in case @S_ID IS NULL
 IF @S_ID IS NULL
	BEGIN
		PRINT 'Hey...@S_ID is NULL and the following transaction will fail'
		RAISERROR ('@S_ID cannot be NULL', 11, 1)
		RETURN
	END

SET @D_ID = (SELECT DeptID 
			FROM tblDEPARTMENT 
			WHERE DeptName = @DeptName)
-- error-handle in case @D_ID IS NULL

SET @P_ID = (SELECT PositionID 
			FROM tblPOSITION 
			WHERE PositionName = @PositionName)
-- error-handle in case @P_ID IS NULL


--create explicit transaction
BEGIN TRAN G1
PRINT 'Beginning transaction'
INSERT INTO tblSTAFF_POSITION (StaffID, DeptID, PositionID, BeginDate, EndDate)
VALUES (@S_ID, @D_ID, @P_ID, @Begin, @End)
-- check if there is a train wreck ahead-->
if @@ERROR <> 0
	ROLLBACK TRAN G1
ELSE
	COMMIT TRAN G1
go

