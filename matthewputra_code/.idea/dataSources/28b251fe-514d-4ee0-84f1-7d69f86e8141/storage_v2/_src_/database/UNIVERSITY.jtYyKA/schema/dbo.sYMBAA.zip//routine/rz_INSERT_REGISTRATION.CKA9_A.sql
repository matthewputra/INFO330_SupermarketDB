CREATE PROCEDURE rz_INSERT_REGISTRATION

@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@RegFee Numeric(10,2),
@RegDate Date,
@CourseName varchar(75),
@year char(4),
@Section Varchar(4),
@Quarter varchar(30),
@Grade Numeric(2,1) = Null

AS

DECLARE @C_ID INT
DECLARE @S_ID INT

SET @C_ID = (SELECT ClassID 
			from tblCLASS Cl
			JOIN tblQUARTER Q ON Cl.QuarterID = q.QuarterID
			JOIN tblCOURSE CR ON Cl.CourseID = CR.CourseID
			WHERE Q.QuarterName = @Quarter
			AND CR.CourseName = @CourseName
			AND Cl.[Year] = @year
			AND cl.Section = @Section)

SET @S_ID = (SELECT StudentID 
			From tblSTUDENT
			WHERE StudentFname = @Fname 
			AND StudentLname = @Lname
			AND StudentBirth = @Birth)


INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, @Grade, @RegDate, @RegFee)
go

