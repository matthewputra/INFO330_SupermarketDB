/* Business rule extra credit: "Students with a permanent state of 'Washington, WA' has a maximum fee of $495 per class"  */

CREATE FUNCTION fn_No495FeeInWA()
RETURNS INT
AS
BEGIN

DECLARE @Ret INT = 0
IF EXISTS ( -- sql code select whichever violates the logic
		   select *
		   from tblSTUDENT S
			   JOIN tblCLASS_LIST CL ON CL.StudentID = S.StudentID
			where S.StudentPermState = 'Washington, WA'
			AND CL.RegistrationFee > 495)
	BEGIN
		SET @Ret = 1
	END
RETURN @RET
END
go

