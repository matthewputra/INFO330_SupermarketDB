CREATE PROCEDURE melhenry_FindCourseID
@CRName VARCHAR (75)
AS
DECLARE @CRID INT

SET @CRID = (SELECT CourseID
                FROM tblCOURSE
                WHERE CourseName = @CRName)
go

