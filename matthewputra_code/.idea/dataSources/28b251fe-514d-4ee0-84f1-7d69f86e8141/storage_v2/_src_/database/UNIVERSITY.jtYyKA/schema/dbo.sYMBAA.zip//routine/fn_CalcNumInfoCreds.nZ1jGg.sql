CREATE FUNCTION fn_CalcNumInfoCreds(@PK INT)
RETURNS INT
AS
BEGIN 
	DECLARE @RET INT = 
	(SELECT COUNT(CR.Credits)
	FROM tblSTUDENT S
		JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
		JOIN tblCLASS C ON CL.ClassID = C.ClassID
		JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
		JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
		JOIN tblCOLLEGE CO ON D.CollegeID = CO.CollegeID
	WHERE S.StudentID = @PK
	AND CL.Grade > 3.4
	AND CO.CollegeName = 'Informatics')

RETURN @RET
END
go

