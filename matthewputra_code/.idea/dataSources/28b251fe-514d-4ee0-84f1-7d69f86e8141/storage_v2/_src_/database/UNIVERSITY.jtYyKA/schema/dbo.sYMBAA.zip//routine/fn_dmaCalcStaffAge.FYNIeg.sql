CREATE FUNCTION fn_dmaCalcStaffAge(@PK INT)
RETURNS Numeric(3,1)
AS
BEGIN
	DECLARE @RET Numeric(3,1) =
		(SELECT DATEDIFF(Day, StaffBirth, GetDate()) / 365.25
		FROM tblStaff
		WHERE StaffID = @PK)

	RETURN @RET
END
go

