CREATE VIEW vSeven_per_students AS
SELECT TOP 7 S.StudentID, StudentFname, StudentLname, AVG(CL.Grade) AS AvgGrade
FROM tblCollege COL
JOIN tblDEPARTMENT D ON D.CollegeID = COL.CollegeID
JOIN tblCOURSE CO ON CO.DeptID = D.DeptID
JOIN tblCLASS C ON C.CourseID = CO.CourseID
JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
JOIN tblCLASS_LIST CL ON CL.ClassID = C.ClassID
JOIN tblSTUDENT S ON S.StudentID = CL.StudentID
WHERE C.[YEAR] = 2011
AND C.[YEAR] = 2014
AND COL.CollegeName LIKE '%Medicine%'
GROUP BY S.StudentID, StudentFname, StudentLname
ORDER BY AVG(CL.Grade)

go

