CREATE FUNCTION TotalRegistrFee(@PK NUMERIC)
RETURNS NUMERIC (20,2)
AS
BEGIN
    DECLARE @Ret NUMERIC (20,2) = (SELECT SUM(CL.RegistrationFee)
                        FROM tblCLASS_LIST CL
                            JOIN tblCLASS CS on CL.ClassID = CS.ClassID
                            JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
                            JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
                            JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
                        WHERE DATEDIFF(year,CL.RegistrationDate,GETDATE()) <= 2
                        AND C.CollegeID=@PK  )
RETURN @Ret
end
go

