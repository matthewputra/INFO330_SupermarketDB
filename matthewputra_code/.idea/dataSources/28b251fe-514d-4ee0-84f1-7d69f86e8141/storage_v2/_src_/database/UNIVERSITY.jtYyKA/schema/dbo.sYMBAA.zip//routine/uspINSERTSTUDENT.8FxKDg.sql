CREATE PROCEDURE uspINSERTSTUDENT
@Fname varchar(20),
@Lname varchar(20),
@Birth Date,
@RDate Date,
@Year char(4),
@SName varchar(3)
AS
DECLARE @S_ID INT, @C_ID INT
SET @S_ID = (SELECT S.StudentID FROM tblSTUDENT S
	JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
	WHERE RegistrationDate = @RDate
	AND StudentFname = @Fname
	AND StudentLname = @Lname
	AND StudentBirth = @Birth)
SET @C_ID = (SELECT ClassID FROM tblCLASS C
	WHERE [YEAR] = @Year
	AND Section = @SName)

BEGIN TRAN J3
INSERT INTO tblCLASS_LIST (ClassID, StudentID, RegistrationDate)
Values (@S_ID, @C_ID, @RDate)
COMMIT TRAN J3
go

