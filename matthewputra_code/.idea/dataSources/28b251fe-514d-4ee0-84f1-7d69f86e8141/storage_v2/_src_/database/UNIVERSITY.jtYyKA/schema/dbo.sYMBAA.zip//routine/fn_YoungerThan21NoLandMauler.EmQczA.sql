CREATE FUNCTION fn_YoungerThan21NoLandMauler()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = 0
    -- need to look for where the rule is broken
    -- rule is broken when someone under 21 uses a land mauler
    IF EXISTS(
            SELECT TaskID -- if a task exists with the following conditions we need to restrict it
            FROM tblEMPLOYEE E
                JOIN tblEMPLOYEE_SKILL ES ON E.EmpID = ES.EmpID
                JOIN tblCUST_JOB_TASK CJT ON ES.EmpSkillID = CJT.EmpSkillID
                JOIN tblTASK T ON CJT.TaskID = T.TaskID
                JOIN tblTOOL TL ON CJT.ToolID = TL.ToolID
                JOIN tblTOOL_TYPE TT ON TL.ToolTypeID = TT.ToolTypeID
            WHERE ToolTypeName = 'Land Mauler'
            And EmpBirthDate > (GETDATE() - (365.25 * 21))
        )
    SET @Ret = 1
RETURN @Ret
END
go

