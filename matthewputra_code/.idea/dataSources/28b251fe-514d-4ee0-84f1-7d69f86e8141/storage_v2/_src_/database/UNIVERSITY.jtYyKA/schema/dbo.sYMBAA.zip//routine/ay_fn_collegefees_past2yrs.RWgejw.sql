CREATE FUNCTION ay_fn_collegefees_past2yrs(@PK INT)
RETURNS NUMERIC(20,2)
    AS
    BEGIN
        DECLARE @Ret numeric(20,2) = (SELECT SUM(CL.RegistrationFee) FROM tblCLASS_LIST CL
           JOIN tblCLASS C ON  C.ClassID = CL.ClassID
            JOIN tblCOURSE CR ON CR.CourseID = C.CourseID
            JOIN tblDEPARTMENT D ON D.DeptID = CR.DeptID
            JOIN tblCOLLEGE CO ON CO.CollegeID = D.CollegeID
            WHERE CL.RegistrationDate > DATEADD(YEAR, -2, GETDATE())
            AND CO.CollegeID = @PK )
    RETURN @Ret
    end
go

