CREATE PROCEDURE gthayInsertStudentSTatus
@First varchar(30),
@Last varchar(30),
@Birth Date,
@StatName varchar(50),
@Begin Date,
@End Date
AS
DECLARE @S_ID INT, @Stat_ID INT

SET @S_ID = (SELECT StudentID 
			FROM tblSTUDENT 
			WHERE StudentFname = @First 
			AND StudentLname = @Last 
			AND StudentBirth = @Birth)
SET @Stat_ID = (SELECT STatusID FROM tblSTATUS WHERE StatusName = @StatName)


INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate) 
VALUES (@S_ID, @Stat_ID, @Begin, @End)
go

