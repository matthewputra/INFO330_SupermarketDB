CREATE FUNCTION dbo.NoAlaskaTripleWestOver23()
RETURNS INT
AS
    BEGIN
        DECLARE @RET INT = 0
        IF EXISTS(SELECT *
FROM tblSTUDENT
JOIN tblSTUDENT_DORMROOM tSD on tblSTUDENT.StudentID = tSD.StudentID
JOIN tblDORMROOM tD on tSD.DormRoomID = tD.DormRoomID
JOIN tblDORMROOM_TYPE tDT on tD.DormRoomTypeID = tDT.DormRoomTypeID
JOIN tblBUILDING t on tD.BuildingID = t.BuildingID
JOIN tblLOCATION tL on t.LocationID = tL.LocationID
WHERE DormRoomTypeName = 'Triple'
AND LocationName = 'West Campus'
AND StudentBirth < (SELECT DateADD(year,-23,getdate())))
        BEGIN
            SET @RET = 1
        END
        Return @RET
        END
go

