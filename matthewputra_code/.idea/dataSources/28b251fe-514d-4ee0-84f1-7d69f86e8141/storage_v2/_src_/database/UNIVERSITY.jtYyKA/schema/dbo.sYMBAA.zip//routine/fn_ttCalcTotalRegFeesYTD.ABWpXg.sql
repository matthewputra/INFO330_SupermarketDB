CREATE FUNCTION fn_ttCalcTotalRegFeesYTD(@PK INT)
RETURNS numeric(18,2)
AS
BEGIN
	DECLARE @RET numeric(18,2) =	(SELECT SUM(CL.RegistrationFee)
	FROM tblCLASS_LIST CL
		JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
		JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
		JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
		JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
	WHERE C.CollegeID = @PK
	AND YEAR(RegistrationDate) = YEAR(GetDate()) -- will give 2020
	) --dont need group by because only running against one row while group by for multiple rows

RETURN @RET

END
go

