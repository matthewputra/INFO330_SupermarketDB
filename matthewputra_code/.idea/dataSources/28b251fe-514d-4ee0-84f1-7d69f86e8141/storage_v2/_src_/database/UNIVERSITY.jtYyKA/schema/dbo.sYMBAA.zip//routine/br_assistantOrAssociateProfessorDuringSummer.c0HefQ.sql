CREATE FUNCTION br_assistantOrAssociateProfessorDuringSummer()
RETURNS INTEGER
AS 
BEGIN 
	DECLARE @RET INTEGER = 0
	IF EXISTS(SELECT StaffID
				FROM tblPOSITION P 
					JOIN tblSTAFF_POSITION SP ON P.PositionID = SP.PositionID
					JOIN tblDEPARTMENT DP ON DP.DeptID = SP.DeptID
					JOIN tblCOURSE C ON DP.DeptID = C.DeptID
					JOIN tblCLASS CL ON C.CourseID = CL.CourseID
					JOIN tblQUARTER Q ON CL.QuarterID = Q.QuarterID
				WHERE QuarterName = 'Summer'
				AND CourseNumber LIKE '4__'
				AND DP.DeptName = 'Bilology' OR DP.DeptName = 'Philosophy'
				AND P.PositionName <> 'Assistant' 
				AND P.PositionName <> 'Associate Professor')
	BEGIN 
		SET @RET = 1
	END
RETURN @RET
END
go

