CREATE FUNCTION br_assistantOrAssociateProfessorDuringSummer()
RETURNS INTEGER
AS 
BEGIN 
	DECLARE @RET INTEGER = 0
	IF EXISTS(SELECT StaffID
				FROM tblPOSITION_TYPE PT 
					JOIN tblPOSITION P ON PT.PositionTypeID = P.PositionTypeID
					JOIN tblSTAFF_POSITION SP ON P.PositionID = SP.PositionID
					JOIN tblDEPARTMENT DP ON DP.DeptID = SP.DeptID
					JOIN tblCOURSE C ON DP.DeptID = C.DeptID
					JOIN tblCLASS CL ON C.CourseID = CL.CourseID
					JOIN tblQUARTER Q ON CL.QuarterID = Q.QuarterID
				WHERE QuarterName = 'Summer'
				AND CourseNumber LIKE '4__'
				AND DeptName = 'Bilology' OR DEPTNAME = 'Philosophy'
				AND PT.PositionTypeName <> 'Assistant' OR PT.PositionTypeName <> 'Associate Professor')
	BEGIN 
		SET @RET = 1
	END
RETURN @RET
END
go

