CREATE PROCEDURE dennyw_GetStaffID
@Fname VARCHAR(60),
@Lname VARCHAR(60),
@BDate DATE,
@Staffy INT OUTPUT
AS

SET @Staffy = (SELECT StaffID 
             FROM tblSTAFF 
             WHERE StaffFname = @Fname
             AND StaffLname = @Lname
             AND StaffBirth = @BDate)
go

