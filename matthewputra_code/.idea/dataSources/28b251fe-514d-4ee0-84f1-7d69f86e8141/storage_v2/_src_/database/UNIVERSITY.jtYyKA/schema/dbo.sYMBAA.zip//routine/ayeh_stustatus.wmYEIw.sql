CREATE PROCEDURE ayeh_stustatus
@staName varchar(50),
@stuFname varchar(50),
@stuLname varchar(50),
@stuBdate Date,
@Bgdate DATE,
@Edate DATE
AS
   DECLARE @stuID INT, @staID INT
    EXEC ayeh_GetStuID
    @studFname = @stuFname,
    @studLname = @stuLname,
    @studBdate= @stuBdate,
    @studID = @stuID OUTPUT

    IF @stuID IS NULL
        BEGIN
            PRINT '@stuID is null, check spelling of student names and bdate'
            RAISERROR ('@stuID cannot be null; terminating...', 11, 1)
            RETURN
        end

    EXEC ayeh_GetstaID
    @StatName = @staName,
@StatusID = @staID OUTPUT
        IF @staID IS NULL
        BEGIN
            PRINT '@staID is null, check spelling of status name input'
            RAISERROR ('@staID cannot be null; terminating...', 11, 1)
            RETURN
        end

BEGIN TRAN
INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate)
VALUES (@stuID, @staID, @Bgdate, @Edate)
IF @@ERROR <> 0
    BEGIN
        PRINT 'ERROR AT VERY END; ROLLING BACK TRAN'
        ROLLBACK TRAN
    end
ELSE
    COMMIT TRAN
go

