CREATE FUNCTION dbo.fn_NoAlaskaHaveTripleRoom()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF EXISTS (SELECT S.StudentID
               FROM tblSTUDENT S
                   JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
                   JOIN tblDORMROOM D ON SD.DormRoomID = D.DormRoomID
                   JOIN tblDORMROOM_TYPE DT ON D.DormRoomTypeID = DT.DormRoomTypeID
                   JOIN tblBUILDING B ON D.BuildingID = B.BuildingID
                   JOIN tblLOCATION L ON B.LocationID = L.LocationID
               WHERE S.StudentPermState = 'Alaska, AK'
               AND S.StudentBirth < DATEADD(Year, -23, GETDATE())
               AND DT.DormRoomTypeName = 'Triple'
               AND L.LocationName = 'West Campus')
    SET @RET = 1
RETURN @RET
END
go

