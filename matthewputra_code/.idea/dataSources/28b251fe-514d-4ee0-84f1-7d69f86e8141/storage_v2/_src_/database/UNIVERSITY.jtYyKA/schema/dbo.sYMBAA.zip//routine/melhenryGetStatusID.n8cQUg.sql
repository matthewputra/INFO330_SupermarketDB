CREATE PROCEDURE melhenryGetStatusID
@Stat_Name VARCHAR (50),
@StatID INT OUTPUT
AS
SET @StatID = (SELECT StatusID FROM tblSTATUS WHERE StatusName = @Stat_Name)
go

