CREATE FUNCTION tm_noAlcUnder21()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = 0
    IF EXISTS (
        SELECT *
        FROM CUSTOMER C
        JOIN ORDERS O on C.CustID = O.CustID
        JOIN PRODUCT P on O.ProdID = P.ProductID
        JOIN PRODUCT_TYPE PT on P.ProductTypeID = PT.ProductTypeID
        WHERE DATEDIFF(year, getDate(), C.DOB) < 21
        AND PT.ProductTypeName = 'Alcohol'
    )
    BEGIN
        SET @Ret = 1
    end
RETURN @Ret
END
go

