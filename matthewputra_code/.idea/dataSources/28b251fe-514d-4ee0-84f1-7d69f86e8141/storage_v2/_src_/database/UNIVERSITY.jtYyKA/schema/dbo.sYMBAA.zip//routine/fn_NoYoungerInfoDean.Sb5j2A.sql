CREATE FUNCTION fn_NoYoungerInfoDean()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS
	(
		SELECT *
		FROM tblSTAFF S
			JOIN tblSTAFF_POSITION SP ON S.StaffID = SP.StaffID
			JOIN tblPOSITION P ON P.PositionID = SP.PositionID
			JOIN tblPOSITION_TYPE PT ON P.PositionTypeID = PT.PositionTypeID
			JOIN tblDEPARTMENT D ON D.DeptID = SP.DeptID
			JOIN tblCOLLEGE C ON C.CollegeID = D.CollegeID
		WHERE C.COllegeName = 'Information School'
		AND S.StaffBirth > DateAdd(Year, -41, GetDate())
	)
	SET @RET = 1
RETURN @RET
END
go

