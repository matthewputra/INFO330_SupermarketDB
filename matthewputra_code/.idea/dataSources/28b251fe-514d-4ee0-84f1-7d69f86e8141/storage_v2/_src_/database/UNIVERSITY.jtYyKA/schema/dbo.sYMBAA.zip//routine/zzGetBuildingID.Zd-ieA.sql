CREATE PROCEDURE zzGetBuildingID
@Building varchar(50),
@BldgID INT OUTPUT
AS
SET @BldgID=(SELECT BuildingID FROM UNIVERSITY.dbo.tblBUILDING WHERE BuildingName=@Building)
go

