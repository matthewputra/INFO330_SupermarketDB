CREATE PROCEDURE apeng_GET_STUDENT_ID
@FName varchar(50),
@LName varchar(50),
@Birthday DATE,
@StuID INT OUTPUT
AS
SET @StuID = (SELECT StudentID FROM tblSTUDENT WHERE StudentBirth = @Birthday AND StudentFname = @FName AND StudentLname = @LName)
go

