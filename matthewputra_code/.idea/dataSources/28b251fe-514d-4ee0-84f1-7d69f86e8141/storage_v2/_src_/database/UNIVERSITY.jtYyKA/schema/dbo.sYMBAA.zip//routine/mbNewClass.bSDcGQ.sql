CREATE PROCEDURE mbNewClass
@CName varchar(20),
@QName varchar(20),
@year char(4),
@CRName varchar(20),
@Sname varchar(20),
@SBegin time,
@SEnd time,
@Section char(1)
AS
    DECLARE @C_ID INT, @Q_ID INT, @CR_ID INT, @S_ID INT
SET @C_ID = (SELECT CourseID FROM tblCOURSE
    WHERE CourseName = @CName)
SET @Q_ID = (SELECT QuarterID FROM tblQUARTER
    WHERE QuarterName = @QName)
SET @CR_ID = (SELECT ClassroomID FROM tblCLASSROOM
    WHERE ClassroomName = @CRName)
SET @S_ID = (SELECT ScheduleID FROM tblSCHEDULE
    WHERE ScheduleName = @Sname
    AND SchedBeginTime = @SBegin
    AND SchedEndTime = @SEnd)
INSERT INTO tblCLASS(CourseID, QuarterID, YEAR, ClassroomID, ScheduleID, Section)
VALUES (@C_ID, @Q_ID, @year, @CR_ID, @S_ID, @Section)
go

