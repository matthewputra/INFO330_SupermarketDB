CREATE PROC GetAccessID
@Subs_Name VARCHAR(50),
@AcType_Name VARCHAR(50),
@Rec_Name  VARCHAR(50),
@AcDateTime DATETIME,
@Access_ID  INT OUTPUT
AS
    SET @Access_ID = (SELECT AccessID
                      FROM   ACCESS  A
                        JOIN SUBSCRIPTION  S  ON  S.SubscriptionId = A.SubscriptionID
                        JOIN ACCESS_TYPE   AT ON  AT.AccessTypeID  = A.AccessTypeID
                        JOIN RECORDING     R  ON  R.RecordingID    = A.RecordingID
                      WHERE  S.SubscriptionName = @Subs_Name
                      AND    AT.AccessTypeName  = @AcType_Name
                      AND    R.RecordingName    = @Rec_Name
                      AND    A.AccessDateTime   = @AcDateTime
                )
go

