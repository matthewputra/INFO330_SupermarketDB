CREATE FUNCTION mb_NoFlorida2118Creds()
RETURNS varchar(50)
AS
BEGIN
    DECLARE @Ret varchar(50) = 0
    IF EXISTS (SELECT S.StudentID FROM tblSTUDENT S
        JOIN tblCLASS_LIST tCL on S.StudentID = tCL.StudentID
        JOIN tblCLASS tC on tCL.ClassID = tC.ClassID
        JOIN tblCOURSE t on tC.CourseID = t.CourseID
        JOIN tblQUARTER tQ on tC.QuarterID = tQ.QuarterID
    WHERE S.StudentPermState = 'Florida, FL'
    AND StudentBirth > DateAdd(year, -21, GetDate())
    AND RegistrationDate > DateAdd(month,-4,GetDate())
        GROUP BY S.StudentID
        HAVING SUM(Credits) > 18)
    SET @Ret = 1
    RETURN @Ret
END
go

