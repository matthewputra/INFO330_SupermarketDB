CREATE PROCEDURE uspINSERTInsOffice
@Fname varchar(20),
@Lname varchar(20),
@Birth Date,
@O_name varchar(30), -- Office Name
@BDate Date, -- Begin Date
@EDate Date -- End Date
AS
DECLARE @I_ID INT, @O_ID INT -- I_ID: Instructor ID
SET @I_ID = (SELECT InstructorID From tblINSTRUCTOR WHERE InstructorFname = @Fname
AND InstructorLname = @Lname
AND InstructorBirth = @Birth)
SET @O_ID = (SELECT OfficeID From tblOffice WHERE OfficeName = @O_name)

BEGIN TRAN G1 -- Naming an explicit Transcation, has to begin with a letter
INSERT INTO tblInstructor_Office (InstructorID, OfficeID, BeginDate, EndDate)
Values(@I_ID, @O_ID, @BDate, @EDate)
Commit TRAN G1
go

