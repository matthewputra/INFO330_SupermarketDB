CREATE FUNCTION fn_noOneUnder41DeaniSchool_sw()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
		IF EXISTS
		(
			SELECT *
				FROM tblCOLLEGE C
					JOIN tblDEPARTMENT D ON C.CollegeID = D.CollegeID
					JOIN tblSTAFF_POSITION SP ON D.DeptID = SP.DeptID
					JOIN tblPOSITION P ON SP.PositionID = P.PositionID
					JOIN tblSTAFF S ON SP.StaffID = S.StaffID
				WHERE C.CollegeName = 'Information School'
					AND S.StaffBirth > DateAdd(YEAR, -41, GetDate())
		)

		BEGIN
			SET @RET = 1;
		END

RETURN @RET
END
go

