
-- Computed Columns
-- Delivery time - EventDurationPerEventForDeliveredOrder (EndTime - BeginTime) WHERE EventStatus = Delivered

CREATE FUNCTION fnEventDurationPerEventForDeliveredOrder (@EventID INT)
RETURNS numeric(6,2)
AS
BEGIN
DECLARE @RET numeric(6,2) =
   	(SELECT E.EndDateTime - E.BeginDateTime 
       FROM tblEVENT E 
       JOIN tblEVENT_STATUS ES ON ES.EventID = E.EventID 
       JOIN tblSTATUS S ON S.StatusID = ES.StatusID
       WHERE E.EventID = @EventID
       AND S.StatusName = 'Delivered')
 
RETURN @RET
END
go

