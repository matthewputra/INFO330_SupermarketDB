
CREATE FUNCTION fn_ERNumInfoCredits(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 
	(
		SELECT SUM(CO.Credits)
		FROM tblSTUDENT S
			JOIN tblCLASS_LIST CL ON CL.StudentID = S.StudentID
			JOIN tblCLASS C ON CL.ClassID = C.ClassID
			JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
			JOIN tblDEPARTMENT D ON CO.DeptID = D.DeptID
			JOIN tblCOLLEGE COL ON D.CollegeID = COL.CollegeID
		WHERE COL.CollegeName = 'Information School'
		AND GRADE > 3.4
		AND S.StudentID = @PK
	)
RETURN @RET
END
go

