CREATE   PROCEDURE Registeration_Students_in_Class
@StudFName varchar(60),
@StudLName varchar(60),
@CrsName varchar(75),
@ScheduleName varchar(75),
@Quarter varchar(30),
@Classroom varchar(125),
@Section varchar(4),
@StudentDateOfBirth date,
@RegistrationDate date,
@RegistrationFees numeric(10,2)
AS
DECLARE @C_ID INT
SET @C_ID = (
				  Select C.ClassID from tblClass C
				  join tblCOURSE Co on Co.CourseID =C.CourseID
				  join tblSCHEDULE Sc on Sc.ScheduleID = C.ScheduleID
				  join tblCLASSROOM Cr on Cr.ClassroomID = C.ClassroomID
				  join tblQUARTER Q on Q.QuarterID = C.QuarterID
				  WHERE
				  Co.CourseName = '@CrsName'
				  and Sc.ScheduleName='@ScheduleName'
				  and Cr.ClassroomName ='@Classroom'
				  and C.Section='@Section'
				  and C.YEAR =YEAR(@RegistrationDate)
				  and Q.QuarterName='@Quarter'
              )
-- error-handling --> we know the entire procedure will fail at the transaction if this is NULL
IF @C_ID IS NULL
BEGIN
PRINT 'Error: Course does not exist!!'
RAISERROR ('@C_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END
DECLARE @S_ID INT
SET @S_ID = (SELECT ST.StudentID FROM tblSTUDENT ST WHERE ST.StudentFname= '@StudFName' and ST.StudentLname ='@StudLName' and ST.StudentBirth ='@StudentDateOfBirth' )
-- error-handling --> we know the entire procedure will fail at the transaction if this is NULL
IF @S_ID IS NULL
BEGIN
PRINT 'Error: Student does not exist!!'
RAISERROR ('@S_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END
BEGIN TRAN G1
INSERT INTO tblCLASS_LIST(ClassID,StudentID,RegistrationDate,RegistrationFee)
VALUES (@C_ID,@S_ID,@RegistrationDate,@RegistrationFees)
-- error-handling
IF @@ERROR <> 0
BEGIN
PRINT '@@ERROR is showing a number <> 0; transaction is being terminated'
ROLLBACK TRAN G1
END
ELSE
COMMIT TRAN G1
go

