CREATE PROCEDURE apengINSERT_INSTRUCTOR_CLASS

@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@Course varchar(50),
@Year char(4),
@Section char(3),
@Quarter varchar(30)
AS
DECLARE @InstrID INT --These are the required columns for tblInstructor_Class. Both are foreign keys/integers
DECLARE @ClassID INT --No values yet

SET @InstrID = (SELECT InstructorID FROM tblINSTRUCTOR WHERE InstructorFname = @Fname AND InstructorLName = @Lname AND InstructorBirth = @Birth) --This is the lookup function that populates the variables
SET @ClassID = (SELECT ClassID
FROM tblCLASS c
	JOIN tblCOURSE cr ON c.CourseID = cr.CourseID
	JOIN tblQUARTER q ON c.QuarterID = q.QuarterID
	AND cr.CourseName = @Course
	AND c.YEAR = @Year
	AND c.QuarterID = @Quarter
	AND c.Section = @Section)
INSERT INTO tblINSTRUCTOR_CLASS (InstructorID, ClassID)
VALUES (@InstrID, @ClassID)
go

