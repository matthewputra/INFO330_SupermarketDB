
CREATE PROCEDURE gthayINSERT_INSTRUCTOR_CLASS
@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@Course varchar(50),
@Year char(4),
@Quarter varchar(20),
@Section char(3)
AS
DECLARE @InstrID INT, @CLassID INT
SET @InstrID = (SELECT InstructorID FROM tblINSTRUCTOR WHERE InstructorFname = @Fname AND InstructorLname = @Lname
AND InstructorBirth = @Birth)

SET @CLassID = (SELECT ClassID  
			FROM tblCLASS C 
			JOIN tblCOURSE CR ON C.CourseID = CR.CourseID 
			JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
			AND CR.CourseName = @Course
			AND C.[Year] = @Year
			AND Q.QuarterName = @Quarter
			AND C.Section = @Section)
INSERT INTO tblINSTRUCTOR_CLASS (InstructorID, ClassID) -- these are the required columns in the table; both FK and INT
VALUES (@InstrID,@CLassID)
go

