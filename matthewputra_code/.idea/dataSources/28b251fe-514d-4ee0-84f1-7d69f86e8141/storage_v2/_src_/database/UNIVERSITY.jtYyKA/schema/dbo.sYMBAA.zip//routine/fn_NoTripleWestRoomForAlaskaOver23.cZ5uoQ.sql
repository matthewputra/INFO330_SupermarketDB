CREATE FUNCTION dbo.fn_NoTripleWestRoomForAlaskaOver23()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT=0
    IF EXISTS(SELECT *
          FROM tblSTUDENT S
               JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
               JOIN tblDORMROOM DR ON SD.DormRoomID = DR.DormRoomID
               JOIN tblDORMROOM_TYPE DT ON DR.DormRoomTypeID = DT.DormRoomTypeID
               JOIN tblBUILDING B ON DR.BuildingID = B.BuildingID
               JOIN tblLOCATION L ON B.LocationID = L.LocationID
          WHERE S.StudentBirth < (SELECT DATEADD(year, -23, GETDATE()))
            AND DT.DormRoomTypeName = 'Triple'
            AND S.StudentPermState = 'Alaska, AK'
            AND L.LocationName = 'West Campus'
        )
        BEGIN
            SET @RET = 1
        END
RETURN @RET
END
go

