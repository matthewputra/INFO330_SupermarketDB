-- Write the code to create a stored procedure to create a
-- new class of an existing course.
CREATE PROCEDURE uspClass
    @CourseName VARCHAR(75),
    @Quarter VARCHAR(30),
    @Year CHAR(4),
    @Classroom VARCHAR(125),
    @Schedule VARCHAR(75),
    @Section VARCHAR(4)
AS
DECLARE @CO_ID INT, @Q_ID INT, @CL_ID INT, @S_ID INT
SET @CO_ID = (SELECT C.CourseID FROM tblCOURSE AS C WHERE C.CourseName = @CourseName)
SET @Q_ID = (SELECT Q.QuarterID FROM tblQUARTER AS Q WHERE Q.QuarterName = @Quarter)
SET @CL_ID = (SELECT CL.ClassroomID FROM tblCLASSROOM AS CL WHERE CL.ClassroomName = @Classroom)
SET @S_ID = (SELECT S.ScheduleID FROM tblSCHEDULE AS S WHERE S.ScheduleName = @Schedule)
INSERT INTO tblCLASS(COURSEID, QUARTERID, YEAR, CLASSROOMID, SCHEDULEID, SECTION)
VALUES (@CO_ID, @Q_ID, @Year, @CL_ID, @S_ID, @Section);
go

