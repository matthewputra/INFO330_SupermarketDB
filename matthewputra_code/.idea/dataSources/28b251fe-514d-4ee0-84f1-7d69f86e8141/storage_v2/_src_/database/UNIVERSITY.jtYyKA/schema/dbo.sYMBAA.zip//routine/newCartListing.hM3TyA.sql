create proc newCartListing
@first varchar(125),
@last varchar(125),
@dob date
as
declare @C_ID int, @O_ID int, @order datetime
truncate table [copy]
exec getCustID
@Fname = @first,
@Lname = @last,
@Birth = @dob,
@CID = @C_ID output
if @C_ID = null
begin 
	print 'checks values for @first, @last, @dob';
	throw 51000, '@C_ID is null', 1; 
end
insert into tblORDER(CustID, OrderDate)
values(@C_ID, (select getdate()))
set @O_ID = SCOPE_IDENTITY()
set @order = (
	select O.OrderDate
	from tblORDER O
	where O.OrderID = @O_ID
)
insert into copy(CartID, CustID, ProductID, Quantity)
select CartID, CustID, ProductID, Quantity 
from tblCART
where CustID = @C_ID
declare @RUN int = (select count(*) from [copy])
declare @PK int, @prod int, @PN varchar(125), @q int, @cart int
while @RUN > 0
begin
	set @PK = (select min(CopyID) from [copy])
	set @cart = (select C.CartID from [copy] C where C.CopyID = @PK)
	set @prod = (select C.ProductID from [copy] C where C.CopyID = @PK)
	set @q = (select C.Quantity from [copy] C where C.CopyID = @PK)
	SET @PN = (select P.ProductName from tblPRODUCT P where P.ProductID = @prod)
	exec populateLineItem
	@CustFname = @first, 
	@CustLname = @last,
	@CustBirthDate = @dob,
	@ProductName = @PN,	
	@Quantity = @q,
	@orderDate = @order
	delete from [copy] 
	where CopyID = @PK
	delete from tblCART
	where CartID = @cart
	set @RUN = @RUN - 1
end
go

