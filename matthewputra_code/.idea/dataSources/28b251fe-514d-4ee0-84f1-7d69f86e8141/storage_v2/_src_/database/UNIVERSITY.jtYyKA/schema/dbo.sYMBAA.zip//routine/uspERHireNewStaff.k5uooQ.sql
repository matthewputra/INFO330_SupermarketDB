CREATE PROCEDURE uspERHireNewStaff
@fname varchar(20),
@lname varchar(20),
@address varchar(30),
@city varchar(30),
@state varchar(20),
@zip varchar(10),
@birth Date,
@netid Integer,
@email varchar(30),
@gender varchar(20),
@positionName varchar(30),
@deptName varchar(30),
@begin Date
AS
DECLARE @StaffID INT, @PosID INT, @DeptID INT
-- SET @StaffID = ()
SET @PosID = (SELECT PositionTypeID
				FROM tblPOSITION_TYPE PT
				WHERE PT.PositionTypeName = @positionName)
Set @DeptID = (
				SELECT DeptID
				FROM tblDEPARTMENT D
				WHERE D.DeptName = @deptName
				)
BEGIN TRAN E1
INSERT INTO tblSTAFF(StaffFName, StaffLName, StaffAddress, StaffCity, StaffState, StaffZip, StaffBirth, StaffNetID, StaffEmail, Gender)
VALUES(@fname, @lname, @address, @city, @state, @zip, @birth, @netid, @email, @gender)
SELECT @StaffID = SCOPE_IDENTITY()

INSERT INTO tblStaff_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES(@StaffID, @PosID, @begin, NULL, @DeptID)

COMMIT TRAN E1
go

