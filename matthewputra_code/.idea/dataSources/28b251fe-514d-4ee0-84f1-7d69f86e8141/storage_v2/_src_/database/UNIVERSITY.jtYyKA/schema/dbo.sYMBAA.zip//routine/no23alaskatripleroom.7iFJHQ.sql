
CREATE FUNCTION dbo.no23alaskatripleroom()
RETURNS INT 
AS 
BEGIN 
DECLARE @RET INT = 0 
IF EXISTS (
		SELECT *
		FROM tblSTUDENT S
		JOIN tblSTUDENT_DORMROOM DR ON S.StudentID = DR.StudentID
		JOIN tblDORMROOM D ON DR.DormRoomID = D.DormRoomID
		JOIN tblDORMROOM_TYPE DT ON D.DormRoomTypeID = DT.DormRoomTypeID
		JOIN tblBUILDING B on D.BuildingID = B.BuildingID
		JOIN tblLOCATION L on B.LocationID = L.LocationID
		WHERE S.StudentPermState = 'Alaska, AK'
		AND L.LocationName  = 'West Campus'
		AND DT.DormRoomTypeName = 'Triple'
		AND S.StudentBirth < DATEADD(YEAR, -23, getdate())
		)
		SET @RET = 1

		RETURN @RET 
END
go

