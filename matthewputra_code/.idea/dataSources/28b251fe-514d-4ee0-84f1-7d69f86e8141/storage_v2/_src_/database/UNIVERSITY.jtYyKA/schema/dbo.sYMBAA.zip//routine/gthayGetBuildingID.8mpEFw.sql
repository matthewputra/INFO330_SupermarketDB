CREATE PROCEDURE gthayGetBuildingID
@Building varchar(50),
@BldgID INT OUTPUT
AS
SET @BldgID = (SELECT BuildingID FROM tblBUILDING WHERE BuildingName = @Building)
go

