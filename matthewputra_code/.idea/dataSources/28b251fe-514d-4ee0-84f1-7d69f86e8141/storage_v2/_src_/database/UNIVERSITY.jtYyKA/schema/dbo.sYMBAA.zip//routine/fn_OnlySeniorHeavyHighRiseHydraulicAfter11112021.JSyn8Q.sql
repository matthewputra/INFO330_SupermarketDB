CREATE FUNCTION fn_OnlySeniorHeavyHighRiseHydraulicAfter11112021()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 1
    IF EXISTS(
        SELECT JobID
        FROM tblEMPLOYEE E
            JOIN tblEMPLOYEE_POSITION EP ON E.EmpID = EP.EmpID
            JOIN tblPOSITION P ON EP.PositionID = P.PositionID
            JOIN tblEMPLOYEE_SKILL ES ON E.EmpID = ES.EmpID
            JOIN tblLEVEL L ON ES.LevelID = L.LevelID
            JOIN tblSKILL S ON ES.SkillID = S.SkillID
            JOIN tblSKILL_TYPE ST ON S.SkillTypeID = ST.SkillTypeID
            JOIN tblCUST_JOB_TASK CJT ON ES.EmpSkillID = CJT.EmpSkillID
            JOIN tblJOB J ON CJT.JobID = J.JobID
            JOIN tblJOB_TYPE JT ON J.JobTypeID = JT.JobTypeID
            JOIN tblEQUIPMENT EQ ON CJT.EquipID = EQ.EquipID
            JOIN tblEQUIPMENT_TYPE ET ON EQ.EquipTypeID = ET.EquipTypeID
        WHERE JobTypeName = 'high-rise residential'
        AND EquipTypeName = 'hydraulic lift'
        AND JobBeginDate > 'November 11, 2021'
        AND LevelName LIKE '%Senior%'
        AND SkillTypeName = 'Heavy Machinery'
        )
    SET @RET = 0
RETURN @RET
END
go

