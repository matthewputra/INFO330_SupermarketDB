CREATE PROCEDURE updEDateStaffPosition
@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@PositionName varchar(30),
@PositionTypeName varchar(30),
@NewEndDate date,
@DeptName varchar(30),
@CName varchar(30)

AS

DECLARE @S_ID INT, @P_ID INT, @D_ID INT

SET @S_ID = (SELECT StaffID
    FROM tblSTAFF
    WHERE StaffFname = @Fname
    AND StaffLname = @Lname
    AND StaffBirth = @Birth)

SET @P_ID = (SELECT PositionID
    FROM tblPOSITION P
        JOIN tblPOSITION_TYPE PT on P.PositionTypeID = PT.PositionTypeID
    WHERE P.PositionName = @PositionName
    AND PT.PositionTypeName = @PositionTypeName)

SET @D_ID = (SELECT DeptID
            FROM tblDEPARTMENT D
                JOIN tblCOLLEGE C on D.CollegeID = C.CollegeID
            WHERE D.DeptName = @DeptName
            AND C.CollegeName = @CName)

BEGIN TRAN A1
UPDATE tblSTAFF_POSITION
SET EndDate = @NewEndDate
WHERE StaffID = @S_ID
AND PositionID = @P_ID
AND DeptID = @D_ID
COMMIT TRAN A1
go

