CREATE PROCEDURE amp_registerStudent
@Fname varchar(30),
@Lname varchar(30),
@Bdate Date,
@Fee Numeric(10,2),
@RegDate Date,
@Grade Numeric(2,2) = NULL,
@CourseN varchar(75),
@Year char(4),
@Sec Varchar(4),
@Quart varchar(30)

AS

DECLARE @C_ID INT
DECLARE @S_ID INT

SET @C_ID = (SELECT ClassID
			FROM tblCLASS C
				JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
				JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
			WHERE Q.QuarterName = @Quart
			AND CR.CourseName = @CourseN
			AND C.[Year] = @Year
			AND C.Section = @Sec)

SET @S_ID = (SELECT StudentID
			FROM tblSTUDENT
			WHERE StudentFname = @Fname
			AND StudentLname = @Lname
			AND StudentBirth = @Bdate)


INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, @Grade, @RegDate, @Fee);
go

