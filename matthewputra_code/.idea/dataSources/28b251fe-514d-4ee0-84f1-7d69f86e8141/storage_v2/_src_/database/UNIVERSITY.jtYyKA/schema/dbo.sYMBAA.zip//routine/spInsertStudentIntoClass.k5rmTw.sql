CREATE PROCEDURE spInsertStudentIntoClass(
	@SFN varchar(60),
	@SLN varchar(60),
	@DPN varchar(75),
	@CN numeric(3,0),
	@QT varchar(30),
	@YR char(4),
	@SC varchar(4),
	@RD date)
AS
BEGIN 
	DECLARE 
		@CID INT = (SELECT ClassID
						FROM tblCLASS C
							JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
							JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
							JOIN tblDEPARTMENT DP ON CO.DeptID = DP.DeptID
						WHERE DP.DeptName = @DPN 
						AND CourseNumber = @CN
						AND Q.QuarterName = @QT
						AND C.[YEAR] = @YR
						AND C.Section = @SC),
		@SID INT = (SELECT StudentID
						FROM tblSTUDENT
						WHERE StudentFname = @SFN
						AND StudentLname = @SLN)
	INSERT INTO tblCLASS_LIST
		(ClassID,
		StudentID,
		Grade,
		RegistrationDate,
		RegistrationFee)
	VALUES (@CID,
			@SID,
			NULL,
			@RD,
			NULL)
END
go

