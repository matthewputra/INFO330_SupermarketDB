CREATE PROCEDURE spInsertStudentIntoClass(
	@SFN varchar(60),
	@SLN varchar(60),
	@SBD date, 
	@DPN varchar(75),
	@CN numeric(3,0),
	@QT varchar(30),
	@YR char(4),
	@SC varchar(4),
	@Grade decimal(3,2) NULL, 
	@RD date,
	@RF numeric(10,2))
AS
BEGIN 
	DECLARE 
		@CID INT = (SELECT ClassID
						FROM tblCLASS C
							JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
							JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
							JOIN tblDEPARTMENT DP ON CO.DeptID = DP.DeptID
						WHERE DP.DeptName = @DPN 
						AND CourseNumber = @CN
						AND Q.QuarterName = @QT
						AND C.[YEAR] = @YR
						AND C.Section = @SC),
		@SID INT = (SELECT StudentID
						FROM tblSTUDENT
						WHERE StudentFname = @SFN
						AND StudentLname = @SLN
						AND StudentBirth = @SBD)
	INSERT INTO tblCLASS_LIST
		(ClassID,
		StudentID,
		Grade,
		RegistrationDate,
		RegistrationFee)
	VALUES (@CID,
			@SID,
			@Grade,
			@RD,
			@RF)
END
go

