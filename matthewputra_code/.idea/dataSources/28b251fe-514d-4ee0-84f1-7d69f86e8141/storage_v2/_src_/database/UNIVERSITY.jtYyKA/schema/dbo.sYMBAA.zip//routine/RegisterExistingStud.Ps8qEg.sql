/*5.	Create a stored procedure to register an existing student to an existing class. 
Pass-in 'name' values as parameters and use variables to 'look-up' required values as necessary.*/

Create Procedure RegisterExistingStud

@First varchar(30),
@Last varchar(30),
@Birth Date,
@CourseName varchar(50)

AS
DECLARE @StudID INT, @CRSID INT

SET @StudID = (SELECT StudentID
FROM tblSTUDENT
WHERE StudentFname = @First
AND StudentLname = @Last
AND StudentBirth = @Birth)

SET @CRSID = (SELECT CourseID FROM tblCOURSE WHERE CourseName = @CourseName)


INSERT INTO tblCOURSE(CourseID, CourseName)
VALUES (@CRSID, @CourseName)
go

