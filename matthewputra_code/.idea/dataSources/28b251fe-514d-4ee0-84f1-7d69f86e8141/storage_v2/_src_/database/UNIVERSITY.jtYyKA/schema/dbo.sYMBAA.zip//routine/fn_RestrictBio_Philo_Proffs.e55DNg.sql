CREATE FUNCTION fn_RestrictBio_Philo_Proffs()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS (SELECT *
			FROM tblQUARTER Q
				JOIN tblCLASS C ON Q.QuarterID = C.QuarterID
				JOIN tblCOURSE CR ON CR.CourseID = C.CourseID
				JOIN tblDEPARTMENT D ON D.DeptID = CR.DeptID
				JOIN tblINSTRUCTOR_CLASS INC ON INC.ClassID = C.ClassID
				JOIN tblINSTRUCTOR I ON I.InstructorID = INC.InstructorID
				JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON IIT.InstructorID = I.InstructorID
				JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID = IT.InstructorTypeID
			WHERE D.DeptID = 'Biology' or D.DeptName = 'Philosophy'
			AND Q.QuarterName = 'Summer'
			AND IT.InstructorTypeName NOT IN ('Assistant Professor', 'Associate Professor')
			AND CR.CourseName LIKE '%4__')
	 BEGIN
		SET @RET = 1
	END
RETURN @RET
END
go

