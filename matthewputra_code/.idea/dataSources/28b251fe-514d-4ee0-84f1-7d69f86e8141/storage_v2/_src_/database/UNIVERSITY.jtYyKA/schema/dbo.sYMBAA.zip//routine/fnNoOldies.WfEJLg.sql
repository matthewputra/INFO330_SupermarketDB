CREATE FUNCTION fnNoOldies()
RETURNS INT
    AS
    BEGIN
        DECLARE @RET INT = 0
        IF EXISTS(SELECT s.StudentFName, s.StudentLName, S.StudentID, DateDiff(year,s.StudentBirth, getdate()), s.studentpermstate, l.locationname, drt.dormroomtypename
                    FROM tblSTUDENT s
                    INNER JOIN tblStudent_DormRoom sdr ON sdr.studentID = s.StudentID
                    INNER JOIN tblDormRoom dr on sdr.dormroomid = dr.dormroomid
                    INNER JOIN tblDormRoom_Type drt on drt.DormRoomTypeId = dr.DormRoomTypeID
                    INNER JOIN tblBuilding b on dr.buildingid = b.buildingid
                    INNER JOIN tblLocation l on b.locationid = l.locationid
                    WHERE DateDiff(year,s.StudentBirth, getdate()) > 23
                    AND s.StudentPermState like '%Alas%'
                    AND l.locationname = 'West Campus'
                    AND drt.dormroomtypename like '%Trip%')
        BEGIN
            SET @RET = 1
        end
        RETURN @RET
    end
go

