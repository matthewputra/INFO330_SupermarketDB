CREATE PROCEDURE uspNEWCLASS
@Course varchar(50),
@Section char(3),
@Dept varchar(50),
@YEAR char(4)
AS
Declare @ClassID INT
SET @ClassID = (
SELECT ClassID
FROM tblCLASS CL
JOIN tblCOURSE CR
ON CR.CourseID = CL.CourseID
JOIN tblDEPARTMENT DE
ON DE.DeptID = CR.DeptID
WHERE CL.Section = @Section
AND CR.CourseName = @Course
AND DE.DeptName = @Dept
AND CL.YEAR = @YEAR)
INSERT INTO tblCLASS (ClassID, YEAR, Section)
VALUES (@ClassID, @YEAR, @Section)
go

