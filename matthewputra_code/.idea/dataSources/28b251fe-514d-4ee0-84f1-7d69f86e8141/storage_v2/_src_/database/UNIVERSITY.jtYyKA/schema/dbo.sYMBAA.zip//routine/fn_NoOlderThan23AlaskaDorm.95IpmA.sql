CREATE FUNCTION fn_NoOlderThan23AlaskaDorm()
RETURNS INT 
AS 
BEGIN 
	DECLARE @RET INT = 0
		IF EXISTS(SELECT S.StudentID
			FROM tblSTUDENT S
				JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
				JOIN tblDORMROOM D ON SD.DormRoomID = D.DormRoomID
				JOIN tblDORMROOM_TYPE DT ON D.DormRoomTypeID = DT.DormRoomTypeID
				JOIN tblBUILDING B ON D.BuildingID = B.BuildingID
				JOIN tblBUILDING_TYPE BT ON B.BuildingTypeID = BT.BuildingTypeID
				JOIN tblLOCATION LO ON B.LocationID = LO.LocationID
			WHERE S.StudentPermState = 'Alaska, AK'
			AND S.StudentBirth < DateAdd(YEAR, -23, GetDate())
			AND BT.BuildingTypeName LIKE '%Dorm%'
			AND LO.LocationName LIKE '%West Campus%'
			AND DT.DormRoomTypeName = 'Triple'
			GROUP BY S.StudentID
			)
	SET @RET = 1
RETURN @RET
END
go

