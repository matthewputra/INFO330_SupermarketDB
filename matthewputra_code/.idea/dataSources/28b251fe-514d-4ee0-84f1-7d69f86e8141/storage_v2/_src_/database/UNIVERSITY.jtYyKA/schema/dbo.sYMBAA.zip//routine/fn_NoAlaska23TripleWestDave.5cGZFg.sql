CREATE FUNCTION fn_NoAlaska23TripleWestDave()
RETURNS INT
AS
BEGIN
    DECLARE @Ret INT = 0
    IF EXISTS (
        SELECT S.StudentID
        FROM tblSTUDENT S
            JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
            JOIN tblDORMROOM DM ON SD.DormRoomID = DM.DormRoomID
            JOIN tblDORMROOM_TYPE DT on DM.DormRoomTypeID = DT.DormRoomTypeID
            JOIN tblBUILDING B ON DM.BuildingID = B.BuildingID
            JOIN tblLOCATION L ON B.LocationID = L.LocationID
        WHERE S.StudentPermState = 'Alaska, AK'
        AND L.LocationName LIKE '%West%'
        AND StudentBirth < DateAdd(Year, -23, GETDATE()) -- students born earlier than 23 years ago
        AND DormRoomTypeName = 'Triple')
    SET @Ret = 1
RETURN @Ret
END
go

