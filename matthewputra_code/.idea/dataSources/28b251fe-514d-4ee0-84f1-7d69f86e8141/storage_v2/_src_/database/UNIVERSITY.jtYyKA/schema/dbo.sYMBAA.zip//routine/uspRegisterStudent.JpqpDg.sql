CREATE PROCEDURE uspRegisterStudent
    @Fname varchar(20),
    @Lname varchar(20),
    @Bday date,
    @Course varchar(50),
    @Quarter varchar(20),
    @Year char(4),
    @Section char(3),
    @RegDate date,
    @RegFee numeric(6,2)
    AS
    DECLARE @ClassID INT, @StudentID INT
    SET @ClassID = (SELECT ClassID
        FROM tblCLASS CL
            JOIN tblQuarter Q ON CL.QuarterID = Q.QuarterID
            JOIN tblCourse CR ON CL.CourseID = CR.CourseID
        WHERE Q.QuarterName = @Quarter
        AND CR.CourseName = @Course
        AND CL.[YEAR] = @Year
        AND CL.Section = @Section
        )
    SET @StudentID = (SELECT StudentID
        FROM tblSTUDENT S
        WHERE S.StudentFname = @Fname
        AND S.StudentLname = @Lname
        AND S.StudentBirth = @Bday
        )

    BEGIN TRANSACTION RegisterStudent
    INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
    VALUES(@ClassID, @StudentID, NULL, @RegDate, @RegFee)
    COMMIT TRANSACTION RegisterStudent
go

