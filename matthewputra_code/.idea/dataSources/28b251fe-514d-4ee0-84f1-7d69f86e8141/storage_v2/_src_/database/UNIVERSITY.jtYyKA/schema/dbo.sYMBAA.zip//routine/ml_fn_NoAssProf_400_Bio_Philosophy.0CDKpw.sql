CREATE FUNCTION ml_fn_NoAssProf_400_Bio_Philosophy()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT=0
	IF EXISTS(SELECT * FROM tblINSTRUCTOR I 
	JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID=IC.InstructorID
	JOIN tblCLASS CL ON CL.ClassID=IC.ClassID
	JOIN tblQUARTER Q ON Q.QuarterID=CL.QuarterID
	JOIN tblCOURSE CR ON CR.CourseID=CL.CourseID
	JOIN tblDEPARTMENT D ON D.DeptID=CR.DeptID
	JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON IIT.InstructorID=I.InstructorID
	JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID=IT.InstructorTypeID
	WHERE CR.CourseNumber like '%4__'
	AND D.DeptName IN ('Biology','Philosophy')
	AND Q.QuarterName='Summer'
	AND IT.InstructorTypeName NOT IN ('Associate Professor','Assistant Professor'))
	BEGIN
		SET @RET=1
	END
RETURN @RET
END
go

