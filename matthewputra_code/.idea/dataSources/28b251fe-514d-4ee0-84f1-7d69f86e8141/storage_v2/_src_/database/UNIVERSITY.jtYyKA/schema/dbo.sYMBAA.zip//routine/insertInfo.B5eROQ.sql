CREATE PROCEDURE insertInfo
@SFName VARCHAR(20),
@SLName VARCHAR(20),
@Sdob DATE,
@UnitName VARCHAR(20),
@MonthlyPayment NUMERIC(5,2),
@BeginDate DATE,
@EndDate DATE
AS 
DECLARE @U_ID INT, @S_ID INT
go

