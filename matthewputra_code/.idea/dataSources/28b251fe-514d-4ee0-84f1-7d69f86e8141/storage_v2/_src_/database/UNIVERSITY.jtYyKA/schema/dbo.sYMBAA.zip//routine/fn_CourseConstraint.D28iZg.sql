CREATE   FUNCTION fn_CourseConstraint()
RETURNS INT
AS
BEGIN
   DECLARE @RET INT = 0
   IF EXISTS(   select * from  tblClass C
				Join tblInstructor_Class IC on C.ClassID = IC.ClassID
				join tblQUARTER Q on Q.QuarterID= C.QuarterID
				Join tblINSTRUCTOR I on I.InstructorID =IC.InstructorID
				Join tblINSTRUCTOR_INSTRUCTOR_TYPE IIT on IIT.InstructorID = I.InstructorID
				Join tblINSTRUCTOR_TYPE IT on IT.InstructorTypeID= IIT.InstructorTypeID
				join tblCOURSE Co on Co.CourseID= C.CourseID 
				where
				(Co.CourseName like 'BIOL4%'
				or Co.CourseName like 'PHIL4%')
				and Q.QuarterName='Summer'
				and (IT.InstructorTypeName <> 'Assistant Professor' 
				and IT.InstructorTypeName <>'Associate Professor')
               )
   SET @RET = 1
   RETURN @RET
END
go

