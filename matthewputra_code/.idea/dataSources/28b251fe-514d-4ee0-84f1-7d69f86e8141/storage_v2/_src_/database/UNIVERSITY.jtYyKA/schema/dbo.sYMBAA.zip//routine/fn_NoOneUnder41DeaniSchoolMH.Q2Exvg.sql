CREATE FUNCTION fn_NoOneUnder41DeaniSchoolMH()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
        IF EXISTS(SELECT *
            FROM tblCOLLEGE C
                JOIN tblDEPARTMENT D on C.CollegeID = D.CollegeID
                JOIN tblSTAFF_POSITION SP on D.DeptID = SP.DeptID
                JOIN tblPOSITION P on SP.PositionID = P.PositionID
                JOIN tblSTAFF SF on SP.StaffID = SF.StaffID
            WHERE C.CollegeName = 'Information School'
            AND SF.StaffBirth > DATEADD(Year, -41, GETDATE()))
     SET @RET = 1
RETURN @RET
END
go

