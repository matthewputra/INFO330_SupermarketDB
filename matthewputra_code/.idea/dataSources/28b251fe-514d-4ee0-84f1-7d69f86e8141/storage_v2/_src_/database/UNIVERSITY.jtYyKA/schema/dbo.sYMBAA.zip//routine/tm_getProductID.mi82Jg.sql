CREATE PROCEDURE tm_getProductID
@ProductName varchar(50),
@ProductID int output
AS
    SET @ProductID = (SELECT P.ProductID FROM PRODUCT P WHERE P.ProductName = @ProductName)
go

