CREATE PROCEDURE uspINSERTINTOCLASSLISTDave
     -- the first 4 parameters are all to describe ClassID
    @CourseName varchar(20),
    @QuarterName varchar(20),
    @Year char(4),
    @Section varchar(20),
    -- the following are for StudentID
    @FName varchar(30),
    @LName varchar(30),
    @Birth Date,
    -- the rest are ambiguous
    @Grade decimal(3,2),
    @RegistrationDate Date,
    @RegistrationFee numeric(10,2)
AS
     DECLARE @C_ID INT, @S_ID INT
     SET @C_ID = (
         SELECT ClassID
         FROM tblCLASS CS
            JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
            JOIN tblQUARTER Q ON CS.QuarterID = Q.QuarterID
         WHERE CourseName = @CourseName
         AND QuarterName = @QuarterName
         AND CS.[YEAR] = @Year
         AND CS.Section = @Section
         )
     SET @S_ID = (
         SELECT StudentID
         FROM tblSTUDENT
         WHERE StudentFname = @FName
         AND StudentLname = @LName
         AND StudentBirth = @Birth
     )
INSERT INTO tblCLASS_LIST(ClassId, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES(@C_ID, @S_ID, @Grade, @RegistrationDate, @RegistrationFee)
go

