CREATE FUNCTION fn_400BoPProf (@ClassID INT)
RETURNS INT
AS
BEGIN
DECLARE @Ret INT = 0
IF EXISTS (
  SELECT *
  FROM tblCLASS C
  JOIN tblINSTRUCTOR_CLASS IC ON C.CLassID = IC.CLassID
  JOIN tblINSTRUCTOR I ON IC.InstructorID = I.InstructorID
  JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON I.InstructorID = IIT.InstructorID
  JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID = IT.InstructorTypeID
  JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
  JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
  JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
WHERE quarterName = 'Summer'
  AND IT.InstructorTypeName NOT IN ('Assistant Professor', 'Associate Professor')
  AND CR.CourseName LIKE '%4__'
  AND D.DeptName IN ('Biology', 'Philosophy')
  )
  SET @Ret = 1
RETURN @Ret
END
go

