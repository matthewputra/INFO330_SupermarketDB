CREATE PROCEDURE ml_ClassRegistration
@F VARCHAR(60),
@L VARCHAR(60),
@BD DATE,
@Quarter VARCHAR(30),
@Year CHAR(4),
@CourseName VARCHAR(75),
@Section VARCHAR(4),
@RegiDate DATE,
@Fee numeric(10,2)
AS
	DECLARE @ClassID INT,@StuID INT
	SET @ClassID=(SELECT ClassID FROM tblCLASS CL 
	JOIN tblCOURSE CR ON CR.CourseID=CL.CourseID
	JOIN tblQUARTER Q ON Q.QuarterID=CL.QuarterID
	WHERE CR.CourseName=@CourseName
	AND CL.[YEAR]=@Year
	AND Q.QuarterName=@Quarter
	AND CL.Section=@Section)
	SET @StuID=(SELECT StudentID FROM tblSTUDENT
	WHERE StudentFname=@F AND StudentLname=@L AND StudentBirth=@BD)
INSERT INTO tblCLASS_LIST(ClassID,StudentID,RegistrationDate,RegistrationFee)
VALUES(@ClassID,@StuID,@RegiDate,@Fee)
go

