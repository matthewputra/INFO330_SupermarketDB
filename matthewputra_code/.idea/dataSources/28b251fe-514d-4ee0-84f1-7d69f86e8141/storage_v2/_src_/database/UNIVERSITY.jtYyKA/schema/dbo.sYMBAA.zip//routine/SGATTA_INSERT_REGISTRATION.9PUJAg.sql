--Reminder: stored procedure take parameters of 'names' as opposed to 'ID' values.

--Write the query to determine the students who have spent more than $3,000 in RegistrationFees for Information School classes after 2010 who also have completed 12 credits of Public Health courses before 2016. 

--Write the query to list the Top 3 departments in Arts and Sciences ordered by most students completing a class with a grade of less than 3.4 between 2004 and 2013. HINT: look for the number of DISTINCT individuals who meet the condition NOT the number of classes. :-)

--Write the query to determine the newest building on South campus that has had a Geography class instructed by Greg Hay before winter 2015. 

--Write the query to determine the staff person currently-employed who has been in their position the longest for each college.

--Write the query to determine the TOP 3 classroom types (and their COUNT) that have been most-frequently assigned for 300-level Anthropology courses since 1983.

 --Write the code to create a stored procedure to hire a new person to an existing staff position. 

 --Write the code to create a stored procedure to create a new class of an existing course.

 --Write the code to create a stored procedure to register an existing student to an existing class.


 CREATE PROCEDURE SGATTA_INSERT_REGISTRATION



 @FNAME VARCHAR(30),
 @LNAME VARCHAR(30),
 @BIRTH DATE,
 @REGFEE NUMERIC(10,2),
 @REGDATE DATE,
 @GRADE NUMERIC(2,1) = NULL, --IF NOTHING IS PASSED IN, NULL WILL BE DEFAULTED
 @COURSENAME VARCHAR(50),
 @YEAR CHAR(4),
 @SECTION VARCHAR(4),
 @QUARTER VARCHAR(30)

 --THINKING ABOUT CLASS_LIST TABLE
 --PASS IN COURSE NAME FROM TBLCOURSE
 --COURSE, YEAR, SECTION FROM TBLCLASS
 --GO TO TABLES, CLICK ON TABLE COLUMNS TO FIND COLUMN TYPE
 --@SOMETHING IS A PARAMETER

 AS
DECLARE @C_ID INT --CLASS ID
DECLARE @S_ID INT

SET @C_ID = (SELECT CLASSID
			FROM tblCLASS C
			JOIN TBLQUARTER Q ON C.QuarterID = Q.QuarterID
			JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
			WHERE Q.QuarterName = @QUARTER
			AND CR.COURSENAME = @COURSENAME
			AND C.[YEAR] = @YEAR
			AND C.SECTION =@SECTION)

SET @S_ID = (SELECT STUDENTID
			FROM tblSTUDENT
			WHERE StudentFname = @FNAME
			AND StudentLname = @LNAME
			AND StudentBirth = @BIRTH)



INSERT INTO TBLCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, @GRADE, @REGDATE, @REGFEE)

go

