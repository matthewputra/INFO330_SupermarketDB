CREATE FUNCTION fn_StudentInfoCreds(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT =
        (SELECT COUNT(CL.StudentID)
        FROM tblCOLLEGE C
            JOIN tblDEPARTMENT D on C.CollegeID = D.CollegeID
            JOIN tblCOURSE CR on D.DeptID = CR.DeptID
            JOIN tblCLASS CS on CR.CourseID = CS.CourseID
            JOIN tblCLASS_LIST CL on CS.ClassID = CL.ClassID
            JOIN tblSTUDENT S on CL.StudentID = S.StudentID
        WHERE C.CollegeName = 'Information School'
        AND CL.[GRADE] > '3.4'
        GROUP BY S.StudentID)
RETURN @RET
END
go

