CREATE FUNCTION fn_CalcTotalRegFeesStudentLIFETIME(@PK INT)
RETURNS numeric(18,2)
AS
BEGIN
	DECLARE @RET numeric(18,2) = (SELECT SUM(RegistrationFee)
	FROM tblCLASS_LIST CL
		JOIN tblSTUDENT S ON CL.StudentID = S.StudentID
	WHERE S.StudentID = @PK
	)
RETURN @RET

END
go

