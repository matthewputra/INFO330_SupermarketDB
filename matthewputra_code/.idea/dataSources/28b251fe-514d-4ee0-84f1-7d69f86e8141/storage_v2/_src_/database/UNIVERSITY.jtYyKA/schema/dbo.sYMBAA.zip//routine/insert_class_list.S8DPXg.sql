CREATE PROCEDURE insert_class_list
@sfname varchar(50),
@slname varchar(50),
@sbirth date,
@coursename varchar(50),
@quarter varchar(50),
@year char(4),
@section varchar(4),
@Grade decimal(3,2),
@regdate DATE,
@regfee NUMERIC(10,2)
AS
    DECLARE @cID INT, @sID INT
    SET @cID = (SELECT ClassID FROM tblCLASS C
        JOIN tblCOURSE tC on C.CourseID = tC.CourseID
        JOIN tblQUARTER tQ on C.QuarterID = tQ.QuarterID
        WHERE tC.CourseName = @coursename AND tQ.QuarterName = @quarter AND C.YEAR = @year
        AND C.Section = @section)
    SET @sID = (SELECT StudentID FROM tblSTUDENT WHERE StudentFname = @sfname AND StudentLname = @slname
        AND StudentBirth = @sbirth)
INSERT INTO tblCLASS_LIST(CLASSID, STUDENTID, Grade, REGISTRATIONDATE, REGISTRATIONFEE)
VALUES(@cID, @sID, @Grade, @regdate, @regfee)
go

