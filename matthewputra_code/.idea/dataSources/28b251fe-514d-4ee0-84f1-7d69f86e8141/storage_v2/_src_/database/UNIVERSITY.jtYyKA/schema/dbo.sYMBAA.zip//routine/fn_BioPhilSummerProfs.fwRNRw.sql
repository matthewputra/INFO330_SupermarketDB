CREATE FUNCTION fn_BioPhilSummerProfs()
RETURNS INT
AS
BEGIN
DECLARE @Ret INT = 0
	IF EXISTS(SELECT *
		FROM tblCLASS C
			JOIN tblCOURSE CE ON C.CourseID = CE.CourseID
			JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
			JOIN tblINSTRUCTOR_CLASS IC ON C.ClassID = IC.ClassID
			JOIN tblINSTRUCTOR I ON IC.InstructorID = I.InstructorID
			JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON I.InstructorID = IIT.InstructorID
			JOIN tblINSTRUCTOR_TYPE IT 
ON IIT.InstructorTypeID = IT.InstructorTypeID
		WHERE CE.CourseName = 'BIOL' OR CE.CourseName = 'PHIL'
			AND C.ClassID BETWEEN '400' AND '499'
			AND Q.QuarterName = 'SUM'
			AND IT.InstructorTypeName = 'Assistant Professor'
				OR IT.InstructorTypeName = 'Associate Professor'
	)

SET @Ret = 1
RETURN @Ret
END
go

