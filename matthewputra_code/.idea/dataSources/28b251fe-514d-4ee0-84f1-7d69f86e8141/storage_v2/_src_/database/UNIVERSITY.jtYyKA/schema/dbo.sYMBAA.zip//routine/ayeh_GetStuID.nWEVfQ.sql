CREATE PROCEDURE ayeh_GetStuID
@studFname varchar(50),
@studLname varchar(50),
@studBdate Date,
@studID INT OUTPUT
AS
    SET @studID = (SELECT StudentID FROM tblSTUDENT WHERE StudentFname = @studFname AND StudentLname = @studLname AND StudentBirth = @studBdate)
go

