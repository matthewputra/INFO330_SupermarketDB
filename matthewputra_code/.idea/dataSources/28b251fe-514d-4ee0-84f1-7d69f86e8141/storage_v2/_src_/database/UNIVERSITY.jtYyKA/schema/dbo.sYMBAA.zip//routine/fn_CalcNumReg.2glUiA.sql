CREATE FUNCTION fn_CalcNumReg(@PK int)
Returns int
As
Begin
declare @Ret int =
    (select count(Cl.StudentID)
    from tblCLass_List CL
        where CL.ClassID = @PK)
return @Ret
    end
go

