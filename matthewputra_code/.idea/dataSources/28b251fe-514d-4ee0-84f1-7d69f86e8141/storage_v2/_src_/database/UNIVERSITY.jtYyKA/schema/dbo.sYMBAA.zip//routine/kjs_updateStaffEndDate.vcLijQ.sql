CREATE PROCEDURE kjs_updateStaffEndDate
@Fname varchar(20),
@Lname varchar(20),
@Birth Date,
@Dept varchar(50),
@Position varchar(75),
@End Date
AS
DECLARE @S_ID INT, @D_ID INT, @P_ID INT

SET @S_ID = (SELECT StaffID FROM tblSTAFF
				WHERE StaffFname = @Fname
					AND StaffLname = @Lname
					AND StaffBirth = @Birth)
SET @D_ID = (SELECT DeptID FROM tblDEPARTMENT
				WHERE DeptName = @Dept)
SET @P_ID = (SELECT PositionID FROM tblPOSITION
				WHERE PositionName = @Position)

BEGIN TRAN T1
UPDATE tblSTAFF_POSITION
SET EndDate = @End
WHERE StaffID = @S_ID
	AND DeptID = @D_ID
	AND PositionID = @P_ID
COMMIT TRAN T1

go

