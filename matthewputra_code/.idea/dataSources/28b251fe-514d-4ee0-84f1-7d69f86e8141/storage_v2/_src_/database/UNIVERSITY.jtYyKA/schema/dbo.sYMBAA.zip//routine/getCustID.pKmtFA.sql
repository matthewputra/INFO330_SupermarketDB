CREATE PROCEDURE getCustID
@Fname varchar(50),
@Lname varchar(50),
@dob date,
@CustID int output
AS
SET @CustID = (SELECT C.CustID FROM CUSTOMER C WHERE C.Fname = @Fname AND C.Lname = @Lname AND C.DOB = @dob)
go

