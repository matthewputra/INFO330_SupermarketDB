CREATE PROCEDURE uspINSERTCLASS
@Cname varchar(40),
@Qname varchar(10),
@QBegin varchar(10),
@QEnd varchar(10),
@SName varchar(3),
@Year char(4)
AS
DECLARE @CS_ID INT, @CR_ID INT
SET @CS_ID = (SELECT ClassID FROM tblCLASS C
	JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
	WHERE QuarterName = @Qname
	AND QuartBeginMonth = @QBegin
	AND QuartEndMonth = @QEnd
	AND Section = @SName
	AND [YEAR] = @Year)
SET @CR_ID = (SELECT CourseID FROM tblCOURSE CR WHERE CourseName = @Cname)

BEGIN TRAN J2
INSERT INTO tblCLASS (ClassID, CourseID, [YEAR])
Values (@CS_ID, @CR_ID, @Year)
COMMIT TRAN J2
go

