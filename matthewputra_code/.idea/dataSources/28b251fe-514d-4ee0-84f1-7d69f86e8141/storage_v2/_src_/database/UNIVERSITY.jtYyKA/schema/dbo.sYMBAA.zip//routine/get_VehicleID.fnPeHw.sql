
CREATE PROCEDURE get_VehicleID
@VehicleN VARCHAR(50),
@PlateIssuingS VARCHAR(50),
@LicenseP VARCHAR(50),
@V_ID INT OUTPUT
AS 

SET @V_ID = (SELECT VehicleID FROM tblVEHICLE Where VehicleName = @VehicleN AND PlateIssuingState = @PlateIssuingS AND LicensePlate = @LicenseP)
go

