CREATE PROCEDURE usp_Registration
@studentFname varchar(60),
@studentLname varchar(60),
@Birth Date,
@Year varchar(4),
@Quarter varchar(30),
@Section char(3),
@CourseName varchar(75),
@RegistrationFee numeric(10, 2)

AS
DECLARE @StudentID INT
DECLARE @ClassID INT
DECLARE @Grade FLOAT
DECLARE @RegistrationDate DATE

SET @StudentID = (SELECT StudentID
					FROM tblSTUDENT
					WHERE StudentFname = @studentFname
					AND StudentLname = @studentLname
					AND StudentBirth = @Birth)
SET @ClassID = (SELECT c.ClassID
				FROM tblCLASS c
				JOIN tblCOURSE course ON c.CourseID = course.CourseID
				JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
				WHERE course.CourseName = @CourseName
				AND Q.QuarterName = @Quarter
				AND c.[Year] = @Year
				AND c.Section = @Section
				)
SET @Grade = NULL
SET @RegistrationDate = GETDATE()

BEGIN TRAN T_Registration
INSERT INTO tblCLASS_LIST(StudentID, ClassID, Grade, RegistrationDate, RegistrationFee)
VALUES (@StudentID, @ClassID, @Grade, @RegistrationDate, @RegistrationFee)
COMMIT TRAN T_Registration
go

