CREATE PROCEDURE uspNewHIRE
@SFname varchar(20),
@SLname varchar(20),
@SBirth date,
@PosName varchar(20),
@Begin date,
@End date,
@DeptName varchar(20)
AS
    DECLARE @S_ID INT, @P_ID INT, @D_ID INT
SET @S_ID = (SELECT StaffID FROM tblSTAFF
            WHERE StaffLName = @SLname
            AND StaffFName = @SFname
            AND StaffBirth = @SBirth)
SET @P_ID = (SELECT PositionID FROM tblPOSITION
            WHERE PositionName = @PosName)
SET @D_ID = (SELECT DeptID FROM tblDEPARTMENT
            WHERE DeptName = @DeptName)
INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES (@S_ID,@P_ID,@Begin,@End,@D_ID)
go

