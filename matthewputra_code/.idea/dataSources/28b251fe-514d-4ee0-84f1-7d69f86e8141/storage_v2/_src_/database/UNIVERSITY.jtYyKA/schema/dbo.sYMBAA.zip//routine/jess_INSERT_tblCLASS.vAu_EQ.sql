CREATE PROCEDURE jess_INSERT_tblCLASS
@CourName varchar(30),
@SchedName varchar(30),
@RoomName varchar(30),
@Sections varchar(30),
@Year INT,
@QuatName varchar(30)

AS

DECLARE @CourID INT, @QuatID INT, @RoomID INT, @SchedID INT
SET @CourID = (select CourseID from tblCOURSE where CourseName = @CourName)
SET @QuatID = (select QuarterID from tblQuarter where QuarterName = @QuatName)
SET @RoomID = (select ClassroomID from tblCLASSROOM where ClassroomName = @RoomName)
SET @SchedID = (select ScheduleID from tblSCHEDULE where ScheduleName = @SchedName)

INSERT INTO tblCLASS(CourseID, QuarterID, [YEAR], ClassroomID, ScheduleID, Section)
VALUES (@CourID, @QuatID, @Year, @RoomID, @SchedID, @Sections)
go

