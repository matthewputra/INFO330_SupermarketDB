
/* 5. Write the SQL to create enforce the following business rule:
   “No more than 12,500 pounds of baggage may be booked on planes of type ‘Puddle Jumper’” */

CREATE FUNCTION fn_NoMoreThan12500lbBggage()
RETURNS INT
AS
BEGIN

DECLARE @Ret INT = 0
IF EXISTS (select P.PlaneID, P.PlaneName
		   from PLANE P
			  JOIN PLANE_TYPE PT ON PT.PlaneTypeID = P.PlaneTypeID
			  JOIN SEAT_PLANE SP ON SP.PlaneID = P.PlaneID
			  JOIN BOOKING B ON B.SeatPlaneClassID = SP.SeatPlaneClassID
			  JOIN BAG BG ON BG.BookingID = B.BookingID
		   where BG.[Weight] > 12500
		   AND PT.PlanTypeName = 'Puddle Jumper'
		   GROUP BY P.PlaneID, P.PlaneName
		   HAVING SUM(BG.[Weight]) > 12500)
	BEGIN
		SET @Ret = 1
	END
RETURN @RET
END
go

