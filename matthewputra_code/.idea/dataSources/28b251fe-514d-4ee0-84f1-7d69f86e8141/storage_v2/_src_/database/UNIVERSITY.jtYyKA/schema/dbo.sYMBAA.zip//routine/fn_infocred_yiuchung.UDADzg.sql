create function fn_infocred_yiuchung (@pk int)

returns int

as begin 

	declare @ret int = 
	(select sum(c.credits)
	from tblCOURSE c 
	join tblCLASS cs on c.CourseID = cs.CourseID
	join tblCLASS_LIST cl on cs.ClassID = cl.ClassID
	join tblSTUDENT s on cl.studentid = s.studentid

	where s.studentid = @pk
	and c.CourseName like '%INFO__%'
	AND cl.grade > 3.4 
	)

	return @ret
	end
go

