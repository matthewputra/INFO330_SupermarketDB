CREATE FUNCTION AvgGrades_30s (@PK INT)
RETURNS DECIMAL(5,4)
AS
BEGIN
    DECLARE @Ret NUMERIC(5,4)=( SELECT AVG(CL.Grade)
                                FROM tblCLASS_LIST CL
                                    JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
                                    JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
                                    JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
                                    JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
                                WHERE CS.[YEAR] LIKE '193_'
                                AND C.CollegeID=@PK )
RETURN @Ret
end
go

