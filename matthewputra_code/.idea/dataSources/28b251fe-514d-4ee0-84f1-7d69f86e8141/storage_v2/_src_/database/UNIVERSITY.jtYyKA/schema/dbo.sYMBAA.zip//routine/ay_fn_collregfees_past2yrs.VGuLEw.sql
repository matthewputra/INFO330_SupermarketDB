CREATE FUNCTION ay_fn_collregfees_past2yrs (@PK int)
RETURNS int
    AS
    BEGIN
        DECLARE @Ret INT = ( SELECT SUM(CL.RegistrationFee) FROM tblCLASS_LIST CL
           JOIN tblCLASS C ON  C.ClassID = CL.ClassID
            JOIN tblCOURSE CR ON CR.CourseID = C.ClassID
            JOIN tblDEPARTMENT D ON D.DeptID = CR.DeptID
            JOIN tblCOLLEGE CO ON CO.CollegeID = D.CollegeID
            WHERE DATEDIFF (day, CL.RegistrationDate, getdate())/365.25 <= 2
            AND CO.CollegeID = @PK)
        RETURN @Ret
    end
go

