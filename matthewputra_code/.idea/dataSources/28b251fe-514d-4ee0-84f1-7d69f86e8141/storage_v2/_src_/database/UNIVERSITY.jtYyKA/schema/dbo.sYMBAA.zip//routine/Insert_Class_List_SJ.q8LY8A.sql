CREATE   PROCEDURE Insert_Class_List_SJ
@CourseName VARCHAR(10),
@Year CHAR(4),
@Section VARCHAR(4),
@Quarter VARCHAR(30),
@SFName VARCHAR(60),
@SLName VARCHAR(60),
@Birth DATE,
@RegDate DATE,
@RegFee NUMERIC(10,2),
@Grade NUMERIC(2,1)
AS
	DECLARE @StudentID INT, @ClassID INT
	SET @StudentID = (SELECT StudentID FROM tblSTUDENT
	WHERE StudentFname = @SFName
	AND StudentLname = @SLName
	AND StudentBirth = @Birth)

	SET @ClassID = (SELECT ClassID
	FROM tblCLASS C
	JOIN tblQUARTER Q ON C.QuarterID = q.QuarterID
	JOIN tblCOURSE CS ON C.CourseID = CS.CourseID
	WHERE Q.QuarterName = @Quarter
	AND CS.CourseName = @CourseName
	AND C.[YEAR] = @Year
	AND C.Section = @Section)

	IF @StudentID IS NULL
	BEGIN
		PRINT 'Error: Student does not exist!!'
		RAISERROR ('@StudentID cannot be NULL; statement is being terminated', 11,1)
		RETURN
	END
	IF @ClassID IS NULL
	BEGIN
		PRINT 'Error: Class does not exist!!'
		RAISERROR ('@ClassID cannot be NULL; statement is being terminated.', 11,1)
		RETURN
	END
	BEGIN TRAN G1
		INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
		VALUES (@ClassID, @StudentID, @Grade, @RegDate, @RegFee) 
		IF @@ERROR <> 0
		BEGIN
			PRINT '@@ERROR is showing a number <> 0; transaction is being terminated.'
			ROLLBACK TRAN G1
		END
		ELSE
			COMMIT TRAN G1
go

