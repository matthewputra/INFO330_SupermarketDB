CREATE FUNCTION fn_no23yoAlaskaWestDormTypeTriple_sw()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
		IF EXISTS
		(
			SELECT *
				FROM tblSTUDENT S
					JOIN tblSTUDENT_DORMROOM SD ON S.StudentID = SD.StudentID
					JOIN tblDORMROOM D ON SD.DormRoomID = D.DormRoomID
					JOIN tblDORMROOM_TYPE DT ON D.DormRoomTypeID = DT.DormRoomTypeID
					JOIN tblBUILDING B ON D.BuildingID = B.BuildingID
					JOIN tblLOCATION L ON B.LocationID = L.LocationID
				WHERE DormRoomTypeName = 'Triple'
					AND S.StudentBirth < DateAdd(Year, -23, GetDate())
					AND L.LocationName = 'West Campus'
					AND S.StudentPermState = 'Alaska, AK'
		)

		SET @RET = 1

	RETURN @RET
END
go

