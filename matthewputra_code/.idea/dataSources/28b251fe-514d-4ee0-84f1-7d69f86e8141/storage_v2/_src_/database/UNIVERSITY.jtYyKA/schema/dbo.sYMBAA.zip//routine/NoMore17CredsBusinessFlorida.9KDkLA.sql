CREATE FUNCTION dbo.NoMore17CredsBusinessFlorida()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
    IF EXISTS (SELECT *, SUM(CO.Credits)
                FROM tblCOLLEGE C
                    JOIN tblDEPARTMENT D on C.CollegeID = D.CollegeID
                    JOIN tblCOURSE CO on D.DeptID = CO.DeptID
                    JOIN tblCLASS CS on CO.CourseID = CS.CourseID
                    JOIN tblCLASS_LIST CL on CS.ClassID = CL.ClassID
                    JOIN tblSTUDENT S on CL.StudentID = S.StudentID
                    JOIN tblQUARTER Q on CS.QuarterID = Q.QuarterID
                WHERE s.StudentPermState = 'Florida, FL'
                AND C.CollegeName LIKE '%Business%'
                AND Q.QuarterName = 'Winter'
                AND Year(CL.RegistrationDate) = YEAR(GetDate())
                GROUP BY S.StudentID
                HAVING SUM(CO.Credits) > 17)

    SET @RET = 1
RETURN @RET
END
go

