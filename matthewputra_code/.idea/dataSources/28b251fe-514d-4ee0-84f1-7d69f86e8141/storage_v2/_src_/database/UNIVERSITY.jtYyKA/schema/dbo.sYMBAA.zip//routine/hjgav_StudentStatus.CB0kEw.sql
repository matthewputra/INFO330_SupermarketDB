CREATE PROCEDURE hjgav_StudentStatus
@StatusName VARCHAR(60),
@StudentFname VARCHAR(60),
@StudentLname VARCHAR(60),
@BeginDate DATE,
@EndDate DATE

AS 
DECLARE @Stat_ID INT
DECLARE @Stud_ID INT



SET @Stat_ID = (SELECT StatusID 
				FROM tblSTATUS 
				WHERE StatusName = @StatusName)
SET @Stud_ID = (SELECT StudentID
				FROM tblSTUDENT
				WHERE StudentFname = @StudentFname
				AND StudentLname = @StudentLname)


INSERT INTO tblSTUDENT_STATUS(StatusID, StudentID, BeginDate, EndDate)
VALUES (@Stat_ID, @Stud_ID, @BeginDate, @EndDate)
go

