
-- Write the query to determine the number of faculty in the School of Medicine hired before November 21, 2016. 


-- Write the query to determine the number of Administrative staff people were hired in the Medical School between February 12, 2009 and March 28, 2013? 


-- Write the query to determine the newest building on South campus that has had a Geography class instructed by Greg Hay before winter 2015. 


-- Write the query to determine which instructor has had the same office in Padelford Hall the longest.


-- Write the query to determine which 3 classroom types are most-frequently assigned for 400-level Psychology courses


-- Write the code to create a stored procedure to hire a new person to an existing staff position.


-- Write the code to create a stored procedure to create a new class of an existing course.


-- Write the code to create a stored procedure to register an existing student to an existing class.
CREATE PROCEDURE rachvuu_REG

@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@RegFee Numeric(10,2),
@RegDate Date,
@Grade Numeric(2,1) = NULL,
@CourseName varchar(50),
@Year char(4),
@section varchar(4),
@Quarter varchar(30)

AS

DECLARE @C_ID INT
DECLARE @S_ID INT

SET @C_ID = (SELECT ClassID
			FROM tblClass C
				JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
				JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
			WHERE Q.QuarterName = @Quarter
			AND CR.CourseName = @CourseName
			AND C.[YEAR] = @Year
			AND C.Section = @Section)

SET @S_ID = (Select StudentID
			FROM tblSTUDENT
			WHERE StudentFname = @Fname
			AND StudentLname = @Lname
			AND StudentBirth = @Birth)

INSERT INTO tblCLASS_LIST (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, @Grade, @RegDate, @RegFee)
go

