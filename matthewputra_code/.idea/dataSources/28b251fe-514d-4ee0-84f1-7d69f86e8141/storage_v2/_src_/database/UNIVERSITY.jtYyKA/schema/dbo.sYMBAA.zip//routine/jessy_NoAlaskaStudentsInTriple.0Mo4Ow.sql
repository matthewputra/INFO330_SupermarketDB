/* 1) Write the SQL to create a computed column to track #Info credits above 3.4 for each student */

/* CREATE FUNCTION fn_ */

/* 2) Business Rule: "No student older than 23 from Alaska can be assigned a dorm room on West Campus of dorm room type 'Triple'"  */

CREATE FUNCTION jessy_NoAlaskaStudentsInTriple()
RETURNS INT
AS
BEGIN

DECLARE @Ret INT = 0
IF EXISTS (select *
		   from tblSTUDENT_DORMROOM SD
			   JOIN tblSTUDENT S ON S.StudentID = SD.StudentID
			   JOIN tblDORMROOM D ON D.DormRoomID = SD.DormRoomID
			   JOIN tblDORMROOM_TYPE DT ON DT.DormRoomTypeID = D.DormRoomTypeID
			where DATEDIFF(DAY, S.StudentBirth, GetDate()) > 23 * 365
			AND S.StudentPermState = 'Alaska, AK'
			AND DT.DormRoomTypeName = 'Triple')
	BEGIN
	SET @Ret = 1
	END
RETURN @RET
END
go

