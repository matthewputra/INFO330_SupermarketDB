CREATE PROCEDURE updEndDateStaffPosition
@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@PositionName varchar(30),
@PositionTypeName varchar(30),
@NewEndDate date

AS

DECLARE @S_ID INT, @P_ID INT

SET @S_ID = (SELECT StaffID
    FROM tblSTAFF
    WHERE StaffFname = @Fname
    AND StaffLname = @Lname
    AND StaffBirth = @Birth)

SET @P_ID = (SELECT PositionID
    FROM tblPOSITION P
        JOIN tblPOSITION_TYPE PT on P.PositionTypeID = PT.PositionTypeID
    WHERE P.PositionName = @PositionName
    AND PT.PositionTypeName = @PositionTypeName)

BEGIN TRAN A1
UPDATE tblSTAFF_POSITION
SET EndDate = @NewEndDate
WHERE StaffID = @S_ID
AND PositionID = @P_ID
COMMIT TRAN A1
go

