
CREATE FUNCTION fn_NoAssProf()
RETURNS INTEGER
AS 
BEGIN

DECLARE @RET INT = 0
IF EXISTS (SELECT *
			FROM tblINSTRUCTOR_TYPE IT 
				JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON  IT.InstructorTypeID = IIT.InstructorTypeID
				JOIN tblINSTRUCTOR I ON IIT.InstructorID = I.InstructorID
				JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID = IC.InstructorID
				JOIN tblCLASS C ON IC.ClassID = C.ClassID
				JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
				JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID 
			WHERE IT.InstructorTypeName LIKE '%Assistant Pro%'
			AND CR.CourseNumber LIKE '5__'
			AND D.DeptName LIKE '%Geo%'
			AND C.[YEAR] > '2018')
SET @RET = 1
RETURN @RET 
END
go

