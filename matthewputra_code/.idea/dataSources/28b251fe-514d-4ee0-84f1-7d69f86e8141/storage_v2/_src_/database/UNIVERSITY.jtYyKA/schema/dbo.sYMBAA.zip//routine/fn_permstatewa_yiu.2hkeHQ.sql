
	create function fn_permstatewa_yiu()
	returns int 
	as 
	begin
		declare @ret int = 0
			if exists
			(select *
			FROM tblSTUDENT S 
			JOIN tblCLASS_LIST CL on s.studentid = cl.StudentID
			Where s.StudentPermState = 'Washington, WA'
			AND cl.registrationfee >= '495'
			)

			set @ret = 1
	return @ret 
	end
    go

