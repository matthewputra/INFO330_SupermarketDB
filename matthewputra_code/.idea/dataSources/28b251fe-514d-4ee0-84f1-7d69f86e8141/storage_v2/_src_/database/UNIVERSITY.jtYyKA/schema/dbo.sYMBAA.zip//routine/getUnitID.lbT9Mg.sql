CREATE PROCEDURE getUnitID
@UnitroomName VARCHAR(50),
@UnitID INT OUTPUT
AS 
SET @UnitID = (SELECT UnitID 
			FROM UNIT
			WHERE UnitName = @UnitroomName
			)
go

