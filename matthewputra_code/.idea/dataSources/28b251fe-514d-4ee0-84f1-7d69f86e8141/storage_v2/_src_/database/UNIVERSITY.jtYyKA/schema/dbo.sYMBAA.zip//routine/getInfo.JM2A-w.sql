CREATE PROCEDURE getInfo
    @Fname VARCHAR(20),
    @Lname VARCHAR(20),
    @Birthdate DATE,
    @S_ID INT OUTPUT 
AS
SET @S_ID = (SELECT StudentID 
			FROM STUDENT
			WHERE Fname = @Fname	
			AND Lname = @Lname
			AND Birthdate = @Birthdate)
go

