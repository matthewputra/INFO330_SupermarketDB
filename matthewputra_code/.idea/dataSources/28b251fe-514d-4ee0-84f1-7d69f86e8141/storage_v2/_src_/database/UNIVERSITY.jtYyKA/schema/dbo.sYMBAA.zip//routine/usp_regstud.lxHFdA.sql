CREATE PROCEDURE usp_regstud
@Fname varchar (30),
@Lname varchar (30),
@DOB date,
@Grade varchar (2) = 'NA',
@ClassID INT
AS
DECLARE @StudentID INT
 
SET @StudentID = (SELECT StudentID FROM tblSTUDENT WHERE StudentFname = @Fname
        AND StudentLName = @Lname
        AND StudentBirth = @DOB)
 
INSERT INTO tblCLASS_LIST (StudentID, ClassID, Grade, RegistrationDate)
VALUES (@StudentID, @ClassID, @Grade, GetDate())

IF @@ERROR <> 0
    ROLLBACK TRAN G1
ELSE
    COMMIT TRAN G1
go

