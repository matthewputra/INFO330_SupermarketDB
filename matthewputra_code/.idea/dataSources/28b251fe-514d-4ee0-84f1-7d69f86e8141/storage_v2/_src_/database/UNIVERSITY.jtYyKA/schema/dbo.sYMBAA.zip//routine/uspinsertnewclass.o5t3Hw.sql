create procedure uspinsertnewclass
@CouName varchar (50),
@Year char(4),
@Section char(3),
@Quarter varchar(10),
@Classroom varchar(50),
@Schedule varchar (20)

AS
    DECLARE @COURSEID AS INT,
        @QUARTERID AS INT,
        @CLASSROOMID AS INT,
        @SCHEDULEID AS INT
set @courseid = (select courseid from tblCourse where CourseName = @CouName)
set @quarterid = (select quarterid from tblquarter where quartername = @quarter)
set @classroomid = (select classroomid from tblclassroom where classroomname = @classroom)
set @scheduleid = (select scheduleid from tblschedule where schedulename = @schedule)

insert into tblClass (CourseID, QuarterID, YEAR, classroomID, ScheduleID, Section)
Values (@CourseID, @QuarterID, @Year, @ClassRoomID, @ScheduleID, @Section)
go

