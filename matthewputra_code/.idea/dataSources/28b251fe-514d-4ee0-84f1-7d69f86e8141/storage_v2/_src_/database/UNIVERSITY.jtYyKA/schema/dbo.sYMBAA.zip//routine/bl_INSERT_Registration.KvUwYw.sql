
CREATE PROCEDURE bl_INSERT_Registration
@Fname varchar(30),
@Lname varchar(30),
@Birth Date,
@RegFee Numeric(10,2),
@RegDate Date,
@Grade Numeric(2, 1) = NULL,
@CourseName varchar(50),
@Year char(4),
@Section Varchar(4),
@Quarter varchar(30)

AS

DECLARE @C_ID INT
DECLARE @S_ID INT

SET @C_ID = (SELECT ClassID
            FROM tblClass C
                JOIN tblQuarter Q ON C.QuarterID = Q.QuarterID
                JOIN tblCourse CR ON C.CourseID = CR.CourseID
            WHERE Q.QuarterName = @Quarter
            AND CR.CourseName = @CourseName
            AND C.[Year] = @Year
            AND C.Section = @Section)

SET @S_ID = (SELECT StudentID 
            FROM tblStudent
            WHERE StudentFname = @Fname
            AND StudentLname = @Lname
            AND StudentBirth = @Birth)

INSERT INTO tblClass_List (ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, @Grade, @RegDate, @RegFee)

go

