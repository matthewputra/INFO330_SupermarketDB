
CREATE FUNCTION fn_EBMaxFee()
RETURNS INT
AS
BEGIN
DECLARE @RET INT = 0
IF EXISTS (SELECT S.StudentID
		   FROM tblSTUDENT S 
		    JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
		   WHERE S.StudentPermState = 'Washington, WA'
			AND CL.RegistrationFee > 495
		   GROUP BY S.StudentID)

		SET @RET = 1

RETURN @RET
END
go

