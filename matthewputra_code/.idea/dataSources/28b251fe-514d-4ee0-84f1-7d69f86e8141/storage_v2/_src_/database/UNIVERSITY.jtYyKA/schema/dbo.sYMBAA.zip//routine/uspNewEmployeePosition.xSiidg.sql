CREATE PROCEDURE uspNewEmployeePosition
@Pname VARCHAR(50),
@EFname VARCHAR(50),
@ELame VARCHAR(50),
@EBdate VARCHAR(50)
AS
DECLARE @EID INT, @PID INT
SET @EID = (SELECT EmpID
            FROM tblEMPLOYEE
            WHERE EmpFname = @EFname
            AND EmpLname = @ELame
            AND EmpBirthDate = @EBdate
)

SET @PID = (SELECT PositionID
            FROM tblPOSITION
            WHERE PositionName = @Pname
)
INSERT INTO tblEMPLOYEE_POSITION(EmpID, PositionID, BeginDate, EndDate)
VALUES(@EID, @PID)
go

