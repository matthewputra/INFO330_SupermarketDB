CREATE PROCEDURE usp_newStudentInClass
@Fname varchar(20),
@Lname varchar(20),
@Birth date,
@CName varchar(20),
@QName varchar(20),
@year char(4),
@RegFee numeric(6,2)
AS
    DECLARE @C_ID INT, @S_ID INT
SET @C_ID = (SELECT ClassID FROM tblCLASS C
    JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
    JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
    WHERE CourseName = @CName
    AND QuarterName = @QName
    AND YEAR = @year)
SET @S_ID = (SELECT StudentID FROM tblSTUDENT
    WHERE StudentFname = @Fname
    AND StudentLname = @Lname
    AND StudentBirth = @Birth)
INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES (@C_ID, @S_ID, NULL, GETDATE(), @RegFee)
go

