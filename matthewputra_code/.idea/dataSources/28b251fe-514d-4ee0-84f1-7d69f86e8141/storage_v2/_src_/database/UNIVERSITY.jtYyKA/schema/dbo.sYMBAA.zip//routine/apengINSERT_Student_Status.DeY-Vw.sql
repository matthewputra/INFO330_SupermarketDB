CREATE PROCEDURE apengINSERT_Student_Status

@Fname varchar(30),
@Lname varchar(30),
@Birth DATE,
@Status varchar(30),
@BeginDate DATE,
@EndDate DATE

AS

DECLARE @StuID INT
DECLARE @StatID INT

SET @StuID = (SELECT StudentID FROM tblSTUDENT WHERE StudentFname = @Fname AND StudentLname = @Lname AND StudentBirth = @Birth)
SET @StatID = (SELECT StatusID FROM tblSTATUS WHERE StatusName = @Status)

INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate)
Values(@StuID, @StatID, @BeginDate, @EndDate)
go

