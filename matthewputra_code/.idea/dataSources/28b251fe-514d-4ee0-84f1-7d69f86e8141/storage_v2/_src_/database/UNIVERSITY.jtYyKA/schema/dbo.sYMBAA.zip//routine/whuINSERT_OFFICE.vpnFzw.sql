CREATE PROCEDURE whuINSERT_OFFICE
@BlgName VARCHAR(50),
@OT_Name VARCHAR(50), 
@OName VARCHAR(50)
AS
DECLARE @OT_ID INT, @B_ID INT

/*
SET @B_ID = (SELECT BuildingID FROM tblBUILDING WHERE BuildingName = @BlgName)
*/

-- nested procedure goes below: 
EXEC whuGetBuidlingID
@Building = @BlgName ,
@BldgID = @B_ID OUTPUT

-- error handling goes below: example of RAISERROR
IF @B_ID IS NULL
	BEGIN
		PRINT ('This is an improptu message of RAISERROR')
		RAISERROR ('@B_ID is null; the INSERT statement is being terminated', 11, 1)
		PRINT ('This is after RAISERROR but before RETURN')
	END

/*
SET @OT_ID = (SELECT OfficeTypeID FROM tblOFFICE_TYPE WHERE OfficeTypeName = @OT_Name)
*/
EXEC whuGetOfficeTypeID
@OffType = @OT_Name ,
@OffTypeID = @OT_ID OUTPUT

-- error handling goes below: example of THROW
IF @OT_ID IS NULL
	BEGIN
		PRINT ('System cannot locate ID value for the building name entered');
		THROW 50445, '@B_ID is null; the INSERT statement is being terminated', 1;
		PRINT 'This is after THROW'
		RETURN
	END

INSERT INTO tblOFFICE(OfficeName, OfficeTypeID, BuildingID)
VALUES(@OName, @OT_ID, @B_ID)
go

