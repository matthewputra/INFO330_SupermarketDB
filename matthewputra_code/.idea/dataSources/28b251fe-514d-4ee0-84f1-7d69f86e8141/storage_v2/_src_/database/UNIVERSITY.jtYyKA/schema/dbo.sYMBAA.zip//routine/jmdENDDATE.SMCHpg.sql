CREATE PROCEDURE jmdENDDATE
@F varchar(30),
@L varchar(30),
@DOB varchar(30),
@PosName varchar(30),
@NewEndDate DATE,
@DEPTName varchar(30),
@begin DATE
as
Declare @sid int, @pid int, @dit int

Set @sid = (select staffid from tblstaff where stafffname = @f and stafflname = @l and staffbirth = @DOB)
Set @pid = (select positionid from tblPosition where positionname = @posname)
Set @dit = (select deptid from tbldepartment where deptname = @deptname)

Begin tran wassup
Update tblStaff_position
Set enddate = @NewEndDate
Where staffid = @sid and positionid = @pid
Commit tran wassup
go

