Create Procedure pInsPet
    @PetName VarChar(50),
    @PetTypeName VarChar(50),
    @CountryName VarChar(50),
    @TempName VarChar(50),
    @DOB Date,
    @GenderName Varchar(50)
As 
Begin 
    Declare @PT_ID int, @C_ID int, @T_ID int, @G_ID int
    Exec pGetPetTypeID @PetTypeName = @PetTypeName, @PetTypeID = @PT_ID output
    If @PT_ID is null
    Begin
        RaisError('Invalid Pet type name', 11, 1)
        return
    END
    Exec pGetCountryID @CountryName = @CountryName, @CountryID = @C_ID output
    If @C_ID is null
    Begin
        RaisError('Invalid Country name', 11, 1)
        return
    End 
    Exec pGetTempID @TempName = @TempName, @TempID = @T_ID output
    If @T_ID is null
    Begin 
        RaisError('Invalid Temperament name', 11, 1)
        return
    End
    Exec pGetGenderID @GenderName, @GenderID = @G_ID output
    If @G_ID is null
    Begin
        RaisError('Invalid Gender name', 11, 1)
        return
    End

    Begin Tran G1
    Insert Into PET(PetName, PetTypeID, CountryID, TempID, DOB, GenderID)
    Values (@PetName, @PT_ID, @C_ID, @T_ID, @DOB, @G_ID)
    If @@ERROR <> 0
        Rollback Tran G1
    Else
        Commit Tran G1
End
go

