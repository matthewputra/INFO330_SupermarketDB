CREATE PROCEDURE get_StudentID
@StudentFname VARCHAR(50),
@StudentLname VARCHAR(50),
@BirthDate DATE,
@S_ID INT OUTPUT
AS 

Set @S_ID = (SELECT StudentID FROM tblSTUDENT Where StudentFname = @StudentFname AND StudentLname = @StudentLname AND StudentBirth = @BirthDate)
go

