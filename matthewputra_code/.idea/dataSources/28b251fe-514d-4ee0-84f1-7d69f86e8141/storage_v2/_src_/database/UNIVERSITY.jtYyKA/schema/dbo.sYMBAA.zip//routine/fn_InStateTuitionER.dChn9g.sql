CREATE FUNCTION fn_InStateTuitionER()
RETURNS INT
AS
BEGIN
	DECLARE @RET INT = 0
	IF EXISTS
	(
		SELECT *
		FROM tblSTUDENT S
			JOIN tblCLASS_LIST CL ON CL.StudentID = S.StudentID
		WHERE S.StudentPermState = 'Washington, WA'
		AND CL.RegistrationFee > 495

	)
	SET @RET = 1
RETURN @RET
END
go

