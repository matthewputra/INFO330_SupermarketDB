CREATE PROCEDURE ym_GetStaffID
@Fname varchar(60),
@Lname varchar(60),
@BDate Date,
@Staffy INT OUTPUT
AS

SET @Staffy = (SELECT StaffID 
			FROM tblSTAFF 
			WHERE StaffFName = @Fname
			AND StaffLName = @Lname
			AND StaffBirth = @BDate)
go

