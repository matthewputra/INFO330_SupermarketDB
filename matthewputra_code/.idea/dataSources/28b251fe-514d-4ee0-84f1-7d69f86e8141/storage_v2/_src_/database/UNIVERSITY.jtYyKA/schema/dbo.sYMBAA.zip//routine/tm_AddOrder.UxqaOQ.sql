CREATE PROCEDURE tm_AddOrder
@CustFName varchar(50),
@CustLName varchar(50),
@CustDOB Date,
@Quantity int,
@OrderDate DATE,
@ProdName varchar(50)
AS
    DECLARE @CID INT, @PID INT

EXEC tm_getCustID
    @Fname = @CustFName,
    @Lname = @CustLName,
    @dob = @CustDOB,
    @CustID = @CID output

IF @CID IS NULL
BEGIN
    PRINT('HEY @CID IS NULL')
    RAISERROR('@CID Cannot be null', 11, 1)
end

EXEC tm_getProductID
    @ProductName = @ProdName,
    @ProductID = @PID output

IF @PID IS NULL
BEGIN
    PRINT('HEY @PID IS NULL')
    RAISERROR('@PID Cannot be null', 11, 1)
end

BEGIN TRAN G1
INSERT INTO ORDERS(OrderDate, CustID, ProdID, Quantity)
VALUES(@OrderDate, @CID, @PID, @Quantity)
IF @@ERROR<>0
BEGIN
    PRINT 'TRAN G1 is terminating due to some error'
    ROLLBACK TRAN G1
    END
    ELSE
    COMMIT TRAN G1
go

