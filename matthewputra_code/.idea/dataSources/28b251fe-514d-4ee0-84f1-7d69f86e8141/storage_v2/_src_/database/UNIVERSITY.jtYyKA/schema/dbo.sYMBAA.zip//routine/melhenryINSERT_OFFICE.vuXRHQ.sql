CREATE PROCEDURE melhenryINSERT_OFFICE
@BldgName VARCHAR(50),
@OT_Name VARCHAR(50),
@O_Name VARCHAR(50)

AS

DECLARE @B_ID INT, @OT_ID INT

SET @B_ID = (SELECT BuildingID FROM tblBuilding WHERE BuildingName = @BldgName)
/*Error handling goes here, Example of RAISERROR*/

IF @B_ID IS NULL
    BEGIN
        PRINT 'Hey, system cannot locate an ID value for the building given'
        RAISERROR ('@B_ID is NULL; this INSERT statement is being terminated', 11,1)
        RETURN /*Ends the transaction*/
    END

SET @OT_ID = (SELECT OfficeTypeID FROM tblOFFICE_TYPE WHERE OfficeTypeName = @OT_Name)

IF @OT_ID IS NULL
    BEGIN
        PRINT 'Hey, system cannot locate an ID value for the office type given';
        THROW 50445, '@OT_ID is NULL; this INSERT statement is being terminated', 1;
    END

INSERT INTO tblOFFICE (OfficeName, OfficeTypeID, BuildingID)
VALUES (@O_Name, @OT_ID, @B_ID)
go

