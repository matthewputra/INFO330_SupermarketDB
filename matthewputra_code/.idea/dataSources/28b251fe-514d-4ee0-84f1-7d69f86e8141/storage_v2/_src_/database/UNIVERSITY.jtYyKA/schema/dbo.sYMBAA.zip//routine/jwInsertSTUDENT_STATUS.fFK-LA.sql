CREATE PROCEDURE jwInsertSTUDENT_STATUS
@Fname varchar(30),
@Lname varchar(30),
@Statname varchar(30),
@BDate Date,
@EDate Date

AS

DECLARE @StudID INT, @StatID INT, @BegDate DATE, @EndDate DATE

SET @StudID = (SELECT StudentID FROM tblSTUDENT
				WHERE StudentFname = @Fname AND
				StudentLname = @Lname)
SET @StatID = (SELECT StatusID FROM tblSTATUS
				WHERE StatusName = @Statname)

SET @BegDate = @BDate
SET @EndDate = @EDate

INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID,
								BeginDate, EndDate)
VALUES(@StudID, @StatID, @BDate, @EDate)
go

