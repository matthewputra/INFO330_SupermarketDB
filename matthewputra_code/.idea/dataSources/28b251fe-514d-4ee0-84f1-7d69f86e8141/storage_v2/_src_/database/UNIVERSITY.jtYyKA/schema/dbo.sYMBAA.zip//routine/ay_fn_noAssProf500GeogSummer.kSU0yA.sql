CREATE FUNCTION ay_fn_noAssProf500GeogSummer()
RETURNS INTEGER --we almost always want to return integer in businessrules
AS
BEGIN
    DECLARE @Ret INT = 0 --int type match above, assume no violation (0)
    IF
    EXISTS (SELECT * FROM tblINSTRUCTOR I
        JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON I.InstructorID = IIT.InstructorID
        JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID = IT.InstructorTypeID
        JOIN tblINSTRUCTOR_CLASS IC ON I.InstructorID = IC.InstructorID
        JOIN tblCLASS C ON C.ClassID = IC.ClassID
        JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
        JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
        JOIN tblDEPARTMENT D ON D.DeptID = CR.DeptID
        WHERE IT.InstructorTypeName = 'Assistant Professor'
        AND Q.QuarterName = 'Summer'
        AND C.[YEAR] >= '2018'
        AND D.DeptName = 'Geography'
        AND CR.CourseNumber LIKE '5%' )   --(Logic goes here, violation of bad data)
    SET @Ret = 1 --if we find violation we return 1
RETURN @Ret
END
go

