CREATE VIEW vwSomeNewView
AS
SELECT C.CollegeName, CS.[Year], L.LocationName, COUNT(*) AS NumClasses
FROM tblCOLLEGE C
JOIN tblDEPARTMENT D ON C.CollegeID = D.CollegeID
JOIN tblCOURSE CR ON D.DeptID = CR.DeptID
JOIN tblCLASS CS ON CR.CourseID = CS.CourseID
JOIN tblCLASSROOM CM ON CS.ClassroomID = CM.ClassroomID
JOIN tblBUILDING B ON CM.BuildingID = B.BuildingID
JOIN tblLOCATION L ON B.LocationID = L.LocationID
GROUP BY C.CollegeName, CS.[Year], L.LocationName
go

