CREATE PROCEDURE nickbonn_NewStaffPosition
@Firsty varchar(60),
@Lasty varchar(60),
@Birthy Date,
@DeptName varchar(75),
@PosName varchar(50),
@Begin Date,
@End DATE
AS 
DECLARE @S_ID INT, @D_ID INT, @P_ID INT

EXEC nickbonn_GetStaffID
@Fname = @Firsty,
@Lname = @Lasty,
@BDate = @Birthy,
@Staffy = @S_ID OUTPUT

--error-handle in case @S_ID is null
IF @S_ID IS NULL 
    BEGIN 
        PRINT 'Hey SID is null and the following transaction will fail'
        RAISERROR ('@S_ID cannot be NULL', 11, 1)
        RETURN 
    END

SET @D_ID = (SELECT DeptID from tblDEPARTMENT WHERE DeptName = @DeptName)
--error-handle in case @D_ID is null


SET @P_ID = (SELECT PositionID from tblPOSITION WHERE PositionName = @PosName)
--error-handle in case @P_ID is null

--Create explicit transaction

BEGIN TRAN G1
INSERT INTO tblStaff_Position (StaffID, DeptID, PositionID, BeginDate, EndDate)
VALUES (@S_ID, @D_ID, @P_ID, @Begin, @End)
--Check if there is a train wreck ahead (Other transactions are failing around us)
IF @@ERROR <>0
    ROLLBACK TRAN G1
ELSE 
    COMMIT TRAN G1
go

