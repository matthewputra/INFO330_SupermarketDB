CREATE PROC uspStudentReg
	@Fname	varchar(20),
	@Lname	varchar(20),
	@Bdate	Date,
	@Course varchar(50),
	@Quarter varchar(20),
	@Year	char(4),
	@Section	char(3),
	@RDate	Date,
	@RegFee	numeric(6,2)
AS
	DECLARE @S_ID INT, @C_ID INT
	SET @S_ID = (SELECT StudentID FROM tblSTUDENT S
				 WHERE S.StudentFname = @Fname
				 AND S.StudentLname = @Lname
				 AND S.StudentBirth = @BDate)
	SET @C_ID = (SELECT ClassID FROM tblCLASS CS
				 JOIN tblQUARTER Q ON CS.QuarterID = CS.QuarterID
				 JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
				 WHERE Q.QuarterName = @Quarter
				 AND CR.CourseName = @Course
				 AND CS.[YEAR] = @Year
				 AND CS.Section = @Section)
BEGIN TRAN studentreg1
	INSERT INTO tblCLASS_LIST
		(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
	values (@C_ID, @S_ID, NULL, @RDate, @RegFee)
COMMIT TRAN studentreg1

go

