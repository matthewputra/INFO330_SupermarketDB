/* 

1) Write the SQL to create a computed column to track #Info credits above 3.4 for each student
2) Business Rule: "No student older than 23 from Alaska can be assigned a dorm room on West Campus of dorm room type 'Triple'"  */
CREATE FUNCTION info_creds_student(@PK INT)
RETURNS INT
AS
BEGIN 
DECLARE @RET INT =
(SELECT SUM(CO.Credits)
	FROM tblCOURSE CO
		JOIN tblCLASS C ON CO.CourseID = C.CourseID
		JOIN tblCLASS_LIST CL ON C.ClassID = CL.ClassID
		JOIN tblSTUDENT S ON CL.StudentID = S.StudentID

WHERE S.StudentID = @PK
AND CO.CourseName LIKE '%INFO___%'
AND CL.Grade > 3.4
)
RETURN @RET
END
go

