create function fn_NumClasses_Course(@PK INT)
Returns INT
AS
Begin
	Declare @Ret INT = (select COUNT(CR.CourseID) As NumClasses
						from tblCOURSE CR
							JOIN tblCLASS C on CR.CourseID = C.CourseID
							JOIN tblCLASSROOM CM on C.ClassroomID = CM.ClassroomID
							JOIN tblBUILDING B ON CM.BuildingID = B.BuildingID
						where CR.CourseID = @PK
							AND C.[YEAR] > '1953'
						)
	
	RETURN @ret
END
go

