CREATE FUNCTION fn_InfoCredits34Dave(@PK INT)
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = (
        SELECT SUM(CR.Credits) AS InfoCreditsAbove34
        FROM tblSTUDENT S
            JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
            JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
            JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
            JOIN tblDEPARTMENT D ON CR.DeptID = D.DeptID
            JOIN tblCOLLEGE C ON D.CollegeID = C.CollegeID
        WHERE S.StudentID = @PK
        AND CollegeName = 'Information School'
        AND CL.Grade > 3.4
        GROUP BY S.StudentID
        )
RETURN @RET
END
go

