CREATE FUNCTION fn_CheckSeniorEmployee()
RETURNS INT
AS
    BEGIN
        DECLARE @Ret INT = 0
        IF EXISTS(SELECT CJT.JobTaskID
            FROM EMPLOYEE AS E
            JOIN EMPLOYEE_SKILL AS ES ON E.EmpID = ES.EmpID
            JOIN LEVEL AS L ON ES.LevelID = L.LevelID
            JOIN SKILL AS S ON ES.SkillID = S.SkillID
            JOIN SKILL_TYPE AS ST ON S.SkillTypeID = ST.SkillTypeID
            JOIN CUST_JOB_TASK AS CJT ON ES.EmpSkillID = CJT.EmpSkillID
            JOIN JOB AS J ON CJT.JobID = J.JobID
            JOIN JOB_TYPE AS JT ON J.JobTypeID = JT.JobTypeID
            JOIN EQUIPMENT AS E ON CJT.EquipID = E.EquipID
            JOIN EQUIPMENT_TYPE AS ET ON E.EquipTypeID = ET.EquipTypeID
            WHERE JT.JobTypeName = 'high-rise residential' AND
                  ET.EquipTypeName = 'hydraulic lift' AND
                  J.JobBeginDate > 'November 11, 2021' AND
                  (L.LevelName != 'Senior' OR ST.SkillTypeName != 'Heavy Machinery'))
        SET @Ret = 1
        RETURN @Ret
    END
go

