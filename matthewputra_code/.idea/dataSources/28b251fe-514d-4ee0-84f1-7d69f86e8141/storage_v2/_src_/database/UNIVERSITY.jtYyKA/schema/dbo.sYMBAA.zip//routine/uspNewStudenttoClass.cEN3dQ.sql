CREATE PROCEDURE uspNewStudenttoClass
@FName varchar(20),
@LName varchar(20),
@PermAdd varchar(100),
@PermCity varchar(50),
@PermState varchar(20),
@PermZip INT,
@Birth DATE,
@SSN INT,
@CourseID INT,
@QuarterID INT,
@Year char(4),
@ClassroomID INT,
@ScheduleID INT,
@Section varchar(20),
@Grade FLOAT,
@RegDate DATE,
@RegFee MONEY
AS
DECLARE @ClassID INT, @StudentID INT
SET @ClassID = (SELECT ClassID
				FROM tblCLASS
				WHERE CourseID = @CourseID
					AND QuarterID = @QuarterID
					AND [YEAR] = @Year
					AND ClassroomID = @ClassroomID
					AND ScheduleID = @ScheduleID
					AND Section	= @Section)
SET @StudentID = (SELECT StudentID
				  FROM tblSTUDENT
				  WHERE StudentFname = @FName
						AND StudentLname = @LName
						AND StudentPermAddress = @PermAdd
						AND StudentPermCity = @PermCity
						AND StudentPermState = @PermState
						AND StudentPermZip = @PermZip
						AND StudentBirth = @Birth
						AND StudentSocSecNum = @SSN)

INSERT INTO tblCLASS_LIST(ClassID, StudentID, Grade, RegistrationDate, RegistrationFee)
VALUES(@ClassID, @StudentID, @Grade, @RegDate, @RegFee)
go

