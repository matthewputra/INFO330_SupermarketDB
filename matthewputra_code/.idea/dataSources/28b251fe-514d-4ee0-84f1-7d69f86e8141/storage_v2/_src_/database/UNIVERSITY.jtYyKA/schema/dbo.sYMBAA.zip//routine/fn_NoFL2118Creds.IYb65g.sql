CREATE FUNCTION fn_NoFL2118Creds()
RETURNS INT 
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (SELECT *
				FROM tblSTUDENT S
					JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
					JOIN tblCLASS CS ON CL.ClassID = CS.ClassID
					JOIN tblCOURSE CR ON CS.CourseID = CR.CourseID
				WHERE S.StudentPermState = 'Florida, FL'
				AND S.StudentBirth > DATEADD(Year, -21, GETDATE())
				AND CL.RegistrationDate >DATEADD(Month, -4, GETDATE())
				GROUP BY S.StudentID
				HAVING SUM(CR.Credits) > 18)
	SET @Ret = 1
RETURN @Ret
END
go

