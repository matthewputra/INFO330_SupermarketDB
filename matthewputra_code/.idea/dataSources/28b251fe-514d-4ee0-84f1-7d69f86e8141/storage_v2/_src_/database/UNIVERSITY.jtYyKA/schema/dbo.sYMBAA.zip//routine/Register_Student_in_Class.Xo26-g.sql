CREATE   PROCEDURE Register_Student_in_Class
@StudFName varchar(60),
@StudLName varchar(60),
@CrsName varchar(75),
@StudentDateOfBirth date,
@RegistrationDate date,
@RegistrationFees numeric(10,2)
AS
DECLARE @C_ID INT
SET @C_ID = (
SELECT CLs.ClassID FROM tblCLASS Cls join tblCOURSE Co on Cls.CourseID =Co.CourseID WHERE Co.CourseName = @CrsName )
-- error-handling --> we know the entire procedure will fail at the transaction if this is NULL
IF @C_ID IS NULL
BEGIN
PRINT 'Error: Course does not exist!!'
RAISERROR ('@C_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END
DECLARE @S_ID INT
SET @S_ID = (SELECT ST.StudentID FROM tblSTUDENT ST WHERE ST.StudentFname= '@StudFName' and ST.StudentLname ='@StudLName' and ST.StudentBirth ='@StudentDateOfBirth' )
-- error-handling --> we know the entire procedure will fail at the transaction if this is NULL
IF @S_ID IS NULL
BEGIN
PRINT 'Error: Student does not exist!!'
RAISERROR ('@S_ID cannot be NULL; statement is being terminated', 11,1)
RETURN
END
BEGIN TRAN G1
INSERT INTO tblCLASS_LIST(ClassID,StudentID,RegistrationDate,RegistrationFee)
VALUES (@C_ID,@S_ID,@RegistrationDate,@RegistrationFees)
-- error-handling
IF @@ERROR <> 0
BEGIN
PRINT '@@ERROR is showing a number <> 0; transaction is being terminated'
ROLLBACK TRAN G1
END
ELSE
COMMIT TRAN G1
go

