CREATE PROCEDURE uspINSERTINTOSTAFFPOSITION
     -- the following are for StaffID
    @FirstName varchar(20),
    @LastName varchar(20),
    @Birth DATETIME,
    -- the following is for PositionID
    @PosName varchar(30),
    -- the following is for DeptID
    @DName varchar(30),
     -- the rest are ambiguous
    @Begin DATETIME,
    @End DATETIME
AS
     DECLARE @S_ID INT, @P_ID INT, @D_ID INT
     SET @S_ID = (
         SELECT StaffID
         FROM tblSTAFF
         WHERE StaffFName = @FirstName
         AND StaffLName = @LastName
         AND StaffBirth = @Birth
         )
     SET @P_ID = (
         SELECT PositionID
         FROM tblPOSITION
         WHERE PositionName = @PosName
        )
     SET @D_ID = (
         SELECT DeptID
         FROM tblDEPARTMENT
         WHERE DeptName = @DName
         )
     INSERT INTO tblSTAFF_POSITION(StaffID, PositionID, BeginDate, EndDate, DeptID)
     VALUES(@S_ID, @P_ID, @Begin, @End, @D_ID)
go

