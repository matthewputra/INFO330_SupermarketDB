CREATE PROCEDURE uspINSERTStaffPosition
@Fname varchar(20),
@Lname varchar(20),
@Pname varchar(50),
@Birth Date,
@BDate Date,
@EDate Date
AS
DECLARE @S_ID INT, @SP_ID INT
SET @S_ID = (SELECT StaffID FROM tblSTAFF WHERE StaffFName = @Fname
AND StaffLName = @Lname
AND StaffBirth = @Birth)
SET @SP_ID = (SELECT StaffPositionID FROM tblSTAFF_POSITION SP
	JOIN tblPOSITION P ON SP.PositionID = P.PositionID
	WHERE P.PositionName = @Pname)

BEGIN TRAN J1
INSERT INTO tblSTAFF_POSITION (StaffID, PositionID, BeginDate, EndDate)
Values (@S_ID, @SP_ID, @BDate, @EDate)
COMMIT TRAN J1
go

