CREATE PROCEDURE jwINSERT_StudentStatus
@Fname varchar(50),
@Lname varchar(50),
@email varchar(100),
@Stat varchar(50),
@Begin Date,
@End Date
AS
DECLARE @Student_ID INT, @Status_ID INT

EXECUTE jwGetStudentID
@StudFName = @Fname,
@StudLname = @Lname,
@Studmail = @email,
@StudID = @Student_ID OUTPUT


EXECUTE jwGetStatusID
@StatName = @Stat,
@StatID = @Status_ID OUTPUT;


IF @Student_ID IS NULL
	BEGIN
	RAISERROR('@Stu_ID cannot be NULL; Statement terminating', 11, 1)
	RETURN
	END

IF @Status_ID IS NULL
	BEGIN
	RAISERROR('@Stat_ID cannot be NULL; Statement terminating', 11, 1)
	RETURN
	END

INSERT INTO tblSTUDENT_STATUS (StudentID, StatusID, BeginDate, EndDate)
VALUES(@Student_ID, @Status_ID, @Begin, @End)
go

