CREATE PROCEDURE whuINSERT_INSTRUCTOR_CLASS
@Fname VARCHAR(20),
@Lname VARCHAR(20),
@Birth DATE,
@Course VARCHAR(20),
@Year CHAR(4),
@Quarter VARCHAR(20),
@Section CHAR(3)
AS
DECLARE @InstrID INT, @ClassID INT
SET @InstrID = (SELECT InstructorID FROM tblINSTRUCTOR 
				WHERE InstructorFName = @Fname
				AND InstructorLName = @Lname
				AND InstructorBirth = @Birth)
SET @ClassID = (SELECT ClassID FROM tblCLASS C
				JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
				JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
				AND CR.CourseName = @Course
				AND C.[YEAR] = @Year
				AND C.Section = @Section
				AND Q.QuarterName = @Quarter)
INSERT INTO tblINSTRUCTOR_CLASS(InstructorID, ClassID)  -- required columsn in th table, both pk and fk
VALUES (@InstrID, @ClassID)
go

