CREATE PROCEDURE melhenryGetStudentID
@S_Fname VARCHAR (50),
@S_Lname VARCHAR (50),
@B DATE,
@S_ID INT OUTPUT
AS
SET @S_ID = (SELECT StudentID
            FROM tblSTUDENT
            WHERE StudentFname = @S_Fname
            AND StudentLname = @S_Lname
            AND StudentBirth = @B)
go

