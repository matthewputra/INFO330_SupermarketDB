CREATE FUNCTION fnpermstatewa()
RETURNS INT
    AS
    BEGIN
        DECLARE @RET INT = 0
        IF EXISTS(SELECT S.StudentID, sum(cl.registrationfee)
            From tblClass_list cl
            inner join tblclass cs on cl.classid = cs.ClassID
            inner join tblcourse cr on cr.courseid = cr.CourseID
            inner join tblDepartment d on d.deptid = cr.deptid
            INNER JOIN tblCollege c on d.collegeid = c.collegeid
            inner join tblStudent s on cl.studentid = s.studentid
            where s.studentpermstate = 'Washington, WA'
            group by s.studentid
            having sum(cl.RegistrationFee) > 495)
        BEGIN
            SET @RET = 1
        end
        RETURN @RET
    end
go

