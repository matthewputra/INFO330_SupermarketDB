CREATE PROCEDURE jrav_INSERT_New_Staff
@Fname varchar(60),
@Lname varchar(60),
@Address varchar(120),
@City varchar(75),
@State varchar(25),
@Zip varchar(25),
@Birth Date,
@NetID varchar(20) = NULL,
@Email varchar(80) = NULL,
@Gender char(1),
@PositionName varchar(50),
@PositionStart Date,
@PositionEnd Date = NULL,
@Department varchar(75) = NULL

AS

DECLARE @P_ID INT
DECLARE @S_ID INT
DECLARE @D_ID INT

INSERT INTO tblSTAFF(StaffFName, StaffLName, StaffAddress, StaffCity, StaffState, StaffZip, StaffBirth, StaffNetID, StaffEmail, Gender)
VALUES (@Fname, @Lname, @Address, @City, @State, @Zip, @Birth, @NetID, @Email, @Gender)

SET @P_ID = (SELECT PositionID FROM tblPOSITION WHERE PositionName = @PositionName)
SET @S_ID = (SELECT StaffID
			FROM tblSTAFF
			WHERE StaffFName = @Fname
				AND StaffLName = @Lname
				AND StaffBirth = @Birth)
SET @D_ID = (SELECT DeptID FROM tblDEPARTMENT WHERE DeptName = @Department)

INSERT INTO tblSTAFF_POSITION (StaffID, PositionID, BeginDate, EndDate, DeptID)
VALUES (@S_ID, @P_ID, @PositionStart, @PositionEnd, @D_ID)
go

