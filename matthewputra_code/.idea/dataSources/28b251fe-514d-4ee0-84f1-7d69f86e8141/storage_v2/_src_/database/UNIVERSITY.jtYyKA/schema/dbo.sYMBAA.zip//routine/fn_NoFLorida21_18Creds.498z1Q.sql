CREATE FUNCTION fn_NoFLorida21_18Creds()
RETURNS varchar(50)
AS
BEGIN
	DECLARE @Ret INT = 0
	IF EXISTS (SELECT S.StudentID
				FROM  tblSTUDENT S
					JOIN tblCLASS_LIST CL ON S.StudentID = CL.StudentID
					JOIN tblCLASS C ON CL.ClassID = C.ClassID
					JOIN tblCOURSE CR ON C.CourseID = CR.CourseID
				WHERE S.StudentPermState = 'Florida, FL'
				AND S.StudentBirth > DATEADD(Year, -21, GETDATE())
				AND RegistrationDate > DATEADD(Month, -4, GETDATE())
				GROUP BY S.StudentID
				HAVING SUM(CR.Credits) > 18)
	SET @Ret = 1
RETURN @Ret
END
go

