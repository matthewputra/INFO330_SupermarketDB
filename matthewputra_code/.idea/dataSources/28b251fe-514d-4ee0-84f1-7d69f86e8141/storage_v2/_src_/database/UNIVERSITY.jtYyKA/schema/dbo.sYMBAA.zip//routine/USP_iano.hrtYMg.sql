CREATE PROCEDURE USP_iano
@Fname varchar(20),
@Lname varchar(20),
@Bdate date,
@PosName varchar(40)

AS
DECLARE @S_ID INT, @P_ID INT
SET @S_ID = (SELECT StaffID FROM tblStaff
    WHERE StaffFName = @Fname
        AND StaffLName = @Lname
        AND StaffBirth = @Bdate)
SET @P_ID = (SELECT PositionID FROM tblPOSITION
    WHERE PositionName = @PosName)

INSERT INTO tblSTAFF_POSITION(StaffID, PositionID)
VALUES (@S_ID, @P_ID)
go

