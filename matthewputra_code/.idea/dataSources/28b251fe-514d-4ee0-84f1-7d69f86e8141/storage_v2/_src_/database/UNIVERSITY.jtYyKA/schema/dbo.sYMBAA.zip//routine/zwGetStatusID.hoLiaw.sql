CREATE PROCEDURE zwGetStatusID
@StatusName VARCHAR(30),
@StatusID INT OUTPUT
AS
	SET @StatusID = (SELECT StatusID FROM tblSTATUS WHERE StatusName = @StatusName)
	RETURN
go

