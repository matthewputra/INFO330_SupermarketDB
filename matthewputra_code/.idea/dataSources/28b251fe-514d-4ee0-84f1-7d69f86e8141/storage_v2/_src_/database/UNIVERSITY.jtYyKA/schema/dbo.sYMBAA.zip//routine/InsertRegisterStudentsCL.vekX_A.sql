CREATE PROCEDURE InsertRegisterStudentsCL
@Fname varchar(25),
@Lname varchar(25),
@Birth date, 
@Course varchar(25), 
@Section varchar(5),
@Year varchar(25)
AS 
DECLARE @C_ID INT, @S_ID INT
SET @C_ID = (SELECT C.ClassID FROM tblCLASS C
			JOIN tblCOURSE CO ON C.CourseID = CO.CourseID
			JOIN tblQUARTER Q ON C.QuarterID = Q.QuarterID
			WHERE CourseName = @Course 
			AND Section = @Section 
			AND [Year] = @Year)
SET @S_ID = (SELECT StudentID FROM tblSTUDENT WHERE StudentFname = @Fname AND StudentLname = @Lname AND StudentBirth = @Birth)
INSERT INTO tblCLASS_LIST(C.ClassID, StudentID)
Values(@C_ID, @S_ID)
go

