CREATE FUNCTION fn_Calcie(@PK INT)
RETURNS Numeric(18,2)
    AS
BEGIN
    DECLARE @RET Numeric(18,2) = (SELECT sum(cr.credits)
        from tblClass_list cl
            inner join tblclass cs on cl.classid = cs.ClassID
            inner join tblcourse cr on cr.courseid = cr.CourseID
            inner join tblDepartment d on d.deptid = cr.deptid
            INNER JOIN tblCollege c on d.collegeid = c.collegeid
            inner join tblStudent s on cl.studentid = s.studentid
        WHERE s.studentid = @pk
        AND cl.grade > 3.4
    and c.collegename like '%Information%'
        group by s.studentid)
    return @RET
end
go

