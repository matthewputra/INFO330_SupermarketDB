CREATE FUNCTION fn_InfoCreditsStudents34(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = (select SUM(C.Credits)
					from tblCOURSE C
						JOIN tblDEPARTMENT D ON D.DeptID = C.DeptID
						JOIN tblCOLLEGE CO ON CO.CollegeID = D.CollegeID
						JOIN tblCLASS CL ON CL.CourseID = C.CourseID
						JOIN tblCLASS_LIST CLL ON CLL.ClassID = CL.ClassID
						JOIN tblSTUDENT S ON S.StudentID = CLL.StudentID
					where S.StudentID = @PK
					AND CO.CollegeName = 'Information School'
					AND CLL.Grade > 3.4
					GROUP BY S.StudentID, S.StudentFname, S.StudentLname)
	RETURN @Ret
END
go

