CREATE FUNCTION fn_noOneUnder41Dean_iSchool1()
RETURNS INT
AS
BEGIN
    DECLARE @RET INT = 0
        IF EXISTS(
            SELECT *
            FROM tblCOLLEGE C
                JOIN tblDEPARTMENT tD on C.CollegeID = tD.CollegeID
                JOIN tblSTAFF_POSITION tSP on tD.DeptID = tSP.DeptID
                JOIN tblPOSITION tP on tSP.PositionID = tP.PositionID
                JOIN tblSTAFF tS on tSP.StaffID = tS.StaffID
            WHERE C.CollegeName = 'Information School'
            AND tS.StaffBirth > DATEADD(Year, -41, GETDATE()))
    SET @RET = 1
RETURN @RET
END
go

