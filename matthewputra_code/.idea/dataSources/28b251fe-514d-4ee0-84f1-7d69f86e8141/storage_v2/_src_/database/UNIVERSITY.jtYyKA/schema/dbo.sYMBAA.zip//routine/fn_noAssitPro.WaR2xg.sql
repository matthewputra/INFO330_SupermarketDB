CREATE FUNCTION fn_noAssitPro()
RETURNS INTEGER --plural
AS
BEGIN
    DECLARE @Ret INT =0 --1.must match the type with RETURNS above.2. stands for return, best practice
    IF EXISTS(SELECT *
                FROM tblINSTRUCTOR I
                    JOIN tblINSTRUCTOR_INSTRUCTOR_TYPE IIT ON I.InstructorID=IIT.InstructorID
                    JOIN tblINSTRUCTOR_TYPE IT ON IIT.InstructorTypeID = IT.InstructorTypeID
                    JOIN tblINSTRUCTOR_CLASS IC on I.InstructorID = IC.InstructorID
                    JOIN tblCLASS C on IC.ClassID = C.ClassID
                    JOIN tblQUARTER Q on C.QuarterID = Q.QuarterID
                    JOIN tblCOURSE CR on C.CourseID = CR.CourseID
                    JOIN tblDEPARTMENT D on CR.DeptID = D.DeptID
                WHERE IT.InstructorTypeName='Assistant Professor'
                AND Q.QuarterName='Summer'
                AND C.[Year]='2018'
                AND D.DeptName='Geography'
                AND CR.CourseName LIKE '5%')--logic goes here!!-->write VIOLATION here.
    SET @Ret=1
RETURN @Ret
END
go

