create function fn_infocred (@pk int)

returns int

as begin 

	declare @ret int = 
	(select s.studentid
	from tblCOURSE c 
	join tblCLASS cs on c.CourseID = cs.CourseID
	join tblCLASS_LIST cl on cs.ClassID = cl.ClassID
	join tblSTUDENT s on cl.studentid = s.studentid

	where s.studentid = @pk
	and c.CourseName like '%INFO___%'
	AND cl.grade > 3.4 
	)

	return @ret
	end
go

