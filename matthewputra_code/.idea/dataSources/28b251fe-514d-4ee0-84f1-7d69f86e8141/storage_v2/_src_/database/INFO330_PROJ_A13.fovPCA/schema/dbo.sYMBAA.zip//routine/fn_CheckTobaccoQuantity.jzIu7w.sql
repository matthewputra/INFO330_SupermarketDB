CREATE FUNCTION fn_CheckTobaccoQuantity()
RETURNS INT
AS
    BEGIN
        DECLARE @Ret INT = 0
        IF EXISTS(SELECT SP.StoreID
            FROM tblStoreProduct AS SP
            JOIN tblProduct AS P ON SP.ProductID = P.ProductID
            JOIN tblProductType AS PT ON P.ProductTypeID = PT.ProductTypeID
            WHERE PT.ProductTypeName = 'tobacco'
            GROUP BY SP.StoreID
            HAVING SUM(SP.StoreProductQuantity) > 500)
        SET @Ret = 1
        RETURN @Ret
    END
go

