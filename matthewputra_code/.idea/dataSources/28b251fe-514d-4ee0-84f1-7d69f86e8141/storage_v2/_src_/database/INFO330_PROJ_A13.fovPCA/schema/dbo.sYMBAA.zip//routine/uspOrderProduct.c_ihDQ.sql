CREATE PROCEDURE uspOrderProduct
@companyname varchar(20),
@brandname varchar(20),
@producttypename varchar(20),
@productname varchar(20),
@cFname varchar(20),
@CLname varchar(20),
@Cbday DATE,
@Cstate varchar(20),
@ordertypename varchar (20),
@quantity INTEGER

AS DECLARE @p_id INT, @o_id INT

SET @p_id = (SELECT productid
				FROM tblProduct P 
				JOIN tblBrand B ON P.BrandID = B.BrandID
				JOIN tblProductType PT ON P.ProductTypeID = PT.ProductTypeID
				JOIN tblCompany C on B.CompanyID = C.CompanyID
				WHERE P.ProductName = @productname
				AND B.BrandName = @brandname
				AND C.CompanyName = @companyname
				AND PT.ProductTypeName = @producttypename
				)

SET @o_id = (SELECT orderiD		
				FROM tblOrder O 
				JOIN tblCustomer C on O.CustomerID = C.CustomerID
				JOIN tblOrderType OT on O.OrderTypeID = OT.OrderTypeID
				WHERE C.CustomerFname = @cFname 
				AND C.CustomerLname = @CLname
				AND C.CustomerBirth = @Cbday
				AND C.CustomerState = @Cstate
				AND OT.OrderTypeName =  @ordertypename
)

begin tran newOrderProduct 
	INSERT INTO tblOrderProduct(ProductID, OrderID, Quantity)

	values(@p_id, @o_id, @quantity)

commit tran newOrderProduct
go

