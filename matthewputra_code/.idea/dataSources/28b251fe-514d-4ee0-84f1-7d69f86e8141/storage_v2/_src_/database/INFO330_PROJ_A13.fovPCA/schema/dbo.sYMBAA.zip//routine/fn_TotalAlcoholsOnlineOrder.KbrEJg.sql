
/* Create a computed column to calculate the number of alcohols sold in each online order. */
CREATE FUNCTION fn_TotalAlcoholsOnlineOrder(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = (select COUNT(P.ProductID)
						from tblProduct P
							JOIN tblProductType PT ON PT.ProductTypeID = P.ProductTypeID
							JOIN tblOrderProduct OP ON OP.ProductID = P.ProductID
							JOIN tblOrder O ON O.OrderID = OP.OrderID
							JOIN tblOrderType OT ON OT.OrderTypeID = O.OrderTypeID
					where O.OrderID = @PK
					AND OT.OrderTypeName = 'Online'
					AND PT.ProductTypeName LIKE '%Alcohol%')
	RETURN @Ret
END
go

