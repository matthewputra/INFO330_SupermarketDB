CREATE FUNCTION fn_CheckAlcoholProduct()
RETURNS INT
AS
    BEGIN
        DECLARE @Ret INT = 0
        IF EXISTS(SELECT SP.StoreID
            FROM tblStoreProduct AS SP
            JOIN tblProduct AS P ON SP.ProductID = P.ProductID
            JOIN tblProductType AS PT ON P.ProductTypeID = PT.ProductTypeID
            WHERE PT.ProductTypeName = 'alcohol'
            GROUP BY SP.StoreID
            HAVING COUNT(P.ProductID) > 50)
        SET @Ret = 1
        RETURN @Ret
    END
go

