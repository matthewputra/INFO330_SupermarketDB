CREATE FUNCTION fn_SumEmployee(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = (select COUNT(E.EmployeeID)
						from tblEmployee E
							JOIN tblEmployeeSalary ES ON E.EmployeeID = ES.EmployeeID
							JOIN tblEmployeeDepartment ED ON ED.EmployeeID = E.EmployeeID
							JOIN tblDepartment D ON D.DepartmentID = ED.DepartmentID
						where D.DepartmentID = @PK
						AND E.EmployeeBirth > 'January 01, 1990'
						AND ES.EmployeeSalary > 3000.00)
	RETURN @Ret
END
go

