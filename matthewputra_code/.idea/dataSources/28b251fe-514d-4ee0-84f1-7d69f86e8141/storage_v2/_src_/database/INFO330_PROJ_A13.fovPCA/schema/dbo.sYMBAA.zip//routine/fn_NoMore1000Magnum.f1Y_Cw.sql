CREATE FUNCTION fn_NoMore1000Magnum()
RETURNS INT
AS
BEGIN

DECLARE @Ret INT = 0
IF EXISTS (select S.SupplierID
		   from tblSupplier S
			   JOIN tblProductSupply PS ON PS.SupplierID = S.SupplierID
			   JOIN tblProduct P ON P.ProductID = PS.ProductID
			   JOIN tblBrand B ON B.BrandID = P.BrandID
			   JOIN tblProductType PT ON PT.ProductTypeID = P.ProductTypeID
			   JOIN tblStoreProduct SP ON SP.ProductID = P.ProductID
			   JOIN tblStore ST ON ST.StoreID = SP.StoreID
			where B.BrandName = 'Magnum'
			AND PT.ProductTypeName LIKE '%ice cream%'
			AND ST.StoreState LIKE '%Washington%'
			AND SP.StoreProductQuantity > 3000
			GROUP BY S.SupplierID
			HAVING COUNT(P.ProductID) > 1000)
	BEGIN
		SET @Ret = 1
	END
RETURN @RET
END
go

