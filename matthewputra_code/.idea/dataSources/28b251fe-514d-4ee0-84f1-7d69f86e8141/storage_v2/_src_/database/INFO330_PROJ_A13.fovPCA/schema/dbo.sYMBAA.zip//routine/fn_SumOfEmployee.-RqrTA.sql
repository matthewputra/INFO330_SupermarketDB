
/* Computed Columns */
/* Create a computed column to calculate the number of employees who was born after January 01, 1990
   receiving a salary more than 3,000.00 in each department. */
CREATE FUNCTION fn_SumOfEmployee(@PK INT)
RETURNS INT
AS
BEGIN
	DECLARE @Ret INT = (select COUNT(E.EmployeeID)
						from tblEmployee E
							JOIN tblEmployeeSalary ES ON E.EmployeeID = ES.EmployeeID
							JOIN tblEmployeeDepartment ED ON ED.EmployeeID = E.EmployeeID
							JOIN tblDepartment D ON D.DepartmentID = ED.DepartmentID
						where D.DepartmentID = @PK
						AND E.EmployeeBirth > 'January 01, 1990'
						AND ES.EmployeeSalary > 3000.00)
	RETURN @Ret
END
go

