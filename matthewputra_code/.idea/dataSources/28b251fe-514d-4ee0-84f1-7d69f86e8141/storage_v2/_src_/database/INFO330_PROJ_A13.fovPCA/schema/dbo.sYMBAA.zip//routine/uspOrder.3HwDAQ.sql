CREATE PROCEDURE uspOrder
@cFname varchar(20),
@CLname varchar(20),
@Cbday DATE,
@Cstate varchar(20),
@ordertypename varchar(20),
@orderDate DATE 


AS DECLARE @C_id INT, @OT_id INT

SET @C_id = (SELECT CustomerID
				FROM tblCustomer C
				WHERE C.CustomerFname = @cFname 
				AND C.CustomerLname = @CLname
				AND C.CustomerBirth = @Cbday
				AND C.CustomerState = @Cstate
				)

SET @OT_id = (SELECT OrderTypeID
				FROM tblOrderType OT
				WHERE OT.OrderTypeName = @ordertypename
				)

begin tran newOrder
	INSERT INTO tblOrder(CustomerID, OrderTypeID, OrderDate)
	values(@C_id, @OT_id, @orderDate)
commit tran newOrder
go

