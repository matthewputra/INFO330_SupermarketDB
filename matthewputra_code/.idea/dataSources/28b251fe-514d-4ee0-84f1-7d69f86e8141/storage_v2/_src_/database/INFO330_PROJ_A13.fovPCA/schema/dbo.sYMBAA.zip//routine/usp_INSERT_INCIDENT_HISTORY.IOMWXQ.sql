CREATE PROCEDURE usp_INSERT_INCIDENT_HISTORY
@TypeName varchar(30),
@IncidName varchar(30),
@LocateName varchar(30),
@InSTDate DATE,
@InENDate DATE,
@FirstName varchar(30),
@LastName varchar(30),
@BirthDate DATE,
@Gender varchar(10),
@OdTypeName varchar(30),
@OdDate DATE,
@StatName varchar(30),
@OSBEDate DATE,
@OSENDate DATE,
@HistDescription varchar(50)

AS

DECLARE @TypeID INT, @LocateID INT, @IncidID INT, @StatID INT, @OrTypeID INT, @GendID INT, @CustID INT, @OdID INT, @OStatID INT
SET @TypeID = (select IncidentTypeID from tblIncidentType where IncidentTypeName = @TypeName)
SET @LocateID = (select LocationID from tblLocation where LocationName = @LocateName)
SET @IncidID = (select IncidentID from tblIncident where IncidentTypeID = @TypeID
												   AND IncidentName = @IncidName
												   AND LocationID = @LocateID
												   AND StartDate = @InSTDate
												   AND EndDate = @InENDate)
SET @StatID = (select StatusID from tblStatus where StatusName = @StatName)
SET @GendID = (select GenderID from tblGender where GenderName = @Gender)
SET @CustID = (select CustomerID from tblCustomer where GenderID = @GendID
												  AND CustomerFname = @FirstName
												  AND CustomerLname = @LastName
												  AND CustomerBirth = @BirthDate)
SET @OrTypeID = (select OrderTypeID from tblOrderType where OrderTypeName = @OdTypeName)
SET @OdID = (select OrderID from tblOrder where CustomerID = @CustID
										  AND OrderTypeID = @OrTypeID
										  AND OrderDate = @OdDate)
SET @OStatID = (select OrderStatusID from tblOrderStatus where OrderID = @OdID
														 AND StatusID = @StatID
														 AND BeginDate = @OSBEDate
														 AND EndDate = @OSENDate)

INSERT INTO tblIncidentHistory(OrderStatusID, IncidentID, IncidentHistoryDescription)
VALUES(@OStatID, @IncidID, @HistDescription)
go

