CREATE PROCEDURE usp_INSERT_EMPLOYEE_DEPARTMENT
@FirstName varchar(30),
@LastName varchar(30),
@Gender varchar(10),
@BirthDate DATE,
@DeptName varchar(30),
@PosName varchar(30),
@StartDate DATE,
@EndDate DATE

AS

DECLARE @GendID INT, @EmpID INT, @DeptID INT, @PosID INT
SET @GendID = (select GenderID from tblGender where GenderName = @Gender)
SET @EmpID = (select EmployeeID from tblEmployee where GenderID = @GendID
												 AND EmployeeFname = @FirstName
												 AND EmployeeLname = @LastName
												 AND EmployeeBirth = @BirthDate)
SET @DeptID = (select DepartmentID from tblDepartment where DepartmentName = @DeptName)
SET @PosID = (select PositionID from tblPosition where PositionName = @PosName)

INSERT INTO tblEmployeeDepartment(EmployeeID, DepartmentID, PositionID, EmployeeDepartmentStartDate, EmployeeDepartmentEndDate)
VALUES(@EmpID, @DeptID, @PosID, @StartDate, @EndDate)
go

