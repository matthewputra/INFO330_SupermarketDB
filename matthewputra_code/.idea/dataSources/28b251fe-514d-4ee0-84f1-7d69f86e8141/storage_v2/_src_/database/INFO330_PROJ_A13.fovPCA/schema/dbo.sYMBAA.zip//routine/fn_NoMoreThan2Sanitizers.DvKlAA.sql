/* Stored Procedures */
/* Insert a new row into tblEmployeeDepartment - Assign an exsiting employee to a department */
/*
CREATE PROCEDURE usp_INSERT_EMPLOYEE_DEPARTMENT
@FirstName varchar(30),
@LastName varchar(30),
@Gender varchar(10),
@BirthDate DATE,
@DeptName varchar(30),
@PosName varchar(30),
@StartDate DATE,
@EndDate DATE

AS

DECLARE @GendID INT, @EmpID INT, @DeptID INT, @PosID INT
SET @GendID = (select GenderID from tblGender where GenderName = @Gender)
SET @EmpID = (select EmployeeID from tblEmployee where GenderID = @GendID
												 AND EmployeeFname = @FirstName
												 AND EmployeeLname = @LastName
												 AND EmployeeBirth = @BirthDate)
SET @DeptID = (select DepartmentID from tblDepartment where DepartmentName = @DeptName)
SET @PosID = (select PositionID from tblPosition where PositionName = @PosName)

INSERT INTO tblEmployeeDepartment(EmployeeID, DepartmentID, PositionID, EmployeeDepartmentStartDate, EmployeeDepartmentEndDate)
VALUES(@EmpID, @DeptID, @PosID, @StartDate, @EndDate)

/* Insert a new row into tblIncident - Record a new incident */
CREATE PROCEDURE usp_INSERT_INCIDENT_HISTORY
@TypeName varchar(30),
@IncidName varchar(30),
@LocateName varchar(30),
@InSTDate DATE,
@InENDate DATE,
@FirstName varchar(30),
@LastName varchar(30),
@BirthDate DATE,
@Gender varchar(10),
@OdTypeName varchar(30),
@OdDate DATE,
@StatName varchar(30),
@OSBEDate DATE,
@OSENDate DATE,
@HistDescription varchar(50)

AS

DECLARE @TypeID INT, @LocateID INT, @IncidID INT, @StatID INT, @OrTypeID INT, @GendID INT, @CustID INT, @OdID INT, @OStatID INT
SET @TypeID = (select IncidentTypeID from tblIncidentType where IncidentTypeName = @TypeName)
SET @LocateID = (select LocationID from tblLocation where LocationName = @LocateName)
SET @IncidID = (select IncidentID from tblIncident where IncidentTypeID = @TypeID
												   AND IncidentName = @IncidName
												   AND LocationID = @LocateID
												   AND StartDate = @InSTDate
												   AND EndDate = @InENDate)
SET @StatID = (select StatusID from tblStatus where StatusName = @StatName)
SET @GendID = (select GenderID from tblGender where GenderName = @Gender)
SET @CustID = (select CustomerID from tblCustomer where GenderID = @GendID
												  AND CustomerFname = @FirstName
												  AND CustomerLname = @LastName
												  AND CustomerBirth = @BirthDate)
SET @OrTypeID = (select OrderTypeID from tblOrderType where OrderTypeName = @OdTypeName)
SET @OdID = (select OrderID from tblOrder where CustomerID = @CustID
										  AND OrderTypeID = @OrTypeID
										  AND OrderDate = @OdDate)
SET @OStatID = (select OrderStatusID from tblOrderStatus where OrderID = @OdID
														 AND StatusID = @StatID
														 AND BeginDate = @OSBEDate
														 AND EndDate = @OSENDate)

INSERT INTO tblIncidentHistory(OrderStatusID, IncidentID, IncidentHistoryDescription)
VALUES(@OStatID, @IncidID, @HistDescription)
*/
/* Business Rules */
/* Customers in WA, OR and CA can only buy a maximum of 2 hand sanitizers per online order. */
CREATE FUNCTION fn_NoMoreThan2Sanitizers()
RETURNS INT
AS
BEGIN

DECLARE @Ret INT = 0
IF EXISTS (select O.OrderID
		   from tblOrder O
			   JOIN tblOrderType OT ON OT.OrderTypeID = O.OrderTypeID
			   JOIN tblCustomer C ON C.CustomerID = O.CustomerID
			   JOIN tblOrderProduct OP ON OP.OrderID = O.OrderID
			   JOIN tblProduct P ON P.ProductID = OP.ProductID
			   JOIN tblProductType PT ON PT.ProductTypeID = P.ProductTypeID
			where PT.ProductTypeName LIKE '%hand sanitizer%'
			AND OT.OrderTypeName = 'Online'
			AND (C.CustomerState LIKE '%Washington%'
			OR C.CustomerState LIKE '%Oregon%'
			OR C.CustomerState LIKE '%California%')
			GROUP BY O.OrderID
			HAVING COUNT(P.ProductID) > 2)
	BEGIN
		SET @Ret = 1
	END
RETURN @RET
END
go

